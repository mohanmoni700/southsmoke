# Grouped Product Staging Functional Tests

The Functional Test Module for **Magento Grouped Product Staging** module.
