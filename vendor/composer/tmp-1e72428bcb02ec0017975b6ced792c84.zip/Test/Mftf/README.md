# Purchase Order Functional Tests

The Functional Test Module for **Magento Purchase Order** module.
