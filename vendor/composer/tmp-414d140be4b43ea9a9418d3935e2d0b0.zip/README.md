The Magento_Developer module provides functionality to make it easier to develop in Magento 2.
