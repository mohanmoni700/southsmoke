# SharedCatalogGraphQL
**SharedCatalogGraphQL** customises products and categoryTree queries to reflect shared catalog information
