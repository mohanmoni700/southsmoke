# Review Staging Functional Tests

The Functional Test Module for **Magento Review Staging** module.
