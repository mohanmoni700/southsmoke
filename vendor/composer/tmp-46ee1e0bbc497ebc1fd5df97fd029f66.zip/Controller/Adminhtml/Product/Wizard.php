<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\ConfigurableProductStaging\Controller\Adminhtml\Product;

use Magento\ConfigurableProduct\Controller\Adminhtml\Product\Wizard as ProductWizard;

class Wizard extends ProductWizard
{
}
