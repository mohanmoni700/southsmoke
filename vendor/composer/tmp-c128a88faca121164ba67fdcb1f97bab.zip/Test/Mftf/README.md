# Visual Merchandiser Functional Tests

The Functional Test Module for **Magento Visual Merchandiser** module.
