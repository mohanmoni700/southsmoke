<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

return [
    \Magento\TestFramework\Core\Version\View::class => \Magento\TestFramework\B2b\Version\View::class,
];
