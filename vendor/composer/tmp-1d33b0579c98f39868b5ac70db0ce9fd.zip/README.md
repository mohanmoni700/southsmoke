## CheckoutAddressSearchGiftRegistry module Overview

CheckoutAddressSearchGiftRegistry module extends Magento_GiftRegistry and adds search customer shipping and billing addresses functionality on checkout to gift registry only if customer address search is enabled in configuration.
