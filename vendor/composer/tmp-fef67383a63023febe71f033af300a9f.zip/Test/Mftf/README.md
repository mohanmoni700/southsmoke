# Website Restriction Functional Tests

The Functional Test Module for **Magento Website Restriction** module.
