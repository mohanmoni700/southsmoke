Magento_CatalogEvent module is designed for creating campaigns that encourage customers to buy products with lower prices.
There are three types of the catalog events: upcoming, open, closed.
