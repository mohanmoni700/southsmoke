# Catalog Event Functional Tests

The Functional Test Module for **Magento Catalog Event** module.
