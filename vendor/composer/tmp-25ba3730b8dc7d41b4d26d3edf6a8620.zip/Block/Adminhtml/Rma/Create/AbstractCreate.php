<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Rma\Block\Adminhtml\Rma\Create;

/**
 * Admin RMA create form header
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
abstract class AbstractCreate extends \Magento\Backend\Block\Widget
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve create order model object
     *
     * @return \Magento\Rma\Model\Rma\Create
     */
    public function getCreateRmaModel()
    {
        return $this->_coreRegistry->registry('rma_create_model');
    }

    /**
     * Retrieve customer identifier
     *
     * @return int
     */
    public function getCustomerId()
    {
        return (int)$this->getCreateRmaModel()->getCustomerId();
    }

    /**
     * Retrieve customer identifier
     *
     * @return int
     */
    public function getStoreId()
    {
        return (int)$this->getCreateRmaModel()->getStoreId();
    }

    /**
     * Retrieve customer object
     *
     * @return int
     */
    public function getCustomer()
    {
        return $this->getCreateRmaModel()->getCustomer();
    }

    /**
     * Retrieve customer name
     *
     * @return int
     */
    public function getCustomerName()
    {
        return $this->escapeHtml($this->getCustomer()->getName());
    }

    /**
     * Retrieve order identifier
     *
     * @return int
     */
    public function getOrderId()
    {
        return (int)$this->getCreateRmaModel()->getOrderId();
    }

    /**
     * Set Customer Id
     *
     * @param int $id
     * @return void
     */
    public function setCustomerId($id)
    {
        $this->getCreateRmaModel()->setCustomerId($id);
    }

    /**
     * Set Order Id
     *
     * @param int $id
     * @return mixed
     */
    public function setOrderId($id)
    {
        return $this->getCreateRmaModel()->setOrderId($id);
    }
}
