# Rma Staging Functional Tests

The Functional Test Module for **Magento Rma Staging** module.
