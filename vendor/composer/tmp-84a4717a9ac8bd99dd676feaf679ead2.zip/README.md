# Magento_StagingPageBuilder module

The Magento_StagingPageBuilder module sets up PageBuilder to be a part of the staging functionality in Magento EE.
