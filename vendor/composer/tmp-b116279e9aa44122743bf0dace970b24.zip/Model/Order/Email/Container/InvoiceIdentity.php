<?php
namespace RedChamps\UnpaidInvoices\Model\Order\Email\Container;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class InvoiceIdentity extends \Magento\Sales\Model\Order\Email\Container\InvoiceIdentity
{
    const XML_PATH_EMAIL_COPY_METHOD = 'unpaid_invoices/email_template/copy_method';
    const XML_PATH_EMAIL_COPY_TO = 'unpaid_invoices/email_template/copy_to';

    /**
     * Return email copy_to list
     *
     * @return array|bool
     */
    public function getEmailCopyTo()
    {
        $data = $this->getConfigValue(self::XML_PATH_EMAIL_COPY_TO, $this->getStore()->getStoreId());
        if (!empty($data)) {
            return array_map('trim', explode(',', $data));
        }
        return false;
    }

    /**
     * Return email copy method
     *
     * @return mixed
     */
    public function getCopyMethod()
    {
        return $this->getConfigValue(self::XML_PATH_EMAIL_COPY_METHOD, $this->getStore()->getStoreId());
    }
}
