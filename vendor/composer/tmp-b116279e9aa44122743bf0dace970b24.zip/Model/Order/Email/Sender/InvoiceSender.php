<?php
namespace RedChamps\UnpaidInvoices\Model\Order\Email\Sender;

use Magento\Sales\Model\Order;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class InvoiceSender extends Order\Email\Sender\InvoiceSender
{
    const BASE_PATH = "unpaid_invoices/email_template/";

    const BASE_PATH_REMINDERS = "unpaid_invoices/reminders/";

    protected function prepareTemplate(Order $order)
    {
        parent::prepareTemplate($order);
        $baseConfigPath = $order->getReminderEmail()?self::BASE_PATH_REMINDERS:self::BASE_PATH;
        if ($order->getCustomerIsGuest()) {
            $templateId = $this->globalConfig->getValue($baseConfigPath . 'guest_template');
        } else {
            $templateId = $this->globalConfig->getValue($baseConfigPath . 'template');
        }
        $this->templateContainer->setTemplateId($templateId);
    }
}
