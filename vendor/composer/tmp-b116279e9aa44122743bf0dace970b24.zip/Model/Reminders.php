<?php
namespace RedChamps\UnpaidInvoices\Model;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class Reminders extends AbstractModel
{
    /**
     * @var TimezoneInterface
     */
    protected $date;

    public function __construct(
        TimezoneInterface $date,
        Context $context,
        Registry $registry,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    )
    {
        $this->date = $date;
        parent::__construct(
            $context,
            $registry,
            $resource,
            $resourceCollection,
            $data
        );
    }

    public function _construct()
    {
        parent::_construct();
        $this->_init('RedChamps\UnpaidInvoices\Model\ResourceModel\Reminders');
    }

    public function beforeSave()
    {
        $date = $this->date->date()->format('Y-m-d H:i:s');
        if(!$this->getCreatedAt()) {
            $this->setCreatedAt($date);
        }
        $this->setUpdatedAt($date);
        return parent::beforeSave();
    }
}
