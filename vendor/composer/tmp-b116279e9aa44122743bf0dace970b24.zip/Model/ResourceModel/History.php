<?php
namespace RedChamps\UnpaidInvoices\Model\ResourceModel;

use Magento\Framework\DataObject;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class History extends AbstractDb
{
    const TABLE_NAME = 'redchamps_unpaid_invoice_history';

    public function _construct()
    {
        $this->_init(self::TABLE_NAME, 'id');
    }

    public function beforeSave(DataObject $object)
    {
        $object->setCreatedAt(gmdate('Y-m-d H:i:s'));
        parent::beforeSave($object);
    }
}
