<?php
namespace RedChamps\UnpaidInvoices\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class Reminders extends AbstractDb
{
    public function _construct()
    {
        $this->_init('redchamps_unpaid_invoice_reminders', 'id');
    }
}
