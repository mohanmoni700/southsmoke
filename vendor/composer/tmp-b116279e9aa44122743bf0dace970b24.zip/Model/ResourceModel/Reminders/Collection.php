<?php
namespace RedChamps\UnpaidInvoices\Model\ResourceModel\Reminders;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class Collection extends AbstractCollection
{
    public function _construct()
    {
        parent::_construct();
        $this->_init(
            'RedChamps\UnpaidInvoices\Model\Reminders',
            'RedChamps\UnpaidInvoices\Model\ResourceModel\Reminders'
        );
    }
}
