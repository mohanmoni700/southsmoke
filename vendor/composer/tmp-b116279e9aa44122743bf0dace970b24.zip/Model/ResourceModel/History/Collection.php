<?php
namespace RedChamps\UnpaidInvoices\Model\ResourceModel\History;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    public function _construct()
    {
        $this->_init(
            'RedChamps\UnpaidInvoices\Model\History',
            'RedChamps\UnpaidInvoices\Model\ResourceModel\History'
        );
    }

}
