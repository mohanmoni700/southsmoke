<?php
namespace RedChamps\UnpaidInvoices\Model;

use Magento\Framework\Model\AbstractModel;

class History extends AbstractModel
{
    public function _construct()
    {
       $this->_init('RedChamps\UnpaidInvoices\Model\ResourceModel\History');
    }
}
