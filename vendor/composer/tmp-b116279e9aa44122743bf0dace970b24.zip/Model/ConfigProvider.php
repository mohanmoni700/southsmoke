<?php
namespace RedChamps\UnpaidInvoices\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class ConfigProvider
{
    private $scopeConfig;

    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    public function getInvoiceIdPrefix()
    {
        return $this->getSetting("prefix", "general");
    }

    public function getSetting($path, $type = "reminders", $storeId = null)
    {
        return $this->scopeConfig->getValue(
            "unpaid_invoices/$type/$path",
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
}
