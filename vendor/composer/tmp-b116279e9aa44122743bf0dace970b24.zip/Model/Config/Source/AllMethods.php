<?php
namespace RedChamps\UnpaidInvoices\Model\Config\Source;

use Magento\Framework\App\Config\Initial;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Payment\Model\Config;
use Magento\Payment\Model\Method\Factory;
use Magento\Payment\Model\MethodInterface;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class AllMethods implements OptionSourceInterface
{
    const XML_PATH_PAYMENT_METHODS = 'payment';

    /**
     * initial config
     *
     * @var  Initial
     */
    protected $initialConfig;

    protected $paymentConfig;

    protected $methodFactory;

    protected $scopeConfig;

    /**
     * @param Initial $initialConfig
     * @param Config $paymentConfig
     * @param Factory $paymentMethodFactory
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Initial $initialConfig,
        Config $paymentConfig,
        Factory $paymentMethodFactory,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->initialConfig = $initialConfig;
        $this->paymentConfig = $paymentConfig;
        $this->methodFactory = $paymentMethodFactory;
        $this->scopeConfig = $scopeConfig;
    }

    public function toOptionArray()
    {
        $methods = [];
        $groups = [];
        $groupRelations = [];
        $titles = [];

        foreach ($this->getPaymentMethods() as $code => $data) {
            $methodInstance = $this->getMethodInstance($code);
            if (!$methodInstance) continue;
            $storedTitle = $methodInstance->getConfigData('title', null);
            $title = false;
            if (isset($storedTitle)) {
                $title = $storedTitle;
            } elseif (isset($data['title'])) {
                $title = $data['title'];
            }
            if ($title instanceof \Magento\Framework\Phrase) {
                $title = $title->getText();
            }
            if ($title) {
                if (isset($titles[$title])) {
                    $methods[$code] = $title . " [" . $code . "]";
                } else {
                    $methods[$code] = $title;
                }
                $titles[$title] = 1;
                if (isset($data['group'])) {
                    $groupRelations[$code] = $data['group'];
                }
            }
        }
        $groups = $this->paymentConfig->getGroups();
        foreach ($groups as $code => $title) {
            $methods[$code] = $title;
        }

        asort($methods);

        $labelValues = [];
        foreach ($methods as $code => $title) {
            $labelValues[$code] = [];
        }
        foreach ($methods as $code => $title) {
            if (isset($groups[$code])) {
                $labelValues[$code]['label'] = $title;
                if (!isset($labelValues[$code]['value'])) {
                    $labelValues[$code]['value'] = null;
                }
            } elseif (isset($groupRelations[$code])) {
                unset($labelValues[$code]);
                $labelValues[$groupRelations[$code]]['value'][$code] = ['value' => $code, 'label' => $title];
            } else {
                $labelValues[$code] = ['value' => $code, 'label' => $title];
            }
        }
        return $labelValues;
    }

    protected function getPaymentMethods()
    {
        return $this->initialConfig->getData('default')[self::XML_PATH_PAYMENT_METHODS];
    }

    /**
     * Retrieve method model object
     *
     * @param string $code
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return MethodInterface|boolean
     */
    public function getMethodInstance($code)
    {
        $class = $this->scopeConfig->getValue(
            $this->getMethodModelConfigName($code),
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        if (!$class) {
            return false;
        }

        return $this->methodFactory->create($class);
    }

    /**
     * Get config name of method model
     *
     * @param string $code
     * @return string
     */
    protected function getMethodModelConfigName($code)
    {
        return sprintf('%s/%s/model', self::XML_PATH_PAYMENT_METHODS, $code);
    }
}
