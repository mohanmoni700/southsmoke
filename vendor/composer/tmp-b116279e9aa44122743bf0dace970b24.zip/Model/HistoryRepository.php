<?php
namespace RedChamps\UnpaidInvoices\Model;

use RedChamps\UnpaidInvoices\Model\HistoryFactory;
use RedChamps\UnpaidInvoices\Model\ResourceModel\History as HistoryResource;

class HistoryRepository
{
    private $historyFactory;

    private $historyResource;

    public function __construct(
        HistoryFactory $historyFactory,
        HistoryResource $historyResource
    ) {

        $this->historyFactory = $historyFactory;
        $this->historyResource = $historyResource;
    }

    public function save($history)
    {
        $this->historyResource->save($history);
    }

    public function getEmptyInstance()
    {
        return $this->historyFactory->create();
    }
}
