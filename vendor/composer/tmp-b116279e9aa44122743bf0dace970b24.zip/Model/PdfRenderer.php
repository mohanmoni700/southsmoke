<?php
namespace RedChamps\UnpaidInvoices\Model;

use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\Order\Pdf\Invoice;

class PdfRenderer
{
    private $pdfInvoice;

    private $dateTime;

    protected $invoice;

    private $configProvider;

    public function __construct(
        Invoice $pdfInvoice,
        ConfigProvider $configProvider,
        DateTime $dateTime
    ) {
        $this->pdfInvoice = $pdfInvoice;
        $this->dateTime = $dateTime;
        $this->configProvider = $configProvider;
    }

    public function render($invoices)
    {
        $this->setInvoice($invoices[0]);
        return $this->pdfInvoice->getPdf($invoices)->render();
    }

    public function getName($invoice = null)
    {
        $invoice = !is_null($invoice)?$invoice:$this->getInvoice();
        return (string)__($this->configProvider->getSetting("pdf_name", "general"), [
            'invoice_increment_id' => $invoice?$invoice->getIncrementId():'',
            'order_increment_id' => $invoice?$invoice->getOrder()->getIncrementId():'',
            'datetime' => $this->dateTime->date('d-M-Y_H-i-s'),
            'date' => $this->dateTime->date('d-M-Y')
        ]);
    }

    protected function getInvoice()
    {
        return $this->invoice;
    }

    public function setInvoice($invoice)
    {
        $this->invoice = $invoice;
    }
}
