<?php
namespace RedChamps\UnpaidInvoices\Model;

use Magento\Framework\Message\ManagerInterface;
use RedChamps\UnpaidInvoices\Action\GetInvoice;
use RedChamps\UnpaidInvoices\Model\Order\Email\Sender\InvoiceSender;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class EmailSender
{
    protected $invoiceSender;

    protected $messageManager;

    protected $historyRepository;

    private $getInvoice;

    public function __construct(
        GetInvoice $getInvoice,
        ManagerInterface $messageManager,
        InvoiceSender $invoiceSender,
        HistoryRepository $historyRepository
    ) {
        $this->messageManager = $messageManager;
        $this->invoiceSender = $invoiceSender;
        $this->historyRepository = $historyRepository;
        $this->getInvoice = $getInvoice;
    }

    public function sendEmail($order, $reason='by unknown', $isReminder = false)
    {
        if ($order->getId()) {
            try {
                if ($order->canInvoice()) {
                    $order->setReminderEmail($isReminder);
                    if ($this->invoiceSender->send($this->getInvoice->execute($order), true)) {
                        $this->historyRepository->save(
                            $this->historyRepository->getEmptyInstance()->setData(
                                [
                                    "reason" => $reason,
                                    "order_id" => $order->getId()
                                ]
                            )
                        );
                        return true;
                    }
                } else {
                    throw new \Exception('order is completely invoiced.');
                }
            } catch (\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        }
        return false;
    }
}
