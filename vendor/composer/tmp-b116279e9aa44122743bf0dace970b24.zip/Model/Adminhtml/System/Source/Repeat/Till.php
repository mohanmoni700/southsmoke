<?php
namespace RedChamps\UnpaidInvoices\Model\Adminhtml\System\Source\Repeat;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class Till
{
    /**
     * Fetch options array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Order is Paid',
                'value' => 'always'
            ],
            [
                'label' => 'Specific Times',
                'value' => 'specific'
            ]
        ];
    }
}
