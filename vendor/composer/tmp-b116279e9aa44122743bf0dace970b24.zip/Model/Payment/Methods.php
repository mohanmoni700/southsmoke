<?php
namespace RedChamps\UnpaidInvoices\Model\Payment;

class Methods
{
    private $methods;

    public function __construct(array $methods = [])
    {
        $this->methods = $methods;
    }

    public function getAvailableMethods()
    {
        return array_filter(
            $this->methods,
            function ($method) {
                return $method->isActive();
            }
        );
    }
}
