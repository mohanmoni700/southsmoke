<?php
namespace RedChamps\UnpaidInvoices\Model\Payment;

use RedChamps\UnpaidInvoices\Model\ConfigProvider;

class Method
{
    /**
     * @var ConfigProvider
     */
    private $configProvider;

    protected $activeConfigPath = "";

    public function __construct(ConfigProvider $configProvider)
    {
        $this->configProvider = $configProvider;
    }

    public function isActive()
    {
        return $this->configProvider->getSetting('active', "payment_methods/".$this->activeConfigPath);
    }

    public function getLink($order)
    {
        return false;
    }
}
