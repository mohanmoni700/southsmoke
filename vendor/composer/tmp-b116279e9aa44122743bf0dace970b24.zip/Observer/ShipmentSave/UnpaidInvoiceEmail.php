<?php
namespace RedChamps\UnpaidInvoices\Observer\ShipmentSave;

use Magento\Framework\Event\Observer;
use RedChamps\UnpaidInvoices\Observer\AbstractUnpaidInvoiceEmail;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class UnpaidInvoiceEmail extends AbstractUnpaidInvoiceEmail
{
    public function execute(Observer $observer)
    {
        if($this->configProvider->getSetting('shipment_trigger', 'general')) {
            $orderId = $observer->getEvent()->getRequest()->getParam('order_id');
            if(is_array($orderId)) {
                $orderId = $orderId['order_id'];
            }
            $order = $this->orderRepository->get($orderId);
            $this->triggerEmail($order,'when shipment is created');
        }
    }
}
