<?php
namespace RedChamps\UnpaidInvoices\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Url;
use Magento\Framework\Event\ObserverInterface;
use RedChamps\UnpaidInvoices\Model\Payment\Methods;

class SetInvoiceMailVariable implements ObserverInterface
{
    private $paymentMethods;

    private $urlBuilder;

    public function __construct(
        Methods $paymentMethods,
        Url $urlBuilder
    ) {
        $this->paymentMethods = $paymentMethods;
        $this->urlBuilder = $urlBuilder;
    }

    public function execute(Observer $observer)
    {
        $transportObject = $observer->getData('transportObject');
        $invoice = $transportObject->getInvoice();
        if ($invoice->getId()) {
            return;
        }
        if (count($this->paymentMethods->getAvailableMethods())) {
            $transportObject->setPaymentLink($this->urlBuilder->getUrl('unpaid-invoice/action/pay', ['order' => $invoice->getOrderId()]));
        }
    }
}
