<?php
namespace RedChamps\UnpaidInvoices\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Psr\Log\LoggerInterface;
use RedChamps\UnpaidInvoices\Action\IsOrderAllowed;
use RedChamps\UnpaidInvoices\Model\ConfigProvider;
use RedChamps\UnpaidInvoices\Model\EmailSender;

abstract class AbstractUnpaidInvoiceEmail implements ObserverInterface
{
    /** @var EmailSender */
    protected $emailSender;

    /** @var LoggerInterface */
    protected $logger;
    /**
     * @var ConfigProvider
     */
    protected $configProvider;

    /**
     * @var IsOrderAllowed
     */
    protected $isOrderAllowed;

    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    public function __construct(
        EmailSender $emailSender,
        IsOrderAllowed $isOrderAllowed,
        ConfigProvider $configProvider,
        LoggerInterface $logger,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->emailSender = $emailSender;
        $this->logger = $logger;
        $this->configProvider = $configProvider;
        $this->isOrderAllowed = $isOrderAllowed;
        $this->orderRepository = $orderRepository;
    }

    protected function triggerEmail($order, $comment = "")
    {
        try {
            if ($this->isOrderAllowed->execute($order)) {
                $this->emailSender->sendEmail($order, $comment);
            }
        } catch (\Exception $exception) {
            $this->logger->critical($exception);
        }
    }
}
