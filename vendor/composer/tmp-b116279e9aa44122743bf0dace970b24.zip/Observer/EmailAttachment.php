<?php
namespace RedChamps\UnpaidInvoices\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use RedChamps\EmailAttachmentHelper\Model\ContentAttacher;
use RedChamps\UnpaidInvoices\Model\ConfigProvider;
use RedChamps\UnpaidInvoices\Model\PdfRenderer;

class EmailAttachment implements ObserverInterface
{
    private $pdfRenderer;

    private $contentAttacher;

    private $configProvider;

    private $logger;

    public function __construct(
        PdfRenderer $pdfRenderer,
        ContentAttacher $contentAttacher,
        ConfigProvider $configProvider,
        LoggerInterface $logger
    ) {
        $this->pdfRenderer = $pdfRenderer;
        $this->contentAttacher = $contentAttacher;
        $this->configProvider = $configProvider;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        try {
            if (!$this->needToAttach($observer->getTemplateId())) {
                return;
            }
            /**
             * @var \Magento\Sales\Api\Data\InvoiceInterface $invoice
             */
            $invoice = $this->getInvoice($observer);

            if ($content = $this->pdfRenderer->render([$invoice])) {
                $this->contentAttacher->addPdf(
                    $content,
                    $this->pdfRenderer->getName(),
                    $observer->getAttachmentContainer()
                );
            }
        } catch (\Exception $exception) {
            $this->logger->critical(
                "Error while attaching PDF to Unpaid Invoice email",
                ['message' => $exception->getMessage(), 'trace' => $exception->getTraceAsString()]
            );
        }
    }

    /**
     * @param $observer
     * @return \Magento\Sales\Api\Data\InvoiceInterface|string
     */
    public function getInvoice($observer)
    {
        $templateVars = $observer->getTemplateVars();
        if (!isset($templateVars['invoice'])) {
            return '';
        }
        return $templateVars['invoice'];
    }

    protected function needToAttach($templateId)
    {
        if (
            $this->configProvider->getSetting("attach_pdf", "email_template")
            && (
                $templateId == $this->configProvider->getSetting("template", "email_template")
                || $templateId == $this->configProvider->getSetting("guest_template", "email_template")
                || $templateId == $this->configProvider->getSetting("template")
                || $templateId == $this->configProvider->getSetting("guest_template")
            )
        ) {
            return true;
        }
        return false;
    }
}
