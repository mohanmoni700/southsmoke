<?php
namespace RedChamps\UnpaidInvoices\Observer\AfterPlaceOrder;

use Magento\Framework\Event\Observer;
use RedChamps\UnpaidInvoices\Observer\AbstractUnpaidInvoiceEmail;

class UnpaidInvoiceEmail extends AbstractUnpaidInvoiceEmail
{
    public function execute(Observer $observer)
    {
        if ($this->configProvider->getSetting("order_trigger", "general")) {
            /* @var $order \Magento\Sales\Model\Order */
            $order = $observer->getData('order');
            $this->triggerEmail($order, 'after order placed');
            $this->removeUnpaidInvoiceFromCollection($order);
        }
    }

    protected function removeUnpaidInvoiceFromCollection($order)
    {
        $invoicesCollection = $order->getInvoiceCollection();
        foreach ($invoicesCollection->getItems() as $key => $invoice) {
            if($invoice->getPregenerated()) {
                $invoicesCollection->removeItemByKey($key);
                break;
            }
        }
    }
}
