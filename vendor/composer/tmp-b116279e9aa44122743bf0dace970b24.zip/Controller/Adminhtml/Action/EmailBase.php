<?php
namespace RedChamps\UnpaidInvoices\Controller\Adminhtml\Action;

use Magento\Backend\App\Action;
use Magento\Sales\Model\OrderRepository;
use RedChamps\UnpaidInvoices\Model\EmailSender;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
abstract class EmailBase extends Action
{
    protected $emailSender;

    protected $orderRepository;

    public function __construct(
        Action\Context $context,
        EmailSender $emailSender,
        OrderRepository $orderRepository
    )
    {
        $this->emailSender = $emailSender;
        $this->orderRepository  = $orderRepository;
        parent::__construct($context);
    }
}
