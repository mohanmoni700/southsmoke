<?php
namespace RedChamps\UnpaidInvoices\Controller\Adminhtml\Action;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class PdfBulk extends PdfBase
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'RedChamps_UnpaidInvoices::print';

    /**
     * print custom invoices from order_ids
     *
     */
    public function execute()
    {
        $orderIds = $this->getRequest()->getPost('selected');
        if (sizeof($orderIds)) {
            if ($content = $this->prepareInvoiceAndGetPdf($orderIds)) {
                return $this->fileFactory->create(
                    $this->pdfRenderer->getName(),
                    $content,
                    DirectoryList::VAR_DIR,
                    'application/pdf'
                );
            } else {
                $this->messageManager->addErrorMessage(
                    __('Unable to generate PDF content. Please try again.')
                );
            }
        } else {
            $this->messageManager->addErrorMessage(__('There are no printable documents related to selected orders.'));
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
