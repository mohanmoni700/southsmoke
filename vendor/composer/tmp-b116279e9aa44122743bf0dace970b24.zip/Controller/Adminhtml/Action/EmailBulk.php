<?php
namespace RedChamps\UnpaidInvoices\Controller\Adminhtml\Action;

use Magento\Framework\Controller\ResultFactory;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class EmailBulk extends EmailBase
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'RedChamps_UnpaidInvoices::email';

    /*
     * Function sends Invoice email on mass action 'Send Invoice Email' option from Sales->Order page
     * */
    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $orderIds = $this->getRequest()->getPost('selected');
        $success = 0;
        if (sizeof($orderIds)) {
            foreach($orderIds as $orderId) {
                $order = $this->orderRepository->get($orderId);
                try {
                    if ($this->emailSender->sendEmail($order,'using mass action')) {
                        $success++;
                    }
                } catch (\Exception $exception) {
                    $this->messageManager->addErrorMessage(
                        __("Invoice generation for order# %1 has produced error: [%2]", $order->getIncrementId(), $exception->getMessage())
                    );
                }
            }
            $this->messageManager->addSuccessMessage(
                __('Invoice email for order %1 out of %2 successfully sent.', $success, count($orderIds))
            );
        } else {
            $this->messageManager->addErrorMessage(__("Order(s) aren't selected properly. Please try again."));
        }
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }

}
