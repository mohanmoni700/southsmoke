<?php
namespace RedChamps\UnpaidInvoices\Controller\Adminhtml\Action;

use Magento\Framework\Controller\ResultFactory;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class Email extends EmailBase
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'RedChamps_UnpaidInvoices::email';

    /*
     * Function sends Invoice email on click of 'Send Invoice Email' button from Sales->Order->View page
     * */
    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $orderId = $this->getRequest()->getParam('order_id');
        try {
            $order = $this->orderRepository->get($orderId);
            $comment = 'by clicking button';
            $reminderEmail = false;
            if ($this->getRequest()->getParam('type') == "reminder") {
                $comment = 'by clicking reminder email button';
                $reminderEmail = true;
            }
            if ($this->emailSender->sendEmail($order, $comment, $reminderEmail)) {
                $this->messageManager->addSuccessMessage(
                    __("Invoice email for order# %1 has been successfully sent.", $order->getIncrementId())
                );
            } else {
                $this->messageManager->addErrorMessage(
                    __("Unable to send email. Please check Magento logs to see the error.")
                );
            }
        } catch (\Exception $exception) {
            $this->messageManager->addErrorMessage(
                __("Invoice generation has produced error %1", $exception->getMessage())
            );
        }

        return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId]);
    }
}
