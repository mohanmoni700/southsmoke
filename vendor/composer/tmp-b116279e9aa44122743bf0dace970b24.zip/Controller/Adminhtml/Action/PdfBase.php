<?php
namespace RedChamps\UnpaidInvoices\Controller\Adminhtml\Action;

use Magento\Backend\App\Action;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\OrderRepository;
use RedChamps\UnpaidInvoices\Action\GetInvoice;
use RedChamps\UnpaidInvoices\Model\PdfRenderer;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
abstract class PdfBase extends Action
{
    protected $pdfInvoice;

    protected $fileFactory;

    protected $dateTime;

    /**
     * @var GetInvoice
     */
    private $getInvoice;

    /**
     * @var PdfRenderer
     */
    protected $pdfRenderer;
    /**
     * @var OrderRepository
     */
    private $orderRepository;

    public function __construct(
        Action\Context $context,
        OrderRepository $orderRepository,
        GetInvoice $getInvoice,
        PdfRenderer $pdfRenderer,
        FileFactory $fileFactory,
        DateTime $dateTime
    ) {
        parent::__construct($context);
        $this->fileFactory = $fileFactory;
        $this->dateTime    = $dateTime;
        $this->getInvoice = $getInvoice;
        $this->pdfRenderer = $pdfRenderer;
        $this->orderRepository = $orderRepository;
    }

    public function prepareInvoiceAndGetPdf($orderIds)
    {
        $invoices = [];
        foreach ($orderIds as $orderId) {
            $invoices[] = $this->getInvoice->execute($this->orderRepository->get($orderId));
        }
        return $this->pdfRenderer->render($invoices);
    }
}
