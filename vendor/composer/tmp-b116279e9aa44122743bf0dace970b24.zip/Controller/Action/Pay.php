<?php
namespace RedChamps\UnpaidInvoices\Controller\Action;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use RedChamps\UnpaidInvoices\Model\Payment\Methods;

class Pay implements HttpGetActionInterface
{
    private $methods;

    private $request;

    private $orderRepository;

    private $resultRedirectFactory;

    private $messageManager;

    public function __construct(
        Methods $methods,
        RequestInterface $request,
        OrderRepositoryInterface $orderRepository,
        RedirectFactory $resultRedirectFactory,
        ManagerInterface $messageManager
    ) {
        $this->methods = $methods;
        $this->request = $request;
        $this->orderRepository = $orderRepository;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->messageManager = $messageManager;
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($orderId = $this->request->getParam('order')) {
            $methods = $this->methods->getAvailableMethods();
            if (count($methods) == 1) {
                $order = $this->orderRepository->get($orderId);
                if ($order->canInvoice()) {
                    $method = reset($methods);
                    if ($link = $method->getLink($order)) {
                        $resultRedirect->setUrl($link);
                        return $resultRedirect;
                    }
                } else {
                    $this->messageManager->addErrorMessage(__('This order has already been fully paid'));
                    return $resultRedirect->setPath("/");
                }
            }
        }
        $this->messageManager->addErrorMessage(
            __("Unable to process your request at the moment due to an error. Please try again.")
        );
        return $resultRedirect->setPath("/");
    }

    protected function sendResponse($message)
    {

    }
}
