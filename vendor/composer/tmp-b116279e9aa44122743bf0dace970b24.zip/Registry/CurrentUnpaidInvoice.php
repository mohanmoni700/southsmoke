<?php
namespace RedChamps\UnpaidInvoices\Registry;

class CurrentUnpaidInvoice
{
    protected $invoice;

    public function set($invoice)
    {
        $this->invoice = $invoice;
    }

    public function get()
    {
        return $this->invoice;
    }
}
