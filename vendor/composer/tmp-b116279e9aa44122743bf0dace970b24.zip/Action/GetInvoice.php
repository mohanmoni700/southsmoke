<?php
namespace RedChamps\UnpaidInvoices\Action;

use RedChamps\UnpaidInvoices\Model\ConfigProvider;
use RedChamps\UnpaidInvoices\Registry\CurrentUnpaidInvoice;

class GetInvoice
{
    private $configProvider;

    private $currentUnpaidInvoice;

    public function __construct(
        ConfigProvider $configProvider,
        CurrentUnpaidInvoice $currentUnpaidInvoice
    ) {
        $this->configProvider = $configProvider;
        $this->currentUnpaidInvoice = $currentUnpaidInvoice;
    }

    /**
     * @param \Magento\Sales\Model\Order $order
     * @return \Magento\Sales\Model\Order\Invoice
     */
    public function execute($order)
    {
        $invoice = $order->prepareInvoice();
        $invoice->setPregenerated(true);
        $invoice->setIncrementId($this->configProvider->getInvoiceIdPrefix().$order->getIncrementId());
        $this->currentUnpaidInvoice->set($invoice);
        return $invoice;
    }
}
