<?php
namespace RedChamps\UnpaidInvoices\Action;

use RedChamps\UnpaidInvoices\Model\ConfigProvider;

class IsOrderAllowed
{
    /**
     * @var ConfigProvider
     */
    private $configProvider;

    public function __construct(ConfigProvider $configProvider)
    {
        $this->configProvider = $configProvider;
    }

    public function execute($order)
    {
        $allowedMethods = $this->configProvider->getSetting('payment_methods', 'general', $order->getStoreId());
        if($order->canInvoice() && $allowedMethods && in_array($order->getPayment()->getMethodInstance()->getCode(), explode(',', $allowedMethods))) {
            return true;
        }
        return false;
    }
}
