<?php
namespace RedChamps\UnpaidInvoices\Cron;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Magento\Store\Model\ScopeInterface;
use RedChamps\UnpaidInvoices\Model\ConfigProvider;
use RedChamps\UnpaidInvoices\Model\EmailSender;
use RedChamps\UnpaidInvoices\Model\RemindersFactory;
use RedChamps\UnpaidInvoices\Model\ResourceModel\Reminders\CollectionFactory;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class ProcessReminders
{
    protected $configProvider;

    protected $emailSender;

    protected $orderCollection;

    protected $resourceConnection;

    protected $timeZone;

    protected $dateTimeFactory;

    protected $remindersFactory;

    protected $reminderCollectionFactory;

    protected $pastRepeatFrequencyDate;

    /**
     * ProcessReminders constructor.
     * @param ConfigProvider $configProvider
     * @param EmailSender $emailSender
     * @param Collection $orderCollection
     * @param TimezoneInterface $timeZone
     * @param ResourceConnection $resourceConnection
     * @param RemindersFactory $remindersFactory
     * @param CollectionFactory $reminderCollectionFactory
     * @param DateTimeFactory $dateTimeFactory
     */
    public function __construct(
        ConfigProvider $configProvider,
        EmailSender $emailSender,
        Collection $orderCollection,
        TimezoneInterface $timeZone,
        ResourceConnection $resourceConnection,
        RemindersFactory $remindersFactory,
        CollectionFactory $reminderCollectionFactory,
        DateTimeFactory $dateTimeFactory
    ) {
        $this->configProvider = $configProvider;
        $this->emailSender = $emailSender;
        $this->orderCollection = $orderCollection;
        $this->resourceConnection = $resourceConnection;
        $this->timeZone = $timeZone;
        $this->dateTimeFactory = $dateTimeFactory;
        $this->remindersFactory = $remindersFactory;
        $this->reminderCollectionFactory = $reminderCollectionFactory;
    }

    public function execute()
    {
        $allowedMethods = $this->configProvider->getSetting('payment_methods', 'general');
        if($this->configProvider->getSetting('active') && $allowedMethods) {
            $hours = $this->configProvider->getSetting('time');
            $repeatFrequency = $this->configProvider->getSetting('repeat_frequency');
            $currentDate = $this->timeZone->date()->format('Y-m-d H:i:s');
            $pastTime = strtotime("-$hours hours", $this->dateTimeFactory->create()->timestamp(time()));
            $pastDate = date('Y-m-d H:i:s', $pastTime);
            $pastRepeatFrequencyTime = strtotime("-$repeatFrequency hours", strtotime($currentDate));
            $this->pastRepeatFrequencyDate = date('Y-m-d H:i:s', $pastRepeatFrequencyTime);
            $ordersCollection = $this->orderCollection
                ->addFieldToFilter(
                    'created_at',
                    ['lt' => $pastDate]
                )
                ->addFieldToFilter(
                    ['base_total_due', 'base_total_due'],
                    [
                        ['gt' => 0], ['null' => true]
                    ]
                );
            $allowedMethods = implode("','", explode(',', $allowedMethods));
            $ordersCollection->getSelect()
                ->join(
                    array('payment' => $this->resourceConnection->getTableName('sales_order_payment')),
                    "main_table.entity_id = payment.parent_id and payment.method in ('$allowedMethods')"
                );

            foreach($ordersCollection as $order) {
                if($order->canInvoice()) {
                    $reminderRecord = $this->reminderCollectionFactory->create()->addFieldToFilter('order_id', $order->getId())->getFirstItem();
                    if($this->canProcessOrder($reminderRecord, $order)) {
                        $reminders = !is_null($reminderRecord->getReminders())?$reminderRecord->getReminders():"1";
                        $this->emailSender->sendEmail($order, "by cron (Reminder# $reminders)", true);
                    }
                }
            }
        }
    }

    protected function canProcessOrder($reminderRecord, $order)
    {
        if(!$reminderRecord || ($reminderRecord && !$reminderRecord->getId())) {
            try {
               $newReminderRecord =  $this->remindersFactory->create()->setData([
                    'order_id' => $order->getId(),
                    'reminders' => 1
                ]);
               $newReminderRecord->getResource()->save($newReminderRecord);
            } catch (\Exception $e) {
                throw new \Exception($e);
            }
            return true;
        } elseif ($this->configProvider->getSetting('repeat')) {
            if($this->configProvider->getSetting('repeat_till') == "specific") {
                if($reminderRecord->getReminders() >= $this->configProvider->getSetting('repeat_time')) {
                    return false;
                }
            }
            if($reminderRecord->getUpdatedAt() > $this->pastRepeatFrequencyDate) {
                return false;
            }
            $reminderRecord->setReminders($reminderRecord->getReminders()+1);
            $reminderRecord->getResource()->save($reminderRecord);
            return true;
        }
        return false;
    }
}
