<?php
namespace RedChamps\UnpaidInvoices\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use RedChamps\UnpaidInvoices\Model\ResourceModel\History;

/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_UnpaidInvoices
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        if(version_compare($context->getVersion(), '1.0.1', '<')) {
            $remindersTable = $installer->getConnection()->newTable(
                $installer->getTable('redchamps_unpaid_invoice_reminders')
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                11,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )->addColumn(
                'created_at',
                Table::TYPE_DATETIME,
                255,
                ['nullable' => false],
                'Created At'
            )->addColumn(
                'updated_at',
                Table::TYPE_DATETIME,
                11,
                ['nullable' => false],
                'Updated At'
            )->addColumn(
                'order_id',
                Table::TYPE_INTEGER,
                10,
                ['unsigned' => true, 'nullable' => false],
                'Order Id'
            )->addColumn(
                'reminders',
                Table::TYPE_INTEGER,
                10,
                ['nullable' => true],
                'Number of Reminders Sent'
            )->addForeignKey(
                $setup->getFkName(
                    'redchamps_unpaid_invoice_reminders',
                    'order_id',
                    'sales_order',
                    'entity_id'
                ),
                'order_id',
                $setup->getTable('sales_order'),
                'entity_id',
                Table::ACTION_CASCADE
            )->addIndex(
                $setup->getIdxName(
                    'redchamps_unpaid_invoice_reminders',
                    'order_id',
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['order_id'],
                ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment(
                'Unpaid Invoice Reminders Record Table'
            );

            $installer->getConnection()->createTable($remindersTable);
        }

        if(version_compare($context->getVersion(), '1.0.2', '<')) {
            $historyTable = $installer->getConnection()->newTable(
                $installer->getTable(History::TABLE_NAME)
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                11,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                '',
                ['nullable' => false, 'default' => 'CURRENT_TIMESTAMP'],
                'Created At'
            )->addColumn(
                'order_id',
                Table::TYPE_INTEGER,
                10,
                ['unsigned' => true, 'nullable' => false],
                'Order Id'
            )->addColumn(
                'reason',
                Table::TYPE_TEXT,
                '',
                ['nullable' => true],
                'Reason'
            )->addForeignKey(
                $setup->getFkName(
                    'redchamps_unpaid_invoice_history',
                    'order_id',
                    'sales_order',
                    'entity_id'
                ),
                'order_id',
                $setup->getTable('sales_order'),
                'entity_id',
                Table::ACTION_CASCADE
            )->setComment(
                'Unpaid Invoice History Table'
            );

            $installer->getConnection()->createTable($historyTable);
        }

        $installer->endSetup();
    }
}
