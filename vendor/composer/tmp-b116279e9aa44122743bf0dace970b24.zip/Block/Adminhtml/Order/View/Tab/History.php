<?php
/**
 * @author RedChamps Team
 * @copyright Copyright (c) RedChamps (https://redchamps.com/)
 * @package RedChamps_RelatedOrders
 */
namespace RedChamps\UnpaidInvoices\Block\Adminhtml\Order\View\Tab;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\View\Element\Text\ListText;
use RedChamps\UnpaidInvoices\Model\ResourceModel\History\CollectionFactory;

class History extends ListText implements TabInterface
{
    protected $count = null;

    protected $collectionFactory;

    public function __construct(
        CollectionFactory $collectionFactory,
        Context $context,
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __(
            'Unpaid Invoice Email History (%1)',
            $this->getCount()
        );
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Unpaid Invoice Email History');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return $this->getCount();
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    protected function getCount()
    {
        if(is_null($this->count)) {
            $this->count = $this->collectionFactory->create()
                ->addFieldToFilter("order_id", $this->_request->getParam('order_id'))
                ->count();
        }
        return $this->count;
    }
}
