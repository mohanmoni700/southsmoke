<?php
namespace RedChamps\UnpaidInvoices\Block\Order\Email\UnpaidInvoice;

use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use RedChamps\UnpaidInvoices\Registry\CurrentUnpaidInvoice;

class Items extends \Magento\Sales\Block\Order\Email\Invoice\Items
{
    private $currentUnpaidInvoice;

    public function __construct(
        CurrentUnpaidInvoice $currentUnpaidInvoice,
        Context $context,
        array $data = [],
        ?OrderRepositoryInterface $orderRepository = null,
        ?InvoiceRepositoryInterface $invoiceRepository = null
    ) {
        $this->currentUnpaidInvoice = $currentUnpaidInvoice;
        parent::__construct($context, $data, $orderRepository, $invoiceRepository);
    }

    public function getInvoice()
    {
        if (!$this->getData('invoice')) {
            $this->setData('invoice', $this->currentUnpaidInvoice->get());
        }
        return parent::getInvoice();
    }
}
