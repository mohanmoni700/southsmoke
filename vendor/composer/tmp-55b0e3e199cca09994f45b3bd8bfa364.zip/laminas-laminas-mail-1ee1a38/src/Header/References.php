<?php

namespace Laminas\Mail\Header;

class References extends IdentificationField
{
    protected $fieldName = 'References';
    protected static $type = 'references';
}
