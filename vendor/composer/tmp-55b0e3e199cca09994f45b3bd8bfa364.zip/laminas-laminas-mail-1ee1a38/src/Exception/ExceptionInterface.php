<?php

namespace Laminas\Mail\Exception;

interface ExceptionInterface
{
}
