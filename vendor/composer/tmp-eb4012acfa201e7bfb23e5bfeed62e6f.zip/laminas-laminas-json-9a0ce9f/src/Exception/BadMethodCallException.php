<?php

namespace Laminas\Json\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
