<?php

namespace Laminas\Json\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
