Magento\Elasticsearch module allows to use Elastic search engine (v6) for product searching capabilities.
The module implements Magento\Search library interfaces.
