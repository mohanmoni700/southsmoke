<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\SharedCatalog\Model\Form\Source;

/**
 * Class SharedCatalog
 */
class SharedCatalog extends \Magento\SharedCatalog\Model\Source\SharedCatalog
{

}
