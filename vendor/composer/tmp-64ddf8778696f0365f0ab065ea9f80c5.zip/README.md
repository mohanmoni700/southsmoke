# BundleRequisitionListGraphQl

**BundleRequisitionListGraphQl** provides GraphQL schema and resolvers for the requisition list module to extend and implement bundle products in requisition list
