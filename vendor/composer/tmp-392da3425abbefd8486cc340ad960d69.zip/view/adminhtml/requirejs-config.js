/*
 * Copyright © 2020 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    map: {
        '*': {
            wyomind_framework_updater: 'Wyomind_Framework/js/updater',
        }
    },
};