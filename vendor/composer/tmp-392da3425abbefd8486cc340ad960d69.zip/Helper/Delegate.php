<?php
/**     
 * The technical support is guaranteed for all modules proposed by Wyomind.
 * The below code is obfuscated in order to protect the module's copyright as well as the integrity of the license and of the source code.
 * The support cannot apply if modifications have been made to the original source code (https://www.wyomind.com/terms-and-conditions.html).
 * Nonetheless, Wyomind remains available to answer any question you might have and find the solutions adapted to your needs.
 * Feel free to contact our technical team from your Wyomind account in My account > My tickets. 
 * Copyright © 2022 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace Wyomind\Framework\Helper;  class Delegate extends \Wyomind\Framework\Helper\License {public $xc1087=null;public $x26560=null;public $x2856b=null; const VERSION = "\67.\61\x2e\x30"; public function __construct(\Magento\Framework\ObjectManagerInterface $objectManager, \Magento\Framework\App\Helper\Context $context) { parent::__construct($objectManager, $context); $this->constructor($this, func_get_args(), __CLASS__); } protected function getDelegation() { ${$this->x26560->xa0->x113} = "\\"; return [ ]; } }