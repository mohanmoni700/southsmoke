# Customer Custom Attributes Functional Tests

The Functional Test Module for **Magento Customer Custom Attributes** module.
