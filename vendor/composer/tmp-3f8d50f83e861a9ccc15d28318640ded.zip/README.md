# Magento_AwsS3CustomerCustomAttributes module

The Magento_AwsS3CustomerCustomAttributes module created for maintaining Customer Custom Attributes tests related to Aws S3 remote storage functionality
