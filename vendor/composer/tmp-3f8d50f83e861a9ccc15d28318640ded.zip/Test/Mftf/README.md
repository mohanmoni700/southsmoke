# Aws S3 Customer Custom Attributes Functional Tests

The Functional Test Module for **Magento Aws S3 Customer Custom Attributes** module.
