# Advanced Catalog Functional Tests

The Functional Test Module for **Magento Advanced Catalog** module.
