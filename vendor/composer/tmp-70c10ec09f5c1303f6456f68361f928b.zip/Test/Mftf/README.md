# Customer Segment Functional Tests

The Functional Test Module for **Magento Customer Segment** module.
