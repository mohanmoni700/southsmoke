## Sub-split of Flysystem for AWS S3.

```bash
composer require league/flysystem-aws-s3-v3
```

View the [documentation](https://flysystem.thephpleague.com/v2/docs/adapter/aws-s3-v3/).
