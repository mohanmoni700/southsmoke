<?php

namespace Yotpo\Loyalty\Block;

use Yotpo\Loyalty\Block\AbstractBlock;

class Snippet extends AbstractBlock
{
}
