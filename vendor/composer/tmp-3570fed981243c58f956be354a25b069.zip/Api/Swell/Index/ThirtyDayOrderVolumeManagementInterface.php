<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface ThirtyDayOrderVolumeManagementInterface
{

    /**
     * GET for ThirtyDayOrderVolume api
     * @return string
     */
    public function getThirtyDayOrderVolume();
}
