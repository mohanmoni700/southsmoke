<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface TestManagementInterface
{

    /**
     * GET for Success api
     * @return string
     */
    public function getSuccess();
}
