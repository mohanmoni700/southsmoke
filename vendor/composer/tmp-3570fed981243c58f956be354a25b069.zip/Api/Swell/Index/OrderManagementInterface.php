<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface OrderManagementInterface
{

    /**
     * GET for Order api
     * @return string
     */
    public function getOrder();
}
