<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface CreateSubscriberManagementInterface
{

    /**
     * POST for CreateSubscriber api
     * @return string
     */
    public function postCreateSubscriber();
}
