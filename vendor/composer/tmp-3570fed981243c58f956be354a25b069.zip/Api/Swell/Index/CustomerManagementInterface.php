<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface CustomerManagementInterface
{

    /**
     * GET for Customer api
     * @return string
     */
    public function getCustomer();
}
