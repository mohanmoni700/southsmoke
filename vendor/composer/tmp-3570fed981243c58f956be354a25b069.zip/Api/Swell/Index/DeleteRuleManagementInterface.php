<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface DeleteRuleManagementInterface
{

    /**
     * POST for DeleteRule api
     * @return string
     */
    public function postDeleteRule();
}
