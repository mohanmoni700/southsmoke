<?php

namespace Yotpo\Loyalty\Api\Swell\Session;

interface GetCartManagementInterface
{

    /**
     * GET for GetCart api
     * @return string
     */
    public function getGetCart();
}
