<?php

namespace Yotpo\Loyalty\Api\Swell\Session;

interface SavecartManagementInterface
{

    /**
     * GET for Savecart api
     * @return string
     */
    public function getSavecart();
}
