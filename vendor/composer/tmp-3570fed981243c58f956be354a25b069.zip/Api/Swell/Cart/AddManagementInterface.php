<?php

namespace Yotpo\Loyalty\Api\Swell\Cart;

interface AddManagementInterface
{

    /**
     * GET for Add api
     * @return string
     */
    public function getAdd();
}
