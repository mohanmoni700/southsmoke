# Staging Functional Tests

The Functional Test Module for **Magento Staging** module.
