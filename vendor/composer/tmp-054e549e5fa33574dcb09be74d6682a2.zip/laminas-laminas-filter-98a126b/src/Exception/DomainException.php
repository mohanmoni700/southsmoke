<?php

declare(strict_types=1);

namespace Laminas\Filter\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
