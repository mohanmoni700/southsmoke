# Custom Attribute Management Functional Tests

The Functional Test Module for **Magento Custom Attribute Management** module.
