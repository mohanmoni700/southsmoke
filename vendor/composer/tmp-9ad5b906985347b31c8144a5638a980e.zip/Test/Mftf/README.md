# Negotiable Quote Weee Functional Tests

The Functional Test Module for **Magento Negotiable Quote Wee** module.
