## NegotiableQuoteWeee module Overview

NegotiableQuoteWeee module extends Weee if it is enabled in configuration and it adds fpt attributes to negotiable quote.
