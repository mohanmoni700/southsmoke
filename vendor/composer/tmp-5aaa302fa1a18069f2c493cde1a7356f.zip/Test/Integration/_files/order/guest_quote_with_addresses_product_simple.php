<?php

declare(strict_types=1);

$productType = 'simple';

require __DIR__ . '/guest_quote_with_addresses_product.php';
