/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            signifyd_sales_order_view: 'Signifyd_Connect/js/sales_order_view'
        }
    }
};
