/**
 * Copyright © 2021 MagestyApps. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    config: {
        mixins: {
            'Magento_Ui/js/form/element/image-uploader': {
                'MagestyApps_WebImages/js/form/element/image-uploader-mixin': true
            }
        }
    }
};
