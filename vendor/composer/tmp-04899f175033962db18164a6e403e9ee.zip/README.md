# Magento_OrderHistorySearch

The Magento_OrderHistorySearch module serves to handle advanced orders filtering on customer account.

## Installation details

...

## Structure

...

## Extensibility

...

### Layouts

...

### UI components

...

## Additional information

...
