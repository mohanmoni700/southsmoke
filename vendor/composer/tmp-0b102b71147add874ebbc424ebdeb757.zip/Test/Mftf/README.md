# Multiple Wishlist Functional Tests

The Functional Test Module for **Magento Multiple Wishlist** module.
