The Magento_MultipleWishlist module implements the multiple wishlists functionality.
These are lists of products from a store a customer would like to buy. Customers can save products to multiple wish lists and copy or move items from list to list.
