# Magento_LoginAsCustomerSales module

The Magento_LoginAsCustomerFrontendUi module provides UI for Storefront
