# Magento_AwsS3 module

The Magento_AwsS3 module integrates your Magento with the [AWS S3](https://aws.amazon.com/s3) storage.
