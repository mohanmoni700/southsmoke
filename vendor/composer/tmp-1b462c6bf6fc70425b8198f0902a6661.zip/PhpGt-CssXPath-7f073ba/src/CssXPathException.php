<?php
namespace Gt\CssXPath;

use RuntimeException;

class CssXPathException extends RuntimeException {}