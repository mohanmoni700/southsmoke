# Checkout Address Search Functional Tests

The Functional Test Module for **Magento Checkout Address Search** module.
