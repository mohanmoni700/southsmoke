# Change Log
## 20.7.0 (2018-06-25)
SHQ18-277 retain existing selectiosn on checkout selections object


## 20.8.0 (2019-03-14)
SHQ18-1651 Update dependencies in composer.json


## 20.9.0 (2019-11-20)
SHQ18-2869 Process rate response as array


## 20.9.1 (2021-01-07)
INFRA-208 updated composer json from uppercase to lowercase


## 20.9.2 (2021-02-23)
MNB-1003 Fix for rate shopped accessorials on LTL methods


## 20.9.3 (2021-04-22)
MNB-1204 Fix issue around date select requesting rates for all carriers and errors showing when shouldnt


## 20.9.4 (2021-11-02)
MNB-1797 Fix unit tests to work with Magento 2.3+


## 20.10.0 (2022-05-13)
MND-2430 M2.4.4 compatibility


