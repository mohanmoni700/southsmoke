<?php

declare(strict_types=1);

namespace Laminas\Stdlib;

class Request extends Message implements RequestInterface
{
    // generic request implementation
}
