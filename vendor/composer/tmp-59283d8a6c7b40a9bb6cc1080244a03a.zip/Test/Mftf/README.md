# Grouped Shared Catalog Functional Tests

The Functional Test Module for **Magento Grouped Shared Catalog** module.
