# Company Payment Functional Tests

The Functional Test Module for **Magento Company Payment** module.
