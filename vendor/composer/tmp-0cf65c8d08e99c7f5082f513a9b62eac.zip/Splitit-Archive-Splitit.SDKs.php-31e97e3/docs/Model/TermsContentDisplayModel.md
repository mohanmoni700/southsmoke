# TermsContentDisplayModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**\SplititSdkClient\Model\TermsContentType**](TermsContentType.md) |  | 
**translation_key** | **string** |  | [optional] 
**translation_category** | **string** |  | [optional] 
**translation_html_content** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


