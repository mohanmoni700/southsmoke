# SingleTermsModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**version** | **string** |  | [optional] 
**terms** | [**\SplititSdkClient\Model\TermsContentDisplayModel[]**](TermsContentDisplayModel.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


