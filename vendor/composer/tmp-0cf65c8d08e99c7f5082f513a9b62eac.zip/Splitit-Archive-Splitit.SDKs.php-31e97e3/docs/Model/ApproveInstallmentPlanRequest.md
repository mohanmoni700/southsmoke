# ApproveInstallmentPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installment_plan_number** | **string** |  | [optional] 
**customer_signature_png_as_base64** | **string** |  | [optional] 
**are_terms_and_conditions_approved** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


