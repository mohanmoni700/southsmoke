# CartData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**\SplititSdkClient\Model\ItemData[]**](ItemData.md) |  | [optional] 
**amount_details** | [**\SplititSdkClient\Model\AmountDetails**](AmountDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


