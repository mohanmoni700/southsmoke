# GetInstallmentsScheduleResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 
**schedules** | [**\SplititSdkClient\Model\Schedule[]**](Schedule.md) |  | [optional] 
**installments_picker** | **string** |  | [optional] 
**headline** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


