# AddressData2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_line** | **string** |  | [optional] 
**address_line2** | **string** |  | [optional] 
**city** | **string** |  | [optional] 
**country** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**zip** | **string** |  | [optional] 
**full_address_line** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


