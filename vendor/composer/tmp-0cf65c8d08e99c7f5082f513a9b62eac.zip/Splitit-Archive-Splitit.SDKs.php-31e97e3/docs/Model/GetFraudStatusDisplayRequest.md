# GetFraudStatusDisplayRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider_reference_id** | **string** |  | [optional] 
**merchant_id** | **int** |  | [optional] 
**installment_plan_number** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


