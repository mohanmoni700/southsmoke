# PaymentWizardData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requested_number_of_installments** | **string** |  | [optional] 
**success_exit_url** | **string** |  | [optional] 
**error_exit_url** | **string** |  | [optional] 
**cancel_exit_url** | **string** |  | [optional] 
**success_async_url** | **string** |  | [optional] 
**view_name** | **string** |  | [optional] 
**is_opened_in_iframe** | **bool** |  | 
**is3d_secure_in_popup** | **bool** |  | [optional] 
**payment_form_message** | **string** |  | [optional] 
**set_short_url** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


