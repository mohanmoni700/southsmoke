# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_code** | **string** |  | 
**message** | **string** |  | 
**additional_info** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


