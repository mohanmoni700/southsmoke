# Disputes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**in_dispute** | **bool** |  | [optional] 
**evidence_provided_on** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


