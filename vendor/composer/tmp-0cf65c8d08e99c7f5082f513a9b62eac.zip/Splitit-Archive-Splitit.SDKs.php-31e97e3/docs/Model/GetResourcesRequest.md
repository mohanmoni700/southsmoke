# GetResourcesRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**system_text_categories** | [**\SplititSdkClient\Model\SystemTextCategory[]**](SystemTextCategory.md) |  | [optional] 
**request_context** | [**\SplititSdkClient\Model\GetResourcesRequestContext**](GetResourcesRequestContext.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


