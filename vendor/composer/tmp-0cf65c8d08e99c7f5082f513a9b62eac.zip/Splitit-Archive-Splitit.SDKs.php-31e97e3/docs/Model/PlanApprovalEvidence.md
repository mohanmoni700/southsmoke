# PlanApprovalEvidence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer_signature_png_as_base64** | **string** |  | [optional] 
**are_terms_and_conditions_approved** | **bool** |  | 
**shopper_approval_date_time** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


