# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**unique_id** | **string** |  | [optional] 
**user_name** | **string** |  | [optional] 
**full_name** | **string** |  | [optional] 
**email** | **string** |  | [optional] 
**phone_number** | **string** |  | [optional] 
**culture_name** | **string** |  | [optional] 
**role_name** | **string** |  | [optional] 
**is_locked** | **bool** |  | 
**is_data_restricted** | **bool** |  | 
**is_data_private_restricted** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


