# GetResourcesRequestContext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchant_code** | **string** |  | [optional] 
**culture_name** | **string** |  | [optional] 
**touch_point_code** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


