# GetResourcesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logos** | **map[string,string]** |  | [optional] 
**touch_point_colors** | **map[string,string]** |  | [optional] 
**resources_grouped_by_categories** | [**map[string,map[string,string]]**](map.md) |  | [optional] 
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


