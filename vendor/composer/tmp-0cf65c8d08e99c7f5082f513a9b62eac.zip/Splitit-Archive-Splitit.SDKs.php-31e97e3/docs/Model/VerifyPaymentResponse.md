# VerifyPaymentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 
**is_paid** | **bool** |  | 
**original_amount_paid** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


