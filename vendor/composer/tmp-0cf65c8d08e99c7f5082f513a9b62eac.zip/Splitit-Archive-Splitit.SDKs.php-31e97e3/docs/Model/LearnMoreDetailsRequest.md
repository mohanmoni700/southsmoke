# LearnMoreDetailsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**\SplititSdkClient\Model\MoneyWithCurrencyCode**](MoneyWithCurrencyCode.md) |  | [optional] 
**number_of_installments** | **int** |  | [optional] 
**installment_plan_number** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


