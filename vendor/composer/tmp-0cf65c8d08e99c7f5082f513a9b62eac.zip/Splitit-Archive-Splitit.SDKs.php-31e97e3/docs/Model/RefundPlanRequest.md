# RefundPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installment_plan_number** | **string** |  | [optional] 
**amount** | [**\SplititSdkClient\Model\MoneyWithCurrencyCode**](MoneyWithCurrencyCode.md) |  | [optional] 
**refund_strategy** | [**\SplititSdkClient\Model\RefundStrategy**](RefundStrategy.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


