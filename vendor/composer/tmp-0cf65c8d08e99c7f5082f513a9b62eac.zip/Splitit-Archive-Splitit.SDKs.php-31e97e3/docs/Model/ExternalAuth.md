# ExternalAuth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unique_gateway_auth_id** | **string** |  | [optional] 
**date** | [**\DateTime**](\DateTime.md) |  | 
**amount** | [**\SplititSdkClient\Model\MoneyWithCurrencyCode**](MoneyWithCurrencyCode.md) |  | [optional] 
**transaction_full_log** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


