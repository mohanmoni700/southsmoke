# ChargebackRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_ids_to_mark** | **string[]** |  | [optional] 
**transaction_ids_to_unmark** | **string[]** |  | [optional] 
**installment_plan_number** | **string** |  | [optional] 
**partial_response_mapping** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


