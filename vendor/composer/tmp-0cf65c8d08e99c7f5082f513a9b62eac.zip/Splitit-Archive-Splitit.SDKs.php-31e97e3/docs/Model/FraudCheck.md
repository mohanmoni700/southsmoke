# FraudCheck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fraud_check_result** | [**\SplititSdkClient\Model\ReferenceEntityBase**](ReferenceEntityBase.md) |  | [optional] 
**provider_result_code** | **string** |  | [optional] 
**provider_result_desc** | **string** |  | [optional] 
**provider_reference_id** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


