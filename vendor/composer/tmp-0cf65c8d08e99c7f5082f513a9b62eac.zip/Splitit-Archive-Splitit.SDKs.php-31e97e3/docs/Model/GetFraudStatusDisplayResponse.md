# GetFraudStatusDisplayResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 
**provider** | **string** |  | [optional] 
**full_log** | **string** |  | [optional] 
**provider_result_description** | **string** |  | [optional] 
**installment_plan_id** | **int** |  | 
**provider_result_code** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


