# CancelInstallmentPlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installment_plan_number** | **string** |  | [optional] 
**refund_under_cancelation** | [**\SplititSdkClient\Model\RefundUnderCancelation**](RefundUnderCancelation.md) |  | 
**cancelation_reason** | [**\SplititSdkClient\Model\InstallmentPlanCancelationReason**](InstallmentPlanCancelationReason.md) |  | [optional] 
**partial_response_mapping** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


