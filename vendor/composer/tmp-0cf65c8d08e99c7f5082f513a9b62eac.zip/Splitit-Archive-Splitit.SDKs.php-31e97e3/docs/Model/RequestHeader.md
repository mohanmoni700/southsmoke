# RequestHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**touch_point** | [**\SplititSdkClient\Model\TouchPoint**](TouchPoint.md) |  | [optional] 
**session_id** | **string** |  | [optional] 
**api_key** | **string** |  | [optional] 
**culture_name** | **string** |  | [optional] 
**authentication_type** | [**\SplititSdkClient\Model\AuthenticationType**](AuthenticationType.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


