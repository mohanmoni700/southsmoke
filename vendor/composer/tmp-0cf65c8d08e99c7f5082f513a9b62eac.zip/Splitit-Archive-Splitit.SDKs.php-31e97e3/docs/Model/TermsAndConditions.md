# TermsAndConditions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agreement** | **string** |  | [optional] 
**important_note** | **string** |  | [optional] 
**full_content** | **string** |  | [optional] 
**privacy_policy** | **string** |  | [optional] 
**what_you_need_to_know_auth_hold_define** | **string** |  | [optional] 
**what_you_need_to_know_budget_management** | **string** |  | [optional] 
**what_you_need_to_know_card_type_details** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


