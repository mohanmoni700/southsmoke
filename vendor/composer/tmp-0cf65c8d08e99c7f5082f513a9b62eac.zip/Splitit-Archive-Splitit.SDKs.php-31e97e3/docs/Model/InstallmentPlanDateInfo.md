# InstallmentPlanDateInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installments_plan_date_type** | [**\SplititSdkClient\Model\InstallmentsPlanDateType**](InstallmentsPlanDateType.md) |  | 
**start_date** | **string** |  | [optional] 
**end_date** | **string** |  | [optional] 
**all_dates** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


