# CardData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card_id** | **string** |  | [optional] 
**card_number** | **string** |  | [optional] 
**card_exp_month** | **string** |  | [optional] 
**card_exp_year** | **string** |  | [optional] 
**card_brand** | [**\SplititSdkClient\Model\ReferenceEntityBase**](ReferenceEntityBase.md) |  | [optional] 
**card_type** | [**\SplititSdkClient\Model\ReferenceEntityBase**](ReferenceEntityBase.md) |  | [optional] 
**bin** | **string** |  | [optional] 
**card_holder_full_name** | **string** |  | [optional] 
**card_cvv** | **string** |  | [optional] 
**address** | [**\SplititSdkClient\Model\AddressData**](AddressData.md) |  | [optional] 
**token** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


