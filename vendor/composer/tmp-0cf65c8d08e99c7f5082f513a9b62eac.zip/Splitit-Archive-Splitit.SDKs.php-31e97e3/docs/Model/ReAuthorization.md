# ReAuthorization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processing_date** | [**\DateTime**](\DateTime.md) |  | [optional] 
**amount** | [**\SplititSdkClient\Model\Money**](Money.md) |  | [optional] 
**transaction_results** | [**\SplititSdkClient\Model\TransactionResult[]**](TransactionResult.md) |  | [optional] 
**card_details** | [**\SplititSdkClient\Model\CardData**](CardData.md) |  | [optional] 
**result** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


