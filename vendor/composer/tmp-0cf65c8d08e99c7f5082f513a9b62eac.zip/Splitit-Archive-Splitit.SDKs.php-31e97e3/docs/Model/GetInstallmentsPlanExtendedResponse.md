# GetInstallmentsPlanExtendedResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**plans_list** | [**\SplititSdkClient\Model\InstallmentPlan[]**](InstallmentPlan.md) |  | [optional] 
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 
**paging_response_header** | [**\SplititSdkClient\Model\PagingResponseHeader**](PagingResponseHeader.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


