# PaymentFormMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**\SplititSdkClient\Model\PaymentFormMessageType**](PaymentFormMessageType.md) |  | 
**code** | **int** |  | 
**message** | **string** |  | [optional] 
**is_empty** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


