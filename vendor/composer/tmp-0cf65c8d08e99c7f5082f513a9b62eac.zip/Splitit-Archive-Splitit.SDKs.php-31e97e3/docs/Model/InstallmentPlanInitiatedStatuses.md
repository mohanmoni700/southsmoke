# InstallmentPlanInitiatedStatuses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**show_initiated_plans_payment_request_sent** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


