# RefundInstallmentPlanResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_header** | [**\SplititSdkClient\Model\ResponseHeader**](ResponseHeader.md) |  | [optional] 
**installment_plan** | [**\SplititSdkClient\Model\InstallmentPlan**](InstallmentPlan.md) |  | [optional] 
**gateway_transaction_results** | [**\SplititSdkClient\Model\TransactionResult[]**](TransactionResult.md) |  | [optional] 
**current_refund_amount** | [**\SplititSdkClient\Model\Money**](Money.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


