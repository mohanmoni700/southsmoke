# LoginRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_name** | **string** |  | [optional] 
**password** | **string** |  | [optional] 
**touch_point** | [**\SplititSdkClient\Model\TouchPoint**](TouchPoint.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


