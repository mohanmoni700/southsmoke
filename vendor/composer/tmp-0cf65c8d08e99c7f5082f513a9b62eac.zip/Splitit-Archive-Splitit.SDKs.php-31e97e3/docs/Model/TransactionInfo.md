# TransactionInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_id** | **string** |  | [optional] 
**transaction_type** | [**\SplititSdkClient\Model\TransactionType**](TransactionType.md) |  | 
**transaction_status** | [**\SplititSdkClient\Model\TransactionStatus**](TransactionStatus.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


