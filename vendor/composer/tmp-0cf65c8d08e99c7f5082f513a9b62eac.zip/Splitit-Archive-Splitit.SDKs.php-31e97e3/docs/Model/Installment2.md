# Installment2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**\DateTime**](\DateTime.md) |  | [optional] 
**amount** | [**\SplititSdkClient\Model\MoneyWithCurrencyCode**](MoneyWithCurrencyCode.md) |  | [optional] 
**held_amount** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


