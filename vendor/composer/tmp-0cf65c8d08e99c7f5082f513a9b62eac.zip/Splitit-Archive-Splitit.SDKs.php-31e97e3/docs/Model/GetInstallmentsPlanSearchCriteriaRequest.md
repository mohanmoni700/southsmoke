# GetInstallmentsPlanSearchCriteriaRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query_criteria** | [**\SplititSdkClient\Model\InstallmentPlanQueryCriteria**](InstallmentPlanQueryCriteria.md) |  | [optional] 
**load_related** | [**\SplititSdkClient\Model\RelationsLoad**](RelationsLoad.md) |  | [optional] 
**paging_request** | [**\SplititSdkClient\Model\PagingRequestHeader**](PagingRequestHeader.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


