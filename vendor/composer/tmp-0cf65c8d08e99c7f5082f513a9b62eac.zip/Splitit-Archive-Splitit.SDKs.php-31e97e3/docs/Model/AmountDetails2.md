# AmountDetails2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sub_total** | **float** |  | 
**tax** | **float** |  | 
**shipping** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


