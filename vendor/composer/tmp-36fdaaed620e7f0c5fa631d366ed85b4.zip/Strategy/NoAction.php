<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Framework\ForeignKey\Strategy;

/**
 * @deprecated split database solution is deprecated and will be removed
 */
class NoAction extends Restrict
{

}
