#Magento_TargetRuleGraphQl 

Magento_TargetRuleGraphQl module provides the rules for showing related products.
