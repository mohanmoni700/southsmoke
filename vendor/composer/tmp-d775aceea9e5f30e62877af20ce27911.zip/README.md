The Versions CMS module adds a hierarchy feature for CMS pages.

The hierarchy feature organizes CMS pages as a hierarchy tree that allows parent/child relationships between pages.
