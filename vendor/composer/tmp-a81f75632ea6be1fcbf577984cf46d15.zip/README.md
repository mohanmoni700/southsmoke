# Magento_LoginAsCustomerLog module

The Magento_LoginAsCustomerLog module provides log for Login as Customer functionality
