<?php

namespace Laminas\EventManager\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
