<?php

namespace Laminas\EventManager\Exception;

/**
 * Base exception interface
 */
interface ExceptionInterface
{
}
