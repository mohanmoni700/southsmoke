# GiftCardAccountGraphQl

**GiftCardAccountGraphQl** provides type and resolver information for the GraphQl module
to generate giftcard acccount information.
