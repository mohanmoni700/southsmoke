## CheckoutAgreementsNegotiableQuote module Overview

CheckoutAgreementsNegotiableQuote module extends CheckoutAgreements if it is enabled in configuration and it adds agreements to payment data on checkout with negotiable quote.
