# Checkout Agreements Negotiable Quote Functional Tests

The Functional Test Module for **Magento Checkout Agreements Negotiable Quote** module.
