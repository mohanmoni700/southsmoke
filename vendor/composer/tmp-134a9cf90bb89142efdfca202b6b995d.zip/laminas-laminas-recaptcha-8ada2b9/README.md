# Laminas\ReCaptcha component

[![Build Status](https://github.com/laminas/laminas-recaptcha/workflows/Continuous%20Integration/badge.svg)](https://github.com/laminas/laminas-recaptcha/actions?query=workflow%3A"Continuous+Integration")

## Install

You can install using [Composer][1]:

```bash
$ composer require laminas/laminas-recaptcha
```

## Documentation

Documentation is on the Laminas website:

- [https://docs.laminas.dev/laminas-recaptcha][2]

[1]: https://getcomposer.org/download/
[2]: https://docs.laminas.dev/laminas-recaptcha
