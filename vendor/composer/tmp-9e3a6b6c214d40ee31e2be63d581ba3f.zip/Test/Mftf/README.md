# Bundle Negotiable Quote Functional Tests

The Functional Test Module for **Magento Bundle Negotiable Quote** module.
