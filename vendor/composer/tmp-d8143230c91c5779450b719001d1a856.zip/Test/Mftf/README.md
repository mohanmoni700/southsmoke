# Marketplace Functional Tests

The Functional Test Module for **Magento Marketplace** module.
