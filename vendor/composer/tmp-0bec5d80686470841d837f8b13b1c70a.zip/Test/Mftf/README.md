# Target Rule Functional Tests

The Functional Test Module for **Magento Target Rule** module.
