# Configurable Requisition List Functional Tests

The Functional Test Module for **Magento Configurable Requisition List** module.
