<?php

namespace Laminas\Validator\Exception;

interface ExceptionInterface
{
}
