<?php

namespace Laminas\Validator\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
