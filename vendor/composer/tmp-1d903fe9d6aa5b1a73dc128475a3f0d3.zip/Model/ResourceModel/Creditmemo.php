<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel;

use Magento\Sales\Model\ResourceModel\Order\Creditmemo as OriginalResourceModel;

/**
 * Class Creditmemo
 */
class Creditmemo extends OriginalResourceModel
{

}
