# Reward Graph Ql Functional Tests

The Functional Test Module for **Magento Reward Graph Ql** module.
