# RewardGraphQl

**RewardGraphQl** provides type information for the GraphQl module
to generate reward fields for customer information endpoints.
