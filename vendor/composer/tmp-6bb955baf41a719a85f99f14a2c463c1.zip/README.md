# RequisitionListGraphQl

**RequisitionListGraphQl** provides GraphQL schema and resolvers for the requisition list module.
to generate requisition list and requisition list items information endpoints.
