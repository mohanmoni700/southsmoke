Provides Magento\Framework\Jwt\JwtManagerInterface implementation based on jwt-framework.
