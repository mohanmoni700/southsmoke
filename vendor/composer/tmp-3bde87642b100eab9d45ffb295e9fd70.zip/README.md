# Magento_PageBuilderAdminAnalytics module

The Magento_PageBuilderAdminAnalytics module tracks Page Builder information through AdminAnalytics.

