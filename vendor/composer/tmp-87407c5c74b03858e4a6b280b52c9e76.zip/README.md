# VersionsCmsPageCache module

The Magento_VersionsCmsPageCache module provides adaptation to PageCache functionality
