# Magento_AwsS3GiftCardImportExport module

The Magento_AwsS3GiftCardImportExport module created for maintaining Gift Card Import/Export tests related to Aws S3 remote storage functionality
