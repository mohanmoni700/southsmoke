# Configurable Shared Catalog Functional Tests

The Functional Test Module for **Magento Configurable Shared Catalog** module.
