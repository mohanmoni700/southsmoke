Magento_CatalogPermissions feature allows to restrict the following permissions:
- Browse categories
- Display product prices
- Add to cart
- Catalog search
The permissions can be restricted for specific customer groups and guest users.
