# Scalable Checkout Functional Tests

The Functional Test Module for **Magento Scalable Checkout** module.
