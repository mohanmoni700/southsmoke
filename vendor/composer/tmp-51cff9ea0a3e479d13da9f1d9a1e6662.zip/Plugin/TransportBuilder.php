<?php
namespace RedChamps\EmailAttachmentHelper\Plugin;

use RedChamps\EmailAttachmentHelper\Model\EmailInfo;

class TransportBuilder
{

    private $emailInfo;

    public function __construct(
        EmailInfo $emailInfo
    ) {
        $this->emailInfo = $emailInfo;
    }

    public function beforeSetTemplateIdentifier(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        $templateIdentifier
    ) {
        $this->emailInfo->setTemplateIdentifier($templateIdentifier);
    }

    public function beforeSetTemplateVars(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        $templateVars
    ) {
        $this->emailInfo->setTemplateVars($templateVars);
    }

    public function aroundGetTransport(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        \Closure $proceed
    ) {
        $mailTransport = $proceed();
        $this->reset();
        return $mailTransport;
    }

    private function reset()
    {
        $this->emailInfo->setTemplateIdentifier(null);
        $this->emailInfo->setTemplateVars(null);
    }
}
