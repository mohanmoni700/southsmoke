<?php
namespace RedChamps\EmailAttachmentHelper\Plugin;

use RedChamps\EmailAttachmentHelper\Model\Api\MailProcessorInterface;
use RedChamps\EmailAttachmentHelper\Model\Api\AttachmentContainerInterface;
use RedChamps\EmailAttachmentHelper\Model\AttachmentContainerFactory;
use Magento\Framework\Mail\MimeMessageInterfaceFactory;
use RedChamps\EmailAttachmentHelper\Model\EmailEventDispatcher;

class MimeMessageFactory
{
    private $emailEventDispatcher;

    private $attachmentContainerFactory;

    private $mailProcessor;

    public function __construct(
        EmailEventDispatcher $emailEventDispatcher,
        AttachmentContainerFactory $attachmentContainer,
        MailProcessorInterface $mailProcessor
    ) {
        $this->emailEventDispatcher = $emailEventDispatcher;
        $this->attachmentContainerFactory = $attachmentContainer;
        $this->mailProcessor = $mailProcessor;
    }

    public function aroundCreate(
        MimeMessageInterfaceFactory $subject,
        \Closure $proceed,
        array $data = []
    ) {
        if (isset($data['parts'])) {
            $attachmentContainer = $this->attachmentContainerFactory->create();
            $this->emailEventDispatcher->dispatch($attachmentContainer);
            $data['parts'] = $this->attachIfNeeded($data['parts'], $attachmentContainer);
        }
        return $proceed($data);
    }

    public function attachIfNeeded($existingParts, AttachmentContainerInterface $attachmentContainer)
    {
        if (!$attachmentContainer->hasAttachments()) {
            return $existingParts;
        }
        return $this->mailProcessor->createMultipartMessage($existingParts, $attachmentContainer);
    }
}
