<?php
namespace RedChamps\EmailAttachmentHelper\Model;

use Magento\Framework\Event\ManagerInterface;

class EmailEventDispatcher
{
    /**
     * @var ManagerInterface
     */
    private $eventManager;

    /**
     * @var EmailInfo
     */
    private $emailInfo;


    public function __construct(
        ManagerInterface $eventManager,
        EmailInfo $emailInfo
    ) {
        $this->eventManager = $eventManager;
        $this->emailInfo = $emailInfo;
    }

    public function dispatch(Api\AttachmentContainerInterface $attachmentContainer)
    {
        if ($identifier = $this->emailInfo->getTemplateIdentifier()) {
            $this->eventManager->dispatch(
                'email_attachment_helper',
                [

                    'attachment_container' => $attachmentContainer,
                    'template_id' => $identifier,
                    'template_vars' => $this->emailInfo->getTemplateVars()
                ]
            );
        }
    }
}
