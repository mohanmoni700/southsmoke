<?php
declare(strict_types=1);

namespace RedChamps\EmailAttachmentHelper\Model\Api;

interface AttachmentInterface
{
    const ENCODING_BASE64          = 'base64';
    const DISPOSITION_ATTACHMENT   = 'attachment';

    public function getMimeType();

    public function getFilename($encoded = false);

    public function getDisposition();

    public function getEncoding();

    public function getContent();
}
