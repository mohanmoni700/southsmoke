<?php
namespace RedChamps\EmailAttachmentHelper\Model\Api;

interface AttachmentContainerInterface
{
    /**
     * @return bool
     */
    public function hasAttachments();

    /**
     * @param AttachmentInterface $attachment
     */
    public function addAttachment(AttachmentInterface $attachment);

    /**
     * @return AttachmentInterface[]
     */
    public function getAttachments();

    /**
     * @return void
     */
    public function resetAttachments();
}
