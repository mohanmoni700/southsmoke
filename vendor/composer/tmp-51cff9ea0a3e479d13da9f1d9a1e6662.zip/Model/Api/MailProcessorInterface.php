<?php
declare(strict_types=1);

namespace RedChamps\EmailAttachmentHelper\Model\Api;

interface MailProcessorInterface
{
    public function createMultipartMessage(
        array $existingParts,
        AttachmentContainerInterface $attachmentContainer
    );
}
