<?php
declare(strict_types=1);

namespace RedChamps\EmailAttachmentHelper\Model\Api;

interface PdfRendererInterface
{
    public function getPdfAsString(array $salesObjects);

    public function getFileName($input = '');

    public function canRender();
}
