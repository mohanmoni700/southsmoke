<?php
namespace RedChamps\EmailAttachmentHelper\Model;

class AttachmentContainer implements Api\AttachmentContainerInterface
{
    private $attachments = [];
    private $dedupIds = [];

    /**
     * @return bool
     */
    public function hasAttachments()
    {
        return !empty($this->attachments);
    }

    /**
     * @param Api\AttachmentInterface $attachment
     */
    public function addAttachment(Api\AttachmentInterface $attachment)
    {
        $dedupId = hash('sha256', $attachment->getFilename());
        if (!isset($this->dedupIds[$dedupId])) {
            $this->attachments[] = $attachment;
            $this->dedupIds[$dedupId] = true;
        }
    }

    /**
     * @return array
     */
    public function getAttachments()
    {
        return $this->attachments;
    }

    /**
     * @return void
     */
    public function resetAttachments()
    {
        $this->attachments = [];
        $this->dedupIds = [];
    }
}
