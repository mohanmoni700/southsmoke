<?php
use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'RedChamps_EmailAttachmentHelper',
    __DIR__
);

