<?php

declare(strict_types=1);

namespace Laminas\Di\Exception;

use LogicException as BaseLogicException;

class LogicException extends BaseLogicException implements ExceptionInterface
{
}
