<?php

namespace Klaviyo\Reclaim\Logger;

class Logger extends \Monolog\Logger
{
}
