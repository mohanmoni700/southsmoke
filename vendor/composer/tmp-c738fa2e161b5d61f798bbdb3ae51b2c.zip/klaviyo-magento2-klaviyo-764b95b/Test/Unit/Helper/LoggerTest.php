<?php

namespace Klaviyo\Reclaim\Test\Unit\Helper;

use PHPUnit\Framework\TestCase;

class LoggerTest extends TestCase
{
    /**
     * this class already has full coverage from testing performed for Reclaim.php
     */
}
