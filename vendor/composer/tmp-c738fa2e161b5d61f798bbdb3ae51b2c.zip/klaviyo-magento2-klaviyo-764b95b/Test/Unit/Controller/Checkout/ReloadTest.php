<?php

namespace Klaviyo\Reclaim\Test\Unit\Controller\Checkout;

use PHPUnit\Framework\TestCase;

class ReloadTest extends TestCase
{
}
