<?php

namespace Klaviyo\Reclaim\Test\Unit\Controller\Checkout;

use PHPUnit\Framework\TestCase;

class CartTest extends TestCase
{
}
