# Company Credit Functional Tests

The Functional Test Module for **Magento Company Credit** module.
