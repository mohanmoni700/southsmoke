<?php

namespace Laminas\Mime\Exception;

interface ExceptionInterface
{
}
