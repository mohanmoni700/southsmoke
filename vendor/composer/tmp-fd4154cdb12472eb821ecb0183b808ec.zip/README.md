# MultipleWishlistGraphQl

**MultipleWishlistGraphQl** provides type information regarding multiple wishlist functionality for the GraphQl module
