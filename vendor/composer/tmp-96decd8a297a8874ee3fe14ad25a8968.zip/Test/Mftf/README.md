# Admin Gws Configurable Product Functional Tests

The Functional Test Module for **Magento Admin Gws Configurable Product** module.
