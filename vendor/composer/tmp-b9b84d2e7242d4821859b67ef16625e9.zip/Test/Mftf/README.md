# Gift Card Shared Catalog Functional Tests

The Functional Test Module for **Magento Gift Card Shared Catalog** module.
