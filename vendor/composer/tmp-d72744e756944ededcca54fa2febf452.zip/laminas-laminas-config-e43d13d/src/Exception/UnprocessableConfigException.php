<?php

namespace Laminas\Config\Exception;

class UnprocessableConfigException extends RuntimeException
{
}
