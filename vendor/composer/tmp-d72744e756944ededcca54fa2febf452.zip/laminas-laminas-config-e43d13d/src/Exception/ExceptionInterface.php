<?php

namespace Laminas\Config\Exception;

interface ExceptionInterface
{
}
