<?php

namespace Laminas\Config\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
