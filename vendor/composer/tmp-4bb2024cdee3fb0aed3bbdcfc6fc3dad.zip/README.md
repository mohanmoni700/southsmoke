# GiftMessageGraphQl

**GiftMessageGraphQl** provides information about gift messages for carts, cart items, orders and order items.
