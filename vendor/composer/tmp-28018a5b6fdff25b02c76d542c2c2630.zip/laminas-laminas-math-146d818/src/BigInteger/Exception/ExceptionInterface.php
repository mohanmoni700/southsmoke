<?php

namespace Laminas\Math\BigInteger\Exception;

use Laminas\Math\Exception;

/**
 * Invalid argument exception
 */
interface ExceptionInterface extends Exception\ExceptionInterface
{
}
