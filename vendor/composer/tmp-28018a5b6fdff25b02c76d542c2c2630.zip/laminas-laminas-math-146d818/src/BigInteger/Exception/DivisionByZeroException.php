<?php

namespace Laminas\Math\BigInteger\Exception;

/**
 * Division by zero exception
 */
class DivisionByZeroException extends RuntimeException implements ExceptionInterface
{
}
