<?php

namespace Laminas\Math\BigInteger\Exception;

use Laminas\Math\Exception;

/**
 * Invalid argument exception
 */
class InvalidArgumentException extends Exception\InvalidArgumentException implements ExceptionInterface
{
}
