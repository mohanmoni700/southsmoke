<?php

namespace Laminas\Math\Exception;

/**
 * Invalid argument exception
 */
class InvalidArgumentException extends \InvalidArgumentException implements
    ExceptionInterface
{
}
