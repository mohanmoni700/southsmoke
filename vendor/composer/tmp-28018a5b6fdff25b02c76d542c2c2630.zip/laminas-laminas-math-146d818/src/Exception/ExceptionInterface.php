<?php

namespace Laminas\Math\Exception;

interface ExceptionInterface
{
}
