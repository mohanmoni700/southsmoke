AdvancedSalesRule module enhances the performance of sale rule processing.

