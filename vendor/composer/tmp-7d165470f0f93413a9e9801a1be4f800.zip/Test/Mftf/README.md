# Advanced Sales Rule Functional Tests

The Functional Test Module for **Magento Advanced Sales Rule** module.
