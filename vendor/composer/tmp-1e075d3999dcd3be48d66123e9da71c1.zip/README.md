AdvancedRule module enhances the performance of rule processing.

