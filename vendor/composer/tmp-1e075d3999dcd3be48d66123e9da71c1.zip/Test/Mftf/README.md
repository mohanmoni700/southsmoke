# Advanced Rule Functional Tests

The Functional Test Module for **Magento Advanced Rule** module.
