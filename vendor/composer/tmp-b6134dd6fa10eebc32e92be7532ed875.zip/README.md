# WishlistGiftCard

**WishlistGiftCard** provides the needed provider for adding a gift card product type to wish list.
