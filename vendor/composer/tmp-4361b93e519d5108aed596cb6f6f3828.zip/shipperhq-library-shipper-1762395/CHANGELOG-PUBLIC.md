## 20.3.3
SHQ16-2392 added comments and refactored unit tests, added tests for calendarDetails default date, M2-52 remove dependency on debug setting to enable logging


## 20.7.0 (2018-06-21)
Bring releases and versioning back in line


## 20.8.0 (2018-06-25)
SHQ18-277 refactor save selections functions to reuse selection object


## 20.9.0 (2018-08-02)
SHQ18-155 support map and location details for in store pickup


## 20.10.0 (2019-03-14)
SHQ18-1613 Display actual method chosen by rate shopping in admin panel


## 20.10.1 (2019-04-29)
SHQ18-1675 Added support for the new TimeSlotBreakDown field


## 20.11.0 (2019-06-12)
SHQ18-2107 Support for allowed methods for multiple API keys on one store


## 20.11.1 (2019-09-12)
SHQ18-2587/SHQ18-2613 Add price less fees to rates where available


## 20.12.0 (2019-11-20)
SHQ18-2869 Process rate response as array


## 20.12.1 (2019-12-10)
SHQ18-2990 Copy object to array function into library


## 20.12.2 (2020-02-26)
MNB-48 Support for storing rate shopped methods shipments as order comment


## 20.12.3 (2020-06-12)
MNB-422 Revalidate saved addresses that have invalid validation status


## 20.12.4 (2020-07-16)
MNB-484 Ensure default date in calendar uses timezone


## 20.13.0 (2020-08-20)
MNB-604 Add support for box comments for merged rates


## 20.14.0 (2021-03-29)
RIV-443 Add place order endpoint


## 20.14.1 (2021-06-07)
MNB-1251 Fix around handling no rates


## 20.14.2 (2021-07-08)
MNB-1227 Fix around promotional rules


## 20.14.3 (2021-07-30)
 MNB-1492 Ensure city is set in request on date or option change 


## 20.15.0 (2021-11-19)
RIV-687 Add freight quote ID to carrier group


## 20.16.0 (2022-05-13)
MND-2430 M2.4.4 compatibility


