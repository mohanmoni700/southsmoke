# GiftCardGraphQl

**GiftCardGraphQl** provides type and resolver information for the GraphQl module
to generate giftcard product information.
