The Magento\CustomerFinance module handles the import and export of the store credit and reward customer data.
It extends Magento_CustomerImportExport and joins the basic customer data with reward and customer balance information to enable to import/export of customer data with reward and store credit data.
