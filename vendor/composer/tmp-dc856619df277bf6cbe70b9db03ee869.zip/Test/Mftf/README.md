# Encryption Key Functional Tests

The Functional Test Module for **Magento Encryption Key** module.
