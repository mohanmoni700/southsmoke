# Negotiable Quote Shared Catalog Functional Tests

The Functional Test Module for **Magento Negotiable Quote Shared Catalog** module.
