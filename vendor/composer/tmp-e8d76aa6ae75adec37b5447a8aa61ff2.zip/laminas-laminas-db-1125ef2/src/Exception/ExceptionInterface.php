<?php

namespace Laminas\Db\Exception;

interface ExceptionInterface
{
}
