<?php

namespace Laminas\Db\Exception;

use Exception;

class ErrorException extends Exception implements ExceptionInterface
{
}
