<?php

namespace Laminas\Db\ResultSet\Exception;

use Laminas\Db\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
