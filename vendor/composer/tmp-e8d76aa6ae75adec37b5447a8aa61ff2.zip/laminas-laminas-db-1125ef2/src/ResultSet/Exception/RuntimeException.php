<?php

namespace Laminas\Db\ResultSet\Exception;

use Laminas\Db\Exception;

class RuntimeException extends Exception\RuntimeException implements ExceptionInterface
{
}
