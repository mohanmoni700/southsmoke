<?php

namespace Laminas\Db\Adapter\Exception;

use Laminas\Db\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
