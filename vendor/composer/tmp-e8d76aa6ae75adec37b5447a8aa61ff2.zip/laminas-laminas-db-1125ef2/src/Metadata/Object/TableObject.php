<?php

namespace Laminas\Db\Metadata\Object;

class TableObject extends AbstractTableObject
{
}
