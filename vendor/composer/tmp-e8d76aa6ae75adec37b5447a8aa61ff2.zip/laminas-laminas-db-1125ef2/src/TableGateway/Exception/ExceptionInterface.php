<?php

namespace Laminas\Db\TableGateway\Exception;

use Laminas\Db\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
