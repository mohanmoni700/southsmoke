<?php

namespace Laminas\Db\Sql\Exception;

use Laminas\Db\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
