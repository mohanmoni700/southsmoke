<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Datetime extends Column
{
    /** @var string */
    protected $type = 'DATETIME';
}
