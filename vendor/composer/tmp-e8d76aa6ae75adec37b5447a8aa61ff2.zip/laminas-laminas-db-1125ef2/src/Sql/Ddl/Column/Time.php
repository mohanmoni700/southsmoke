<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Time extends Column
{
    /** @var string */
    protected $type = 'TIME';
}
