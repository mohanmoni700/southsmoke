<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Varchar extends AbstractLengthColumn
{
    /** @var string */
    protected $type = 'VARCHAR';
}
