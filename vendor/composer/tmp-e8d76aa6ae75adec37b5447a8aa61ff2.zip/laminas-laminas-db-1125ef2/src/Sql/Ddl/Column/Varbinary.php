<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Varbinary extends AbstractLengthColumn
{
    /** @var string */
    protected $type = 'VARBINARY';
}
