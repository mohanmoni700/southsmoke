<?php

namespace Laminas\Session\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
