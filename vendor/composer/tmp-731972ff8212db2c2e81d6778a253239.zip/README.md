Magento_Newsletter module allows clients to subscribe for information about new promotions and discounts and allows store administrators to send newsletters to clients subscribed for them.
