# CheckoutAgreementsPurchaseOrder
**CheckoutAgreementsPurchaseOrder** allows properly use checkout agreements functionality with purchase order module
