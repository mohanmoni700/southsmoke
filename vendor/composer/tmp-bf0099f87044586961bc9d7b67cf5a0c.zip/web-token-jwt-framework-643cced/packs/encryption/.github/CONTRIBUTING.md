# Contributing

This repository is a sub repository of [the JWT Framework](https://github.com/web-token/jwt-framework) project and is READ ONLY. 
Please do not submit any Pull Requests here. It will be automatically closed.
