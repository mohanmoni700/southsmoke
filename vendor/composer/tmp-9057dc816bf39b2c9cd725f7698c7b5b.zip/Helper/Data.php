<?php
/**
 *
 * Created by:  Milan Simek
 * Company:     Plugin Company
 *
 * LICENSE: http://plugin.company/docs/magento-extensions/magento-extension-license-agreement
 *
 * YOU WILL ALSO FIND A PDF COPY OF THE LICENSE IN THE DOWNLOADED ZIP FILE
 *
 * FOR QUESTIONS AND SUPPORT
 * PLEASE DON'T HESITATE TO CONTACT US AT:
 *
 * SUPPORT@PLUGIN.COMPANY
 *
 */
namespace PluginCompany\CmsRevisions\Helper;

use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

class Data extends AbstractHelper
{

    /**
     * @var ProductMetadataInterface
     */
    private $productMetadata;

    public function __construct(
        Context $context,
        ProductMetadataInterface $productMetadata
    )
    {
        $this->productMetadata = $productMetadata;
        parent::__construct($context);
    }

    public function isPageBuilderActive()
    {
        return $this->scopeConfig->isSetFlag('cms/pagebuilder/enabled');
    }

    public function shouldExplicitlyEnableTemplateRendering()
    {
        return version_compare($this->productMetadata->getVersion(), '2.4.0', '>=');
    }

}
