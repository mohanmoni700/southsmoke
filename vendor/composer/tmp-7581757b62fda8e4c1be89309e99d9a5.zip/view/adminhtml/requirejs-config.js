/*
 * Copyright © 2020 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    map: {
        '*': {
            wyomind_uploader_plugin: 'Wyomind_MassStockUpdate/plugin/js/uploader',
            wyomind_MassImportAndUpdate_edit: 'Wyomind_MassStockUpdate/js/edit',
            wyomind_MassImportAndUpdate_cron: 'Wyomind_MassStockUpdate/js/cron',
            wyomind_MassImportAndUpdate_ftp: 'Wyomind_MassStockUpdate/js/ftp',
            wyomind_MassImportAndUpdate_mapping: 'Wyomind_MassStockUpdate/js/mapping',
            wyomind_MassImportAndUpdate_toolbox: 'Wyomind_MassStockUpdate/js/toolbox',
            wyomind_MassImportAndUpdate_profile: 'Wyomind_MassStockUpdate/js/profile',
            wyomind_MassImportAndUpdate_updater: 'Wyomind_MassStockUpdate/js/updater',
            wyomind_MassImportAndUpdate_report: 'Wyomind_MassStockUpdate/js/report',
            wyomind_MassImportAndUpdate_import: 'Wyomind_MassStockUpdate/js/import'
        }
    },
}; 