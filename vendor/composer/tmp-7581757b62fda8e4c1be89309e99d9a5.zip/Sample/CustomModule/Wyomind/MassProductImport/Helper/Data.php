<?php

namespace Wyomind\Custom\Wyomind\MassProductImport\Helper;

/**
 * Copyright © 2021 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

class Data //extends \Wyomind\MassProductImport\Helper\Data
{
    const ADDITIONAL_ATTR = [];
    /**
     *
     */
    const ADDITIONAL_FIELDS = [];
}
