<?php
/**
 * Copyright © 2021 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\Custom\Wyomind\MassStockUpdate\Helper;

class Data extends \Wyomind\MassStockUpdate\Helper\Data
{
    const ADDITIONAL_ATTR = [];
    /**
     *
     */
    const ADDITIONAL_FIELDS = [];
}
