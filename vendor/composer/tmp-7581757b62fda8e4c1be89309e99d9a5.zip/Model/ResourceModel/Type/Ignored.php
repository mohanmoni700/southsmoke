<?php
/**
 * Copyright © 2020 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\MassStockUpdate\Model\ResourceModel\Type;

/**
 * Class Ignored
 * @package Wyomind\MassStockUpdate\Model\ResourceModel\Type
 */
class Ignored extends \Wyomind\MassStockUpdate\Model\ResourceModel\Type\AbstractResource
{


}
