<?php

/**
 * JSONPath implementation for PHP.
 *

 */

/**
 * Copyright © 2020 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

declare(strict_types=1);

namespace Wyomind\MassStockUpdate\JSONPath\Filters;

use ArrayAccess;
use Wyomind\MassStockUpdate\JSONPath\JSONPath;
use Wyomind\MassStockUpdate\JSONPath\JSONPathToken;

/**
 * 
 */
abstract class AbstractFilter
{
    /**
     * @var JSONPathToken
     */
    protected $token;

    /**
     * @var  bool
     */
    protected $magicIsAllowed = false;

    /**
     * @param int|bool $options
     */
    public function __construct(JSONPathToken $token, $options = false)
    {
        $this->token = $token;
        $this->magicIsAllowed = (bool)($options & JSONPath::ALLOW_MAGIC);
    }

    /**
     * @param array|ArrayAccess $collection
     */
    abstract public function filter($collection): array;
}
