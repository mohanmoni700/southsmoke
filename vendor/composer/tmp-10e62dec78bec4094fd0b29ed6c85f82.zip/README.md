# StagingGraphQl

**StagingGraphQl** provides type information for the GraphQl module
to stage and preview entities.
