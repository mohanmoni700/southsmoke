# VersionsCmsUrlRewriteGraphQl

**VersionsCmsUrlRewriteGraphQl** provides type information for the GraphQl module to locate URL for Hierarchy Nodes features.
