# Magento_AwsS3ScheduledImportExport module

The Magento_AwsS3ScheduledImportExport module created for maintaining Scheduled Import/Export tests related to Aws S3 remote storage functionality
