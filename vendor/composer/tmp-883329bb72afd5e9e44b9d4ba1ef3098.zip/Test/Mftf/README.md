# Payment Staging Functional Tests

The Functional Test Module for **Magento Payment Staging** module.
