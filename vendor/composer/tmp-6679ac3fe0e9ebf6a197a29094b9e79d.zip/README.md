# GiftCardRequisitionListGraphQl

**GiftCardRequisitionListGraphQl** provides GraphQL schema and resolvers for the requisition list module to extend and implement gift card products in requisition list
