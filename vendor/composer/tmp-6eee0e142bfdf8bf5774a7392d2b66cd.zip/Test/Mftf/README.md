# Bundle Requisition List Functional Tests

The Functional Test Module for **Magento Bundle Requisition List** module.
