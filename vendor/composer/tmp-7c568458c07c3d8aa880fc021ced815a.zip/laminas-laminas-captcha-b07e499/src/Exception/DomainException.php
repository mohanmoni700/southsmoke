<?php

namespace Laminas\Captcha\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
