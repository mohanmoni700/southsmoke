<?php

namespace Laminas\Captcha\Exception;

/**
 * Exception for Laminas\Form component.
 */
interface ExceptionInterface
{
}
