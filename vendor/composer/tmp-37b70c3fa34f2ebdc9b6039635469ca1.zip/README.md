# CompanyGraphQl

Provides GraphQl mutations and queries to access company information.
