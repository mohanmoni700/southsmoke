# Company Functional Tests

The Functional Test Module for **Magento Company** module.
