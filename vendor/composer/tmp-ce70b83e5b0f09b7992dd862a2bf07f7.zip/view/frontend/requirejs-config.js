/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            uiB2bPaging:        'Magento_B2b/js/grid/paging/paging',
            uiB2bListing:       'Magento_B2b/js/grid/listing'
        }
    }
};
