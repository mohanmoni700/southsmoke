# B2b Functional Tests

The Functional Test Module for **Magento B2b** module.
