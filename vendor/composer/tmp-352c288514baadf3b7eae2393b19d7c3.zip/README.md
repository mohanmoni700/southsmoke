Magento\GiftWrapping module  provides functionality that allows customer to add gift wrapping to the items purchased
from the store as gifts and charge it individually. Magento\GiftWrapping module extends functionality of gift
messages by combining gift messages with gift wrapping functionality