# Scalable Oms Functional Tests

The Functional Test Module for **Magento Scalable Oms** module.
