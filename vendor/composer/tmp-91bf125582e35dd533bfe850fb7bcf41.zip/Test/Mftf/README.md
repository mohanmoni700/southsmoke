# Invitation Functional Tests

The Functional Test Module for **Magento Invitation** module.
