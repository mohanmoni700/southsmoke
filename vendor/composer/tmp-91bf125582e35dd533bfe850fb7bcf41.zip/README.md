The Magento_Invitation module enables invitation sending, referral tracking and generating invitation reports.
