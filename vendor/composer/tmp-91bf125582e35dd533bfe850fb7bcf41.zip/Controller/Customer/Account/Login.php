<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Invitation\Controller\Customer\Account;

use Magento\Invitation\Controller\Customer\AccountInterface;

class Login extends \Magento\Customer\Controller\Account\Login implements AccountInterface
{
}
