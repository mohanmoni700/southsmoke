# Catalog Url Rewrite Staging Functional Tests

The Functional Test Module for **Magento Catalog Url Rewrite Staging** module.
