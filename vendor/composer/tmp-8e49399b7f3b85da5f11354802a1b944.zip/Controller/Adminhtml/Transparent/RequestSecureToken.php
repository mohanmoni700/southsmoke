<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Paypal\Controller\Adminhtml\Transparent;

/**
 * Class RequestSecureToken
 *
 * @package Magento\Paypal\Controller\Adminhtml\Transparent
 */
class RequestSecureToken extends \Magento\Paypal\Controller\Transparent\RequestSecureToken
{

}
