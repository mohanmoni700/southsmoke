# Configurable Negotiable Quote Functional Tests

The Functional Test Module for **Magento Configurable Negotiable Quote** module.
