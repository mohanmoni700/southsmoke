<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

/**
 * Class ConfigurableProductsIgnored
 * @package Wyomind\MassProductImport\Model\ResourceModel\Type
 */
class ConfigurableProductsIgnored extends \Wyomind\MassProductImport\Model\ResourceModel\Type\Ignored
{


    /**
     * @param null $fieldset
     * @param null $form
     * @param null $class
     * @return bool
     */
    function getFields($fieldset = null, $form = null, $class = null)
    {
        return false;
    }
}
