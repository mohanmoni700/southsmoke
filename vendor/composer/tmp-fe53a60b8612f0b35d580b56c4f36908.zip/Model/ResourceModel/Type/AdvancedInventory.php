<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

/**
 * Class AdvancedInventory
 * @package Wyomind\MassProductImport\Model\ResourceModel\Type
 */
class AdvancedInventory extends \Wyomind\MassStockUpdate\Model\ResourceModel\Type\AdvancedInventory
{

    /**
     * @var string
     */
    public $module = "MassProductImport";
}
