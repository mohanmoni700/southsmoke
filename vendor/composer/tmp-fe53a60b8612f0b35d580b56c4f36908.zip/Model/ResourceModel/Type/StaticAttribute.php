<?php
/**
 * Copyright © 2019 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\Framework\Module\ModuleList;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Store\Model\WebsiteRepository;
use Wyomind\Framework\Helper\Module;
use Wyomind\MassProductImport\Helper\Data;
use Wyomind\MassSockUpdate\Model\ResourceModel\Profile;
use Wyomind\MassStockUpdate\Model\ResourceModel\Type\System;

/**
 *
 * @exclude_var e
 */
class StaticAttribute extends System
{
    /**
     * @var
     */
    public $fields;

    public $indexes = [
        1 => "catalogrule_rule",
        2 => "catalogrule_product"
    ];


    /**
     * @var array
     */
    public $attributeSet = [];

    /**
     * @var array
     */
    public $website = [];

    /**
     * @var CollectionFactory|null
     */
    public $_attributeSetCollectionFactory = null;

    /**
     * @var WebsiteRepository|null
     */
    public $_websiteRepository = null;

    /**
     * @var DateTime|null
     */
    public $_coreDate = null;

    /**
     * @var null|Data
     */
    public $_helperData = null;

    /**
     * @var array
     */
    public $removeQueries = [];

    /**
     * @var SearchCriteriaBuilder
     */
    public $searchCriteriaBuilder;

    /**
     * @var ObjectManager
     */
    public $objectManager;

    const WEBSITE_SEPARATOR = ",";


    /**
     * System constructor.
     * @param Context $context
     * @param Module $framework
     * @param Data $helperData
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory $entityAttributeCollection
     * @param CollectionFactory $attributeSetCollectionFactory
     * @param DateTime $coreDate
     * @param WebsiteRepository $websiteRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ModuleList $moduleList
     * @param ObjectManagerInterface $objectManager
     * @param null $connectionName
     */
    public function __construct(
        Context                                                             $context,
        Module                                                              $framework,
        Data                                                                $helperData,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory $entityAttributeCollection,
        CollectionFactory                                                   $attributeSetCollectionFactory,
        DateTime                                                            $coreDate,
        WebsiteRepository                                                   $websiteRepository,
        SearchCriteriaBuilder                                               $searchCriteriaBuilder,
        ModuleList                                                          $moduleList,
        ObjectManagerInterface                                              $objectManager,
        $connectionName = null
    ) {
    
        $this->_attributeSetCollectionFactory = $attributeSetCollectionFactory;
        $this->helperData = $helperData;
        $this->_websiteRepository = $websiteRepository;
        $this->_coreDate = $coreDate;
        $this->_framework = $framework;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->objectManager = $objectManager;
        parent::__construct($context, $framework, $helperData, $entityAttributeCollection, $moduleList, $objectManager, $connectionName);
    }

    /**
     * @throws FileSystemException
     * @throws InputException
     * @throws LocalizedException
     */
    public function _construct()
    {
        $this->table = $this->getTable("catalog_product_entity");
        $this->tableSequence = $this->getTable("sequence_product");
        $this->tableCpei = $this->getTable("catalog_product_entity_int");
        $this->tableCpev = $this->getTable("catalog_product_entity_varchar");
        $this->tableCpw = $this->getTable("catalog_product_website");
        $this->tableCsi = $this->getTable("cataloginventory_stock_item");
        $this->tableEa = $this->getTable("eav_attribute");
        $this->tableUr = $this->getTable("url_rewrite");

        $read = $this->getConnection();
        $tableEet = $this->getTable('eav_entity_type');
        $select = $read->select()->from($tableEet)->where('entity_type_code=\'catalog_product\'');
        $data = $read->fetchAll($select);
        $typeId = $data[0]['entity_type_id'];

        parent::_construct();
    }

    /**
     * @param Profile $profile
     * @param array $columns
     */
    public function beforeCollect($profile, $columns)
    {
        $indexes = [];

        foreach ($indexes as $key => $name) {
            $this->addIndex($key, $name);
        }
        parent::beforeCollect($profile, $columns);
    }

    /**
     * @param int $productId
     * @param Profile $profile
     * @return array|System
     */
    public function updatequeries($productId, $profile)
    {

        if (is_integer($productId)) {
            unset($this->removeQueries[$productId]);
        }
        $queryGroup = $this->removeQueries;
        $this->removeQueries = [];

        foreach ($queryGroup as $key => $queries) {
            if (is_array($queries)) {
                $this->removeQueries[$key] = implode("__BREAKLINE__", $queries);
            } else {
                $this->removeQueries[$key] = $queries;
            }
        }

        return parent::updatequeries($productId, $profile);
    }

    public function reset()
    {
        $this->fields = [];

    }

    public function resetGlobal()
    {
        $this->reset();
        $this->removeQueries = [];
    }


    public function collect($productId, $value, $strategy, $profile)
    {
        list($field) = $strategy['option'];

        $this->fields[$field] = $this->getValue($value);

        parent::collect($productId, $value, $strategy, $profile);
    }

    /**
     * @param int $productId
     * @param Profile $profile
     */
    public function prepareQueries($productId, $profile)
    {



        if (is_integer($productId)) {
            $update = [];
            foreach ($this->fields as $field => $value) {
                $update[] = "`" . $field . "` = '" . $value . "'";
            }
            if ($this->framework->moduleIsEnabled("Magento_Enterprise")) {
                $update[] = "`updated_in` = 2147483647";
            }
            $this->queries[$this->queryIndexer][] = "UPDATE `" . $this->table . "` SET \n"
                . implode(", \n", $update) . " \n WHERE `entity_id` = '$productId';";
        } else {
            // product should already be created
        }

        parent::prepareQueries($productId, $profile);
    }

    /**
     * @return string|void
     */
    public function afterCollect()
    {
        if (is_array($this->queries) && array_key_exists($this->queryIndexer, $this->queries)) {
            $this->queries[$this->queryIndexer] = array_merge($this->queries[$this->queryIndexer], $this->removeQueries);
        }

        parent::afterCollect();
    }

    /**
     * @return array
     * @throws InputException
     * @throws \Zend_Db_Statement_Exception
     */
    public function getDropdown()
    {
        /* IMAGES MAPPING */
        $dropdown = [];
        $fields = ["backend_type", "attribute_code"];
        $conditions = [
            ["eq" =>
                [
                    "static",
                ]
            ],
        ];


        $attributeCodes = [];
        $ignored = ['entity_id', 'sku', 'attribute_set_id', 'type_id', 'has_options', 'created_at', 'updated_at', 'required_options', 'created_by', 'updated_by'];
        $sql = "DESC " . $this->getTable("catalog_product_entity");
        $result = $this->getConnection()->query($sql);
        while ($row = ($result->fetch())) {
            if (!in_array($row['Field'], $ignored)) {
                $attributeCodes[] = $row['Field'];
            }
        }

        if (!empty($attributeCodes)) {
            $conditions[] = ['in' => [$attributeCodes]];
            $attributes = $this->getAttributesList($fields, $conditions);

            $i = 0;
            foreach ($attributes as $attribute) {
                $dropdown['Static Attributes'][$i]['label'] = $attribute['frontend_label'] ?? $attribute['attribute_code'];
                $dropdown['Static Attributes'][$i]["id"] = "StaticAttribute/" . $attribute['attribute_code'];
                $dropdown['Static Attributes'][$i]['style'] = "system";
                $dropdown['Static Attributes'][$i]['type'] = "text";
                $i++;
            }
        }



        return $dropdown;
    }

    /**
     * @param null $fieldset
     * @param bool $form
     * @param null $class
     * @return bool|null
     */
    public function getFields($fieldset = null, $form = false, $class = null)
    {


        return $fieldset;
    }

    /**
     * @param Profile $profile
     * @return array|bool
     */
    public function addModuleIf($profile)
    {
        $modules = ["System"];

        return $modules;
    }


    /**
     * @param array $mapping
     * @return array
     */
    public function getIndexes($mapping = [])
    {
        return $this->indexes;
    }

    /**
     * @param $key
     * @param $name
     */
    public function addIndex($key, $name)
    {
        $this->indexes[$key] = $name;
    }
}
