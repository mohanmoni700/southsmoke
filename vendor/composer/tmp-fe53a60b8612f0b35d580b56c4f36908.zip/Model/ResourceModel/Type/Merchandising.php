<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

/**
 * Class Merchandising
 * @package Wyomind\MassProductImport\Model\ResourceModel\Type
 */
class Merchandising extends \Wyomind\MassProductImport\Model\ResourceModel\Type\AbstractResource
{
    /**
     *
     */
    const FIELD_SEPARATOR = ",";

    /**
     * @var \Magento\Catalog\Api\ProductLinkTypeListInterface
     */
    public $productLinkTypeList;

    /**
     * Merchandising constructor.
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Wyomind\Framework\Helper\Module $framework
     * @param \Wyomind\MassStockUpdate\Helper\Data $helperData
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory $entityAttributeCollection
     * @param \Magento\Catalog\Api\ProductLinkTypeListInterface $productLinkTypeList
     * @param null $connectionName
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Wyomind\Framework\Helper\Module $framework,
        \Wyomind\MassStockUpdate\Helper\Data $helperData,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory $entityAttributeCollection,
        \Magento\Catalog\Api\ProductLinkTypeListInterface $productLinkTypeList,
        \Magento\Framework\Module\ModuleList $moduleList,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        $connectionName = null
    ) {
    
        $this->productLinkTypeList = $productLinkTypeList;
        parent::__construct($context, $framework, $helperData, $entityAttributeCollection, $moduleList, $objectManager, $connectionName);
    }

    /**
     *
     */
    public function _construct()
    {

        $this->tableCpe = $this->getTable("catalog_product_entity");
        $this->tableCplt = $this->getTable("catalog_product_link_type");
        $this->tableCpl = $this->getTable("catalog_product_link");
        $this->tableCpla = $this->getTable("catalog_product_link_attribute");
        $this->tableCplai = $this->getTable("catalog_product_link_attribute_int");
        parent::_construct();
    }

    /**
     * @param int $productId
     * @param string $value
     * @param array $strategy
     * @param \Wyomind\MassSockUpdate\Model\ResourceModel\Profile $profile
     */
    function collect($productId, $value, $strategy, $profile)
    {

        list($entityType) = $strategy['option'];

        if (empty($value) == false) {
            $skus = explode(self::FIELD_SEPARATOR, $value);
            // Delete old data
            // Insert new data
            if ($this->framework->moduleIsEnabled("Magento_Enterprise")) {
                $tableCpe = $this->getTable("catalog_product_entity");
                $productId = "(SELECT MAX(row_id) from $tableCpe where entity_id=$productId)";
            }

            $linkTypeId = " (SELECT link_type_id FROM `" . $this->tableCplt . "` WHERE code = '" . $entityType . "')";
            $productLinkAttributeId = "(SELECT product_link_attribute_id FROM " . $this->tableCpla . " WHERE product_link_attribute_code = 'position' AND link_type_id = " . $linkTypeId . ")";

            $this->queries[$this->queryIndexer][] = "DELETE FROM `" . $this->tableCpl . "` WHERE product_id=" . $productId . " AND link_type_id = " . $linkTypeId;

            $position = 0;
            foreach ($skus as $sku) {
                $this->queries[$this->queryIndexer][] = "INSERT IGNORE INTO " . $this->tableCpl . " (product_id, linked_product_id,link_type_id) "
                    . " VALUES ($productId, (SELECT entity_id FROM `" . $this->tableCpe . "` WHERE sku = '" . $sku . "'), (SELECT link_type_id FROM `" . $this->tableCplt . "` WHERE code = '" . $entityType . "'))\n ";
                $this->queries[$this->queryIndexer][] = "INSERT IGNORE INTO " . $this->tableCplai . " (product_link_attribute_id,link_id,value) VALUES(" . $productLinkAttributeId . ",LAST_INSERT_ID(),$position)";
                $position++;
            }
        }
        parent::collect($productId, $value, $strategy, $profile);
    }

    /**
     * @return array
     * @throws \Zend_Db_Statement_Exception
     */
    public function getDropdown()
    {

        $linkNames = $this->productLinkTypeList->getItems();
        foreach ($linkNames as $linkName) {
            $names[$linkName->getCode()] = $linkName->getName();
        }

        $i = 0;
        $dropdown = [];
        $links = $this->getConnection()->query("SELECT * FROM " . $this->tableCplt . " WHERE code<>'super'");
        foreach ($links->fetchAll() as $link) {
            $linkName = isset($names[$link["link_type_id"]]) ? __(ucwords($names[$link["link_type_id"]])) : 'Link ' . $i;

            $dropdown['Merchandising'][$i]['label'] = $linkName;
            $dropdown['Merchandising'][$i]["id"] = "Merchandising/" . $link["code"];
            $dropdown['Merchandising'][$i]['style'] = "merchandising";
            $dropdown['Merchandising'][$i]['type'] = "List of related product SKU's separated by " . self::FIELD_SEPARATOR;
            $dropdown['Merchandising'][$i]['value'] = "Sku ABC " . self::FIELD_SEPARATOR . " Sku XYZ " . self::FIELD_SEPARATOR . "...";
            $i++;
        }


        return $dropdown;
    }
}
