<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

class Msi extends \Wyomind\MassStockUpdate\Model\ResourceModel\Type\Msi
{

}
