<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

/**
 * Class AbstractResource
 * @package Wyomind\MassProductImport\Model\ResourceModel\Type
 */
class AbstractResource extends \Wyomind\MassStockUpdate\Model\ResourceModel\Type\AbstractResource
{
    
}
