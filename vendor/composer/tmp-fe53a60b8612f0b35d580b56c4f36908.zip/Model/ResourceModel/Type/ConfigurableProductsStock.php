<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

/**
 * Class ConfigurableProductsStock
 * @package Wyomind\MassProductImport\Model\ResourceModel\Type
 */
class ConfigurableProductsStock extends \Wyomind\MassProductImport\Model\ResourceModel\Type\Stock
{


    /**
     * @param null $fieldset
     * @param null $form
     * @param null $class
     * @return bool|null
     */
    function getFields($fieldset = null, $form = null, $class = null)
    {
        return false;
    }

    /**
     *
     */
    public function reset()
    {
        $this->fields = [];
        $this->qtyField = false;
    }

    /**
     * @param int $productId
     * @param \Wyomind\MassSockUpdate\Model\ResourceModel\Profile $profile
     * @return array|void
     */
    public function prepareQueries($productId, $profile)
    {
        $data = [];
        $data["product_id"] = $productId;
        $data["stock_id"] = "1";
        foreach ($this->fields as $field => $value) {
            $data[$field] = $this->getValue($value);
        }

        $this->queries[$this->queryIndexer][] = $this->createInsertOnDuplicateUpdate($this->table, $data);

        parent::prepareQueries($productId, $profile);
    }
}
