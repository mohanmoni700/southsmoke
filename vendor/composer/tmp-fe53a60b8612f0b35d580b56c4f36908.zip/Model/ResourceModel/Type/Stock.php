<?php

namespace Wyomind\MassProductImport\Model\ResourceModel\Type;

class Stock extends \Wyomind\MassStockUpdate\Model\ResourceModel\Type\Stock
{

}
