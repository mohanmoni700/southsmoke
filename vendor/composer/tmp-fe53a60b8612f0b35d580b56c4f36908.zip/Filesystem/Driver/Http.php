<?php
/**
 * Copyright © 2019 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\MassProductImport\Filesystem\Driver;

/**
 * Origin filesystem driver modified so that we can simply get the result code
 * of an url
 */
class Http extends \Wyomind\MassStockUpdate\Filesystem\Driver\Http
{
    
}
