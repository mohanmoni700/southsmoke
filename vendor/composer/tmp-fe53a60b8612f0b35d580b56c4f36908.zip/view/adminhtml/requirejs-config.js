/**
 * Copyright © 2019 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    map: {
        '*': {

            wyomind_MassImportAndUpdate_rules: 'Wyomind_MassProductImport/js/rules',

        }
    },
}; 