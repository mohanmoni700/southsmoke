<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Renderer;

class Datetime extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Renderer\Datetime
{

    public $module = "MassProductImport";
}
