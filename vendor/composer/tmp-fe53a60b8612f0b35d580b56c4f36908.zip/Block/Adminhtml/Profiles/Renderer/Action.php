<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Renderer;

class Action extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Renderer\Action
{

    public $module = "MassProductImport";
}
