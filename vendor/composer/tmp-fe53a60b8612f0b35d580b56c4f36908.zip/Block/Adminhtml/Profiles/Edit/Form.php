<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Edit;

class Form extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Edit\Form
{
    
}
