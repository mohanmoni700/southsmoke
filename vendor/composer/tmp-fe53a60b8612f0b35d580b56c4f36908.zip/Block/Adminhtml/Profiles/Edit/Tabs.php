<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Edit;

class Tabs extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Edit\Tabs
{
    
}
