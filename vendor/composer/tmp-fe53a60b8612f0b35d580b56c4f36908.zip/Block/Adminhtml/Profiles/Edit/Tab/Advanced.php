<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Edit\Tab;

class Advanced extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Edit\Tab\Advanced
{

    public $module = "MassProductImport";
}
