<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Edit\Tab;

class Cron extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Edit\Tab\Cron
{
    public $_module="massproductimport";
}
