<?php

namespace Wyomind\MassProductImport\Block\Adminhtml\Profiles\Edit\Tab;

class Main extends \Wyomind\MassStockUpdate\Block\Adminhtml\Profiles\Edit\Tab\Main
{

    public $module = "MassProductImport";
}
