<?php
/**
 * Copyright © 2019 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Report extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Report
{
    public $module = "MassProductImport";
}
