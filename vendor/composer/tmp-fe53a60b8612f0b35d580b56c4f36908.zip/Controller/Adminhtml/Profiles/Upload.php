<?php
/**
 * Copyright © 2019 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Upload extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Upload
{
    public $module = "MassProductImport";
}
