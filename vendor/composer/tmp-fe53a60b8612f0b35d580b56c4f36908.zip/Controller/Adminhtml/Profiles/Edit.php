<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Edit extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Edit
{

    public $name = "Mass Product Import & Update";
    public $module = "MassProductImport";
}
