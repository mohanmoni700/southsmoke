<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Preview extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Preview
{

    public $module = "MassProductImport";
}
