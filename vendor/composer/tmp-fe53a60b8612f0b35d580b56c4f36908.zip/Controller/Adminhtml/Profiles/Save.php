<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Save extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Save
{

    public $module = "MassProductImport";
}
