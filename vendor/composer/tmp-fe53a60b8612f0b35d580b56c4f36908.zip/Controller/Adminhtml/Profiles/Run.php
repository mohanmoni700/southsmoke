<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

/**
 * Full import process
 */
class Run extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Run
{

    public $module = "MassProductImport";
}
