<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class NewAction extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\NewAction
{

    public $module = "MassProductImport";
}
