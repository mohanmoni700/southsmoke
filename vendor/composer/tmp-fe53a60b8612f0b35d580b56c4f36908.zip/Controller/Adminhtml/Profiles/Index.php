<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Index extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Index
{

    public $name = "Mass Product Import & Update";
    public $module = "MassProductImport";
}
