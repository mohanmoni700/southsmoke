<?php

namespace Wyomind\MassProductImport\Controller\Adminhtml\Profiles;

class Library extends \Wyomind\MassStockUpdate\Controller\Adminhtml\Profiles\Library
{

    public $module = "MassProductImport";
}
