<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Wyomind\MassProductImport\Helper;

class Config extends \Wyomind\MassStockUpdate\Helper\Config
{

    const SETTINGS_LOG = "massproductimport/settings/log";
    const SETTINGS_NB_PREVIEW = "massproductimport/settings/nb_preview";
}
