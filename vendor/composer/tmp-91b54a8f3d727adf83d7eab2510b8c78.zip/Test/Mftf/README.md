# Scalable Inventory Functional Tests

The Functional Test Module for **Magento Scalable Inventory** module.
