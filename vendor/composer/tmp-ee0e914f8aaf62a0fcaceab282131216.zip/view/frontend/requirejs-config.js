/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            removePoints: 'Magento_Reward/js/action/remove-points'
        }
    }
};
