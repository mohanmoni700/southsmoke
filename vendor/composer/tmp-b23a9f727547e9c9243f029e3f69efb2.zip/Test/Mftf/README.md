# Bundle Shared Catalog Functional Tests

The Functional Test Module for **Magento Bundle Shared Catalog** module.
