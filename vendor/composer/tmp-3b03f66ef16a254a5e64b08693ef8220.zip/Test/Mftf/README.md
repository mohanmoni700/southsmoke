# Catalog Rule Configurable Functional Tests

The Functional Test Module for **Magento Catalog Rule Configurable** module.
