Magento_Reminder module provides functionality for sending reminder emails to customers according to pre-configured rules.
