<?php

namespace Splitit\PaymentGateway\Controller\Flexfields;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Json\Helper\Data;
use Magento\Quote\Api\CartRepositoryInterface;
use Psr\Log\LoggerInterface;
use Splitit\PaymentGateway\Model\InstallmentPlanApiObject;
use Splitit\PaymentGateway\Model\Log as LogModel;
use Splitit\PaymentGateway\Model\LogFactory as LogModelFactory;
use Splitit\PaymentGateway\Model\ResourceModel\Log as LogResource;
use SplititSdkClient\Model\AmountDetails;
use SplititSdkClient\Model\CartData;
use SplititSdkClient\Model\ItemData;
use SplititSdkClient\Model\MoneyWithCurrencyCode;
use Splitit\PaymentGateway\Gateway\Config\Config;
use Splitit\PaymentGateway\Block\UpstreamMessaging;

/**
 * TODO: make thin controller - move logic to model, create adminhtml controller, call model in front and admin controllers
 */
abstract class AbstractAction extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Config
     */
    protected $splititConfig;

    /**
     * @var UpstreamMessaging
     */
    protected $upstreamBlock;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var LogModelFactory
     */
    protected $logModelFactory;

    /**
     * @var LogResource
     */
    protected $logResource;

    /**
     * @var InstallmentPlanApiObject
     */
    protected $installmentPlanApiObject;

    /**
     * @var CartRepositoryInterface
     */
    private $quoteRepository;

    /**
     * @var null|\Magento\Quote\Model\Quote
     */
    private $currentQuote = null;

    /**
     * AbstractAction constructor.
     * @param Context $context
     * @param Data $jsonHelper
     * @param LoggerInterface $logger
     * @param Config $splititConfig
     * @param UpstreamMessaging $upstreamBlock
     * @param CheckoutSession $checkoutSession
     * @param LogModelFactory $logModelFactory
     * @param LogResource $logResource
     * @param InstallmentPlanApiObject $installmentPlanApiObject
     * @param CartRepositoryInterface $quoteRepository
     */
    public function __construct(
        Context $context,
        Data $jsonHelper,
        LoggerInterface $logger,
        Config $splititConfig,
        UpstreamMessaging $upstreamBlock,
        CheckoutSession $checkoutSession,
        LogModelFactory $logModelFactory,
        LogResource $logResource,
        InstallmentPlanApiObject $installmentPlanApiObject,
        CartRepositoryInterface $quoteRepository
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->logger = $logger;
        $this->splititConfig = $splititConfig;
        $this->upstreamBlock = $upstreamBlock;
        $this->logModelFactory = $logModelFactory;
        $this->logResource = $logResource;
        $this->checkoutSession = $checkoutSession;
        $this->installmentPlanApiObject = $installmentPlanApiObject;
        $this->quoteRepository = $quoteRepository;
        parent::__construct($context);
    }

    /**
     * Prepare request to API
     *
     * @param \SplititSdkClient\Model\InitiateInstallmentPlanRequest $initiateReq
     * @return \Magento\Framework\Controller\ResultInterface
     * @throws \SplititSdkClient\ApiException
     */
    public function makeRequest($initiateReq)
    {
        $installmentPlanApi = $this->installmentPlanApiObject->create();
        $initResp = $installmentPlanApi->installmentPlanInitiate($initiateReq);

        $success = $initResp->getResponseHeader()->getSucceeded();

        if ($success) {
            $fieldData = [
                "installmentPlan"        => $this->jsonHelper->jsonDecode($initResp->getInstallmentPlan()),
                "privacyPolicyUrl"       => $initResp->getPrivacyPolicyUrl(),
                "termsAndConditionsUrl"  => $initResp->getTermsAndConditionsUrl(),
                "approvalUrl"            => $initResp->getApprovalUrl(),
                "publicToken"            => $initResp->getPublicToken(),
                "checkoutUrl"            => $initResp->getCheckoutUrl(),
                "installmentPlanInfoUrl" => $initResp->getInstallmentPlanInfoUrl(),
            ];

            $this->createOrUpdateLog($fieldData['installmentPlan']['InstallmentPlanNumber']);
            $this->checkoutSession->setInstallmentPlanNumber($fieldData['installmentPlan']['InstallmentPlanNumber']);
            return $this->jsonResponse($fieldData);
        } else {
            $errorMessage = "Splitit Payment method not available currently. Please try again later.";
            $this->messageManager->addErrorMessage($errorMessage);
            return $this->jsonResponse($errorMessage);
        }
    }

    /**
     * Get installment range for amount
     *
     * @param float $amount
     * @return string
     */
    public function getInstallmentRangeForAmount($amount)
    {
        $installmentArray = $this->splititConfig->getInstallmentRange();
        $installmentRange = [];
        if (!empty($installmentArray)) {
            foreach ($installmentArray as $installmentArrayItem) {
                if ($amount >= $installmentArrayItem[0] && $amount <= $installmentArrayItem[1]) {
                    foreach ($installmentArrayItem[2] as $installmentNum) {
                        $installmentRange[] = $installmentNum;
                    }
                }
            }
        }

        return implode(',', array_unique($installmentRange));
    }

    /**
     * Get quote amount
     *
     * @return mixed
     */
    public function getAmount()
    {
        return $this->getRequest()->getParam('amount', $this->getCurrentQuote()->getBaseGrandTotal());
    }

    /**
     * Create or update log
     *
     * @param string $ipn
     */
    public function createOrUpdateLog($ipn)
    {
        $quoteId = $this->getCurrentQuoteId();
        /** @var LogModel $log */
        $log = $this->logResource->getByQuote($quoteId);
        if (!$log) {
            $log = $this->logModelFactory->create();
            $log->setQuoteId($quoteId);
        }
        $log->setInstallmentPlanNumber($ipn);
        try {
            $this->logResource->save($log);
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
        }
    }

    /**
     * Create json response
     *
     * @param string $response
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }

    /**
     * Prepare cart data
     *
     * @return CartData
     */
    public function prepareCartData()
    {
        $quote = $this->getCurrentQuote();
        $currencyCode = $this->upstreamBlock->getCurrentCurrencyCode();

        $items = [];
        $quoteItems = $quote->getItemsCollection();
        foreach ($quoteItems as $quoteItem) {
            /** @var \Magento\Quote\Model\Quote\Item $quoteItem */
            $items[] = new ItemData([
                'name' => $quoteItem->getName(),
                'sku' => $quoteItem->getSku(),
                'price' => new MoneyWithCurrencyCode([
                    "value" => $quoteItem->getPrice(),
                    "currency_code" => $currencyCode
                ]),
                'quantity' => $quoteItem->getQty(),
                'description' => $quoteItem->getDescription(),
            ]);
        }

        if ($quote->getIsVirtual()) {
            $taxAmount = $quote->getBillingAddress()->getTaxAmount();
            $shippingAmount = 0;
        } else {
            $taxAmount = $quote->getShippingAddress()->getTaxAmount();
            $shippingAmount = $quote->getShippingAddress()->getShippingAmount();
        }

        $amountDetails = new AmountDetails([
            'sub_total' => $quote->getSubtotal(),
            'tax' => $taxAmount,
            'shipping' => $shippingAmount
        ]);

        return new CartData([
            'items' => $items,
            'amount_details' => $amountDetails
        ]);
    }

    /**
     * Get current quote id
     *
     * @return int
     */
    public function getCurrentQuoteId()
    {
        $quoteId = $this->getRequest()->getParam('quoteId');
        return $quoteId ? $quoteId : $this->checkoutSession->getQuoteId();
    }

    /**
     * Get current quote
     *
     * @return \Magento\Quote\Model\Quote|\Magento\Quote\Api\Data\CartInterface
     * @return \Magento\Quote\Api\Data\CartInterface|\Magento\Quote\Model\Quote|null
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentQuote()
    {
        if ($this->currentQuote === null) {
            $quote = $this->loadQuoteById();
            $this->currentQuote = $quote ? $quote : $this->checkoutSession->getQuote();
        }

        return $this->currentQuote;
    }

    /**
     * Load quote by id
     *
     * @return \Magento\Quote\Api\Data\CartInterface|null
     */
    private function loadQuoteById()
    {
        $quote = null;

        $quoteId = $this->getRequest()->getParam('quoteId');
        if ($quoteId) {
            try {
                $quote = $this->quoteRepository->get($quoteId);
            } catch (\Exception $e) {
                $quote = null;
            }
        }

        return $quote;
    }
}
