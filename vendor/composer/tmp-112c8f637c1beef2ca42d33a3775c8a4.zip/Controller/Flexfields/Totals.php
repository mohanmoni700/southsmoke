<?php

namespace Splitit\PaymentGateway\Controller\Flexfields;

use Magento\Framework\Exception\LocalizedException;
use SplititSdkClient\Model\PlanData;
use SplititSdkClient\Model\PaymentWizardData;
use SplititSdkClient\Model\MoneyWithCurrencyCode;
use SplititSdkClient\Model\InitiateInstallmentPlanRequest;

class Totals extends AbstractAction
{
    /**
     * TODO : Inject InitiateInstallmentPlanRequest, PlanData, PaymentWizardData, AddressData, CustomerData
     * TODO : Abstract MoneyWithCurrencyCode, InstallmentPlanApi . Return the object using abstracted model.
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        try {
            $amount = $this->getAmount();
            $currencyCode = $this->upstreamBlock->getCurrentCurrencyCode();

            $curInstallmentPlanNumber = $this->checkoutSession->getInstallmentPlanNumber() ?
                $this->checkoutSession->getInstallmentPlanNumber() :
                $this->getRequest()->getParam('installments_plan_number');

            $planData = new PlanData();
            $planData->setAmount(new MoneyWithCurrencyCode(["value" => $amount, "currency_code" => $currencyCode]));

            $paymentWizard = $this->preparePaymentWizardData();

            $initiateReq = new InitiateInstallmentPlanRequest();
            $initiateReq->setPlanData($planData)
                ->setPaymentWizardData($paymentWizard)
                ->setInstallmentPlanNumber($curInstallmentPlanNumber);

            $cartData = $this->prepareCartData();
            $initiateReq->setCartData($cartData);

            return $this->makeRequest($initiateReq);
        } catch (LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            $this->logger->critical($e);
            return $this->jsonResponse($e->getMessage());
        }
    }

    /**
     * Prepare payment wizard data
     *
     * @return PaymentWizardData
     */
    private function preparePaymentWizardData()
    {
        $paymentWizard = new PaymentWizardData();

        $successAsyncUrl = $this->_url->getUrl('splititpaymentgateway/payment/successasync');
        $paymentWizard->setSuccessAsyncUrl($successAsyncUrl);

        $amount = $this->getAmount();
        $installmentRange = $this->getInstallmentRangeForAmount($amount);
        if (!empty($installmentRange)) {
            $paymentWizard->setRequestedNumberOfInstallments($installmentRange);
        }

        $paymentWizard->setIsOpenedInIframe(true);

        return $paymentWizard;
    }
}
