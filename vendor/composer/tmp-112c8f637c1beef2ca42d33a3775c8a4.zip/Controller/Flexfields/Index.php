<?php

namespace Splitit\PaymentGateway\Controller\Flexfields;

use Magento\Framework\Exception\LocalizedException;
use SplititSdkClient\Model\PlanData;
use SplititSdkClient\Model\ConsumerData;
use SplititSdkClient\Model\AddressData;
use SplititSdkClient\Model\PaymentWizardData;
use SplititSdkClient\Model\MoneyWithCurrencyCode;
use SplititSdkClient\Model\InitiateInstallmentPlanRequest;

class Index extends AbstractAction
{
    /**
     * Init Splitit plan
     *
     * TODO : Inject InitiateInstallmentPlanRequest, PlanData, PaymentWizardData, AddressData, CustomerData
     * TODO : Abstract MoneyWithCurrencyCode, InstallmentPlanApi . Return the object using abstracted model.
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        try {
            $initiateReq = new InitiateInstallmentPlanRequest();

            $curInstallmentPlanNumber = $this->getCurrentInstallmentPlanNumber();
            if ($curInstallmentPlanNumber) {
                $initiateReq->setInstallmentPlanNumber($curInstallmentPlanNumber);
            }

            $paymentWizard = $this->preparePaymentWizardData();
            $initiateReq->setPaymentWizardData($paymentWizard);

            $planData = $this->preparePlanData();
            $initiateReq->setPlanData($planData);

            $consumerData = $this->prepareConsumerData();
            if ($this->isConsumerDataValid($consumerData)) {
                $initiateReq->setConsumerData($consumerData);
            }

            $billingAddress = $this->getBillingAddress();
            if ($this->isBillingAddressValid($billingAddress)) {
                $initiateReq->setBillingAddress($billingAddress);
            }

            $cartData = $this->prepareCartData();
            $initiateReq->setCartData($cartData);

            return $this->makeRequest($initiateReq);
        } catch (LocalizedException $e) {
            $this->checkoutSession->setInstallmentPlanNumber(null);
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            $this->checkoutSession->setInstallmentPlanNumber(null);
            $this->logger->critical($e);
            return $this->jsonResponse($e->getMessage());
        }
    }

    /**
     * Get customer name
     *
     * @return string
     */
    protected function getCustomerName()
    {
        $sessionBillingAddress = $this->getCurrentQuote()->getBillingAddress();
        $sessionShippingAddress = $this->getCurrentQuote()->getShippingAddress();
        return $sessionBillingAddress->getName()
            ? $sessionBillingAddress->getName()
            : $sessionShippingAddress->getName();
    }

    /**
     * Get telephone
     *
     * @return string
     */
    protected function getTelephone()
    {
        $sessionBillingAddress = $this->getCurrentQuote()->getBillingAddress();
        $sessionShippingAddress = $this->getCurrentQuote()->getShippingAddress();
        return $sessionBillingAddress->getTelephone()
            ? $sessionBillingAddress->getTelephone()
            : $sessionShippingAddress->getTelephone();
    }

    /**
     * Get billing address
     *
     * @return AddressData
     * @throws LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getBillingAddress()
    {
        $sessionBillingAddress = $this->getCurrentQuote()->getBillingAddress();

        $street1 = $sessionBillingAddress->getStreetLine(1);
        $street2 = $sessionBillingAddress->getStreetLine(2);
        $city = $sessionBillingAddress->getCity();
        $region = $sessionBillingAddress->getRegion();
        $country = $sessionBillingAddress->getCountry();
        $postcode = $sessionBillingAddress->getPostcode();

        return new AddressData([
            "address_line" => $this->getAddressValue('AddressLine', $street1),
            "address_line2" => $this->getAddressValue('AddressLine2', $street2),
            "city" => $this->getAddressValue('City', $city),
            "state" => $this->getAddressValue('State', $region),
            "country" => $this->getAddressValue('Country', $country),
            "zip" => $this->getAddressValue('Zip', $postcode)
        ]);
    }

    /**
     * Check is value exists and get default value if does not exists
     *
     * @param string $fieldName
     * @param string $defaultValue
     * @return mixed
     */
    private function getAddressValue($fieldName, $defaultValue)
    {
        $address = $this->getRequest()->getParam('billingAddress', []);
        return (isset($address[$fieldName]) && !empty($address[$fieldName]))
            ? $address[$fieldName]
            : $defaultValue;
    }

    /**
     * Check is consumer data valid
     *
     * @param ConsumerData $obj
     * @return bool
     */
    protected function isConsumerDataValid($obj)
    {
        return $obj->getEmail() && $obj->getFullName() && $obj->getPhoneNumber();
    }

    /**
     * Check is billing address data valid
     *
     * @param AddressData $address
     * @return bool
     */
    protected function isBillingAddressValid($address)
    {
        return $address->getCity() && $address->getCountry() && $address->getAddressLine() && $address->getZip();
    }

    /**
     * Get current installment plan number
     *
     * @return string|null
     */
    private function getCurrentInstallmentPlanNumber()
    {
        $curInstallmentPlanNumber = $this->checkoutSession->getInstallmentPlanNumber() ?
            $this->checkoutSession->getInstallmentPlanNumber() :
            $this->getRequest()->getParam('installments_plan_number');

        $log = $this->logResource->getByIPN($curInstallmentPlanNumber);
        if ($log && $log->getId() && $log->isSuccess()) {
            $this->checkoutSession->setInstallmentPlanNumber(null);
            $curInstallmentPlanNumber = null;
        }

        return $curInstallmentPlanNumber;
    }

    /**
     * Prepare payment wizard data
     *
     * @return PaymentWizardData
     */
    private function preparePaymentWizardData()
    {
        $paymentWizard = new PaymentWizardData();
        $successAsyncUrl = $this->_url->getUrl('splititpaymentgateway/payment/successasync');
        $paymentWizard->setSuccessAsyncUrl($successAsyncUrl);

        $amount = $this->getAmount();
        $installmentRange = $this->getInstallmentRangeForAmount($amount);
        if (!empty($installmentRange)) {
            $paymentWizard->setRequestedNumberOfInstallments($installmentRange);
        }

        $paymentWizard->setIsOpenedInIframe(true);

        return $paymentWizard;
    }

    /**
     * Prepare plan data
     *
     * @return PlanData
     */
    private function preparePlanData()
    {
        $amount = $this->getAmount();
        $currencyCode = $this->upstreamBlock->getCurrentCurrencyCode();

        $planData = new PlanData();

        $planData->setNumberOfInstallments($this->getRequest()->getParam('numInstallments'));
        $planData->setAmount(new MoneyWithCurrencyCode(["value" => $amount, "currency_code" => $currencyCode]));
        $planData->setAutoCapture(false);
        $planData->setRefOrderNumber($this->getCurrentQuoteId());
        $is3dSecureEnabled = $this->splititConfig->get3DSecure();
        $planData->setAttempt3DSecure($is3dSecureEnabled);

        return $planData;
    }

    /**
     * Prepare consumer data
     *
     * @return ConsumerData
     */
    private function prepareConsumerData()
    {
        $cultureName = strtolower(str_replace('_', '-', $this->upstreamBlock->getCultureName()));
        if ($cultureName == null) {
            $cultureName = 'en-us';
        }

        $consumer = $this->getRequest()->getParam('consumerModel');
        return new ConsumerData([
            "full_name" => $consumer['FullName'] ?? $this->getCustomerName(),
            "email" => $consumer['Email'] ?? $this->getCurrentQuote()->getCustomerEmail(),
            "phone_number" => $consumer['PhoneNumber'] ?? $this->getTelephone(),
            "culture_name" => $cultureName,
            "is_locked" => false,
            "is_data_restricted" => false
        ]);
    }
}
