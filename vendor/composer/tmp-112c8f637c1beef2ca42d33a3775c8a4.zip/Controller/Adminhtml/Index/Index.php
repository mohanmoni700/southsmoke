<?php

namespace Splitit\PaymentGateway\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Splitit\PaymentGateway\Model\InstallmentPlanApiObject;
use Splitit\PaymentGateway\Gateway\Login\LoginAuthentication;
use SplititSdkClient\Model\CancelInstallmentPlanRequest;
use Splitit\PaymentGateway\Gateway\Config\Config;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Framework\App\Request\Http;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;

class Index extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var OrderManagementInterface
     */
    protected $orderManagement;

    /**
     * @var Http
     */
    protected $request;

    /**
     * @var LoginAuthentication
     */
    protected $loginAuth;

    /**
     * @var Config
     */
    protected $splititConfig;

    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @var InstallmentPlanApiObject
     */
    private $installmentPlanApiObject;

    /**
     * Index constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param OrderManagementInterface $orderManagement
     * @param Http $request
     * @param LoginAuthentication $loginAuth
     * @param Config $splititConfig
     * @param OrderRepositoryInterface $orderRepository
     * @param InstallmentPlanApiObject $installmentPlanApiObject
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        OrderManagementInterface $orderManagement,
        Http $request,
        LoginAuthentication $loginAuth,
        Config $splititConfig,
        OrderRepositoryInterface $orderRepository,
        InstallmentPlanApiObject $installmentPlanApiObject
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->orderManagement = $orderManagement;
        $this->request = $request;
        $this->loginAuth = $loginAuth;
        $this->splititConfig = $splititConfig;
        $this->orderRepository = $orderRepository;
        $this->installmentPlanApiObject = $installmentPlanApiObject;
        parent::__construct($context);
    }

    /**
     * TODO : Inject InstallmentPlanApi, CancelInstallmentPlanRequest
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $params = $this->request->getParams();

        $cancelRequest = new CancelInstallmentPlanRequest();
        $cancelRequest->setInstallmentPlanNumber($params['txnId']);
        $cancelRequest->setRefundUnderCancelation("NoRefunds");

        try {
            $apiInstance = $this->installmentPlanApiObject->create();
            $apiInstance->installmentPlanCancel($cancelRequest);
            $this->orderManagement->cancel($params['orderId']);
            $order = $this->orderRepository->get($params['orderId']);
            $order->setState(Order::STATE_CANCELED);
            $order->setStatus(Order::STATE_CANCELED);
            $order->addStatusToHistory($order->getStatus(), __('Order cancelled without issuing refund.'));
            $order->save();
            $this->messageManager->addSuccessMessage(__('Order has been cancelled without issuing refund'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('sales/order/view', ['order_id' => $params['orderId']]);
    }

    /**
     * @inheritDoc
     */
    protected function _isAllowed()
    {
        return true;
    }
}
