<?php

namespace Splitit\PaymentGateway\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\Model\Session\Quote;
use Magento\Framework\Json\Helper\Data;
use Magento\Backend\App\Action\Context;

class Quoteid extends Action
{
    /**
     * @var Quote
     */
    private $quote;

    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * @param Context $context
     * @param Quote $quote
     * @param Data $jsonHelper
     */
    public function __construct(
        Context $context,
        Quote $quote,
        Data $jsonHelper
    ) {
        $this->quote = $quote;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    /**
     * Get quote ID action
     *
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode([
                'quoteId' => $this->quote->getQuoteId()
            ])
        );
    }

    /**
     * @inheritDoc
     */
    protected function _isAllowed()
    {
        return true;
    }
}
