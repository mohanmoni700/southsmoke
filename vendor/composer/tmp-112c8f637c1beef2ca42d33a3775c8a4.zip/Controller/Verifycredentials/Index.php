<?php

namespace Splitit\PaymentGateway\Controller\Verifycredentials;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Splitit\PaymentGateway\Gateway\Config\Config;
use Splitit\PaymentGateway\Model\ValidateApiCredentials;
use Psr\Log\LoggerInterface;

class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var ValidateApiCredentials
     */
    private $validateApiCredentials;

    /**
     * @var Config
     */
    private $splititConfig;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Splitit\PaymentGateway\Model\ValidateApiCredentials $validateApiCredentials
     * @param \Splitit\PaymentGateway\Gateway\Config\Config $splititConfig
     */
    public function __construct(
        Context $context,
        LoggerInterface $logger,
        ValidateApiCredentials $validateApiCredentials,
        Config $splititConfig
    ) {
        $this->logger = $logger;
        $this->validateApiCredentials = $validateApiCredentials;
        $this->splititConfig = $splititConfig;
        parent::__construct($context);
    }

    /**
     * Verify credentials
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $username = $this->splititConfig->getApiUsername();
        $password = $this->splititConfig->getApiPassword();
        $apiKey = $this->splititConfig->getApiMerchantId();
        $envSelected = $this->splititConfig->getEnvironment();

        $this->validateApiCredentials->validate($username, $password, $apiKey, $envSelected);

        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData([
            "status" => $this->validateApiCredentials->isValid(),
            "errorMessage" => $this->validateApiCredentials->getErrorMessage(),
            "successMessage" => $this->validateApiCredentials->getSuccessMessage(),
        ]);

        return $resultJson;
    }
}
