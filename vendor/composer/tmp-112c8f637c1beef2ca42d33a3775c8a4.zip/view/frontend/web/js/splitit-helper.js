define([
    'jquery',
    'underscore',
    'Magento_Catalog/js/price-utils',
    'Magento_Checkout/js/model/quote'
], function ($, _, priceUtils, totals) {
    'use strict';

    function getGrandTotal() {
        /* Magneto issue - https://github.com/magento/magento2/issues/34649. Let's try to read final price from summary */
        var grandTotalcontainer = $('.grand .price');
        if (grandTotalcontainer.length && typeof grandTotalcontainer[0].firstChild !== undefined && grandTotalcontainer[0].firstChild !== null) {
            var priceHtml = grandTotalcontainer[0]['firstChild']['data'];
            return parsePriceHtmlToFloat(priceHtml);
        }

        return quote.getTotals()().grand_total.toFixed(2);
    }

    return {
        parsePriceHtmlToFloat: parsePriceHtmlToFloat,
        updatePriceFormatForUpstreamMessage: updatePriceFormatForUpstreamMessage,
        getGrandTotal: getGrandTotal,
        getSplititNumInstallments: getSplititNumInstallments
    };
});
