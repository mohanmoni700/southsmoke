define([
    'jquery',
    'uiComponent',
    'Magento_Checkout/js/model/quote',
    'Splitit_PaymentGateway/js/helper/general',
    'Splitit_PaymentGateway/js/helper/totals',
    'Magento_Ui/js/lib/view/utils/async',
    'domReady!'
], function ($, Component, quote, splititHelper, totals) {
    'use strict';
    return Component.extend({
        isEnabledOnCheckoutPage: function () {
            return window.checkoutConfig.payment.splitit_payment && window.checkoutConfig.payment.splitit_payment.isUpstreamMessageEnabled;
        },
        getGrandTotal: function () {
            return totals.getGrandTotal();
        },
        getSplititNumInstallments: function () {
            return splititHelper.getSplititNumInstallments(
                totals.getGrandTotal(),
                window.checkoutConfig.payment.splitit_payment.installmentsRange,
                window.checkoutConfig.payment.splitit_payment.defaultInstallments
            );
        },
        initAndRefreshSplititInTotals: function () {
            var self = this;
            $("body").off('DOMSubtreeModified', ".table-totals .grand.totals");
            $("body").on('DOMSubtreeModified', ".table-totals .grand.totals", function () {
                var grandTotalcontainer = $('.grand .price');
                if (grandTotalcontainer.length && typeof grandTotalcontainer[0].firstChild !== undefined && grandTotalcontainer[0].firstChild !== null) {
                    self.updateUpstreamMessage();
                }
            });

            $.async('.splitit-checkout-block > div', function() {
                splititHelper.updatePriceFormatForUpstreamMessage('.splitit-checkout-block');
            });

            this.updateUpstreamMessage();
        },
        initAndRefreshSplitit: function () {
            if (this.isOneStepCheckout()) {
                $('div.splitit-upstream-message-checkout').remove();
                return;
            }

            $.async('.splitit-checkout-block > div', function() {
                splititHelper.updatePriceFormatForUpstreamMessage('.splitit-checkout-block');
            });

            this.updateUpstreamMessage();
        },
        isOneStepCheckout: function () {
            return checkoutConfig.payment.splitit_payment.osc
                || $('#iosc-summary').length != 0 //Onestepcheckout_Iosc extension
                || $('#checkout.am-checkout').length != 0 // Amasty Checkout
                || $('.onestepcheckout-index-index').length != 0 // Mageplaza Checkout
        },
        updateUpstreamMessage: function () {
            splititHelper.updateUpstreamMessage(
                '.splitit-checkout-block',
                totals.getGrandTotal(),
                window.checkoutConfig.payment.splitit_payment.minTotal,
                window.checkoutConfig.payment.splitit_payment.maxTotal,
                this.getSplititNumInstallments()
            );
        }
    });
});