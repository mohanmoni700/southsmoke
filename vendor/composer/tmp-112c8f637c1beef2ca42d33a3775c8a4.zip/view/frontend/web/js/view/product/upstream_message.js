/*browser:true*/
/*global define*/
define([
        'jquery',
        'Magento_Customer/js/customer-data',
        'Splitit_PaymentGateway/js/helper/general',
        'Magento_Ui/js/lib/view/utils/async'
    ],
    function ($, customerData, splititHelper) {
        'use strict';
        return function (config) {
            function init()
            {
                $(document).on('updatePrice', updateSplititUpstreamMessage);
                $(document).on('contentUpdated', '[data-block=\'minicart\']', updateSplititUpstreamMessage);

                var updateUpstreamMessageAfterInit = true;
                $.async('.splitit-product-block .-splitit--text-price', function() {
                    if (updateUpstreamMessageAfterInit) {
                        updateSplititUpstreamMessage();
                        updateUpstreamMessageAfterInit = false;
                    } else {
                        splititHelper.updatePriceFormatForUpstreamMessage('.splitit-product-block');
                    }
                });
            }

            function updateSplititUpstreamMessage()
            {
                //to use cartTotal for show/hide UM on product page
                //let cartTotal = customerData.get('cart')().subtotalAmount ? parseFloat(customerData.get('cart')().subtotalAmount) : 0.0;
                let cartTotal = null;
                let newProductPrice = getNewProductPriceFromHtml();
                let newNumInstallments = splititHelper.getSplititNumInstallments(newProductPrice + cartTotal, config.installmentsRange, config.defaultInstallments);

                splititHelper.updateUpstreamMessage('.splitit-product-block', newProductPrice, config.minTotal, config.maxTotal, newNumInstallments);

                if (isMinMaxCartTotalAllowed(newProductPrice, cartTotal)) {
                    $('.splitit-product-block').show();
                } else {
                    $('.splitit-product-block').hide();
                }
            }

            function isMinMaxCartTotalAllowed(productPrice, cartTotal)
            {
                let isMinTotalPassed = (cartTotal && (cartTotal >= config.minTotal)) || (productPrice >= config.minTotal);
                let isMaxTotalPassed = config.maxTotal ? ((cartTotal <= config.maxTotal) && (productPrice <= config.maxTotal)) : true;

                return isMinTotalPassed && isMaxTotalPassed;
            }

            function getNewProductPriceFromHtml()
            {
                let priceHtml = null;

                if ($('.page-product-bundle').length) {
                    priceHtml = $('.product-details .price')[0]['firstChild']['data'];
                } else if ($('.page-product-grouped').length) {
                    priceHtml = $('#super-product-table .price')[0]['firstChild']['data'];
                } else {
                    priceHtml = $('.product-info-price [data-price-type="finalPrice"] .price')[0]['firstChild']['data'];
                }

                return priceHtml ? splititHelper.parsePriceHtmlToFloat(priceHtml) : 0;
            }

            init();
        }
    }
);
