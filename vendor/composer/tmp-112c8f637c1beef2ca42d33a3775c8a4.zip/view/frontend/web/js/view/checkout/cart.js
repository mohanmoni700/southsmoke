/*browser:true*/
/*global define*/
define([
    'jquery',
    'uiComponent',
    'Splitit_PaymentGateway/js/helper/general',
    'Splitit_PaymentGateway/js/helper/totals',
    'Magento_Ui/js/lib/view/utils/async',
    'domReady!'
], function ($, Component, splititHelper, totals) {
    'use strict';
    return function (config) {
        function init()
        {
            $('body').on('DOMSubtreeModified', '.cart-totals .grand.totals', function () {
                var grandTotalcontainer = $('.grand .price');
                if (grandTotalcontainer.length && typeof grandTotalcontainer[0].firstChild !== undefined && grandTotalcontainer[0].firstChild !== null) {
                    let grandTotal = totals.getGrandTotal();
                    let splititNumInstallments = splititHelper.getSplititNumInstallments(
                        grandTotal,
                        config.installmentsRange,
                        config.defaultInstallments
                    )

                    splititHelper.updateUpstreamMessage(
                        '.splitit-cart-block',
                        grandTotal,
                        config.minTotal,
                        config.maxTotal,
                        splititNumInstallments
                    );
                }
            });

            $.async('.splitit-cart-block > div', function () {
                splititHelper.updatePriceFormatForUpstreamMessage('.splitit-cart-block');
            });
        }

        init();
    }
});
