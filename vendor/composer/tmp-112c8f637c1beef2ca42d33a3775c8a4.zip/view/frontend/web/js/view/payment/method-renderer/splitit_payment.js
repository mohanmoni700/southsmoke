/*browser:true*/
/*global define*/
define([
  "jquery",
  "Magento_Checkout/js/view/payment/default",
  "Magento_Checkout/js/model/quote",
  "Magento_Ui/js/model/messageList",
  "mage/translate",
  "Magento_Checkout/js/checkout-data",
  "Magento_Checkout/js/model/payment/additional-validators",
  "Splitit_PaymentGateway/js/helper/general",
  "Splitit_PaymentGateway/js/helper/totals"
], function ($, Component, quote, messageList, $t, checkoutData, additionalValidators, splititHelper, totals) {
  "use strict";

  return Component.extend({
    defaults: {
      template: "Splitit_PaymentGateway/payment/form",
      transactionResult: "",
      additional_data: {},
      FF: null,
      consumerData: {fullName:'', email:'', phoneNumber:''},
      billingAddress: {},
      imports: {
        customerEmailShippingStep: 'checkout.steps.shipping-step.shippingAddress.customer-email:email',
        customerEmailBillingStep: 'checkout.steps.billing-step.payment.customer-email:email',
      }
    },

    initialize: function() {
      this._super();
      var self = this;

      this.observe(['customerEmailShippingStep', 'customerEmailBillingStep']);
      this.customerEmailShippingStep.subscribe(function (email) {
        if (self.consumerData.email != email) {
          self.consumerData.email = email;
        }
      });
      this.customerEmailBillingStep.subscribe(function (email) {
        if (self.consumerData.email != email) {
          self.consumerData.email = email;
        }
      });

      quote.billingAddress.subscribe(function(newAddress) {
        if (newAddress !== null) {
          self.prepareCustomerAddress(newAddress);
          self.prepareConsumerData(newAddress);
        }
      });

      quote.totals.subscribe(function() {
        if (window.installmentsPlanNumber === null) {
            window.installmentsPlanNumber = '';
            self.splititflexfieldsAfterRender();
        } else {
            self.updateCalculations(false);
        }
      });

      this.lastAmount = totals.getGrandTotal();

      return this;
    },
    updateAddress : function(billingAddress) {
      if (this.billingAddress.addressLine != billingAddress.addressLine ||
          this.billingAddress.addressLine2 != billingAddress.addressLine2 ||
          this.billingAddress.city != billingAddress.city ||
          this.billingAddress.state != billingAddress.state ||
          this.billingAddress.country != billingAddress.country ||
          this.billingAddress.zip != billingAddress.zip) {
        this.billingAddress = billingAddress;
      }
    },
    initObservable: function () {
      this._super().observe(["transactionResult"]);
      return this;
    },
    updateCalculations: function (forceUpdate) {
      if ((!this.isActive() && !forceUpdate) || (typeof SplititFF == 'undefined')) {
        return;
      }
      var newAmount = totals.getGrandTotal();
      if (this.lastAmount === newAmount) {
        return;
      }
      this.lastAmount = newAmount;

      SplititFF.setNumInstallments(0);
      SplititFF._installmentPicker.resetForPlanSync();

      $.ajax({
        url: '/splititpaymentgateway/flexfields/totals',
        method: 'post',
        data: {
            amount: newAmount,
            numInstallments: '',
            installments_plan_number: window.installmentsPlanNumber,
        },
        success: function (response) {
          if (typeof response == 'undefined' || typeof response.publicToken == 'undefined') {
            if (typeof reportExternalError != 'undefined') {
              reportExternalError('Public Token is not defined', response);
            } else {
              console.error('Public Token is not defined');
              console.error(response);
            }
          } else {
              if (typeof window.SplititFF !== 'undefined') {
                  window.SplititFF.setPublicToken(response.publicToken);
                  window.SplititFF.synchronizePlan();
              }
          }
        },
        error: function () {
        }
      });
    },
    prepareCustomerAddress: function(billingAddress) {
      if (billingAddress === null) {
        return;
      }

      var addressLine = '';
      var addressLine2 = '';
      if (typeof billingAddress.street != 'undefined') {
        addressLine = billingAddress.street[0];
        if(billingAddress.street.length > 1 && billingAddress.street[1]) {
          addressLine2 = billingAddress.street[1];
        }
      }
      var address = {
        addressLine: addressLine,
        addressLine2: addressLine2,
        city: null,
        state: null,
        country: null,
        zip: null
      };

      if(typeof billingAddress.city != 'undefined') {
        address.city = billingAddress.city;
      }

      if(typeof billingAddress.region != 'undefined') {
        address.state = billingAddress.region;
      }

      if(typeof billingAddress.countryId != 'undefined') {
        address.country = billingAddress.countryId;
      }

      if(typeof billingAddress.postcode != 'undefined') {
        address.zip = billingAddress.postcode;
      }
      this.updateAddress(address);
    },

    prepareConsumerData: function (newAddress) {
        if (newAddress === null) {
            return;
        }

        this.consumerData = {
            fullName: newAddress.firstname + ' ' + newAddress.lastname,
            email: (quote.guestEmail ? quote.guestEmail : window.checkoutConfig.customerData.email),
            phoneNumber: newAddress.telephone
        };
    },

    getCode: function () {
      return 'splitit_payment';
    },

    getData: function () {
      return {
        'method': this.getCode(),
        'additional_data': this.additional_data
      };
    },

    isAvailable: function () {
      try {
        let minAmount = window.checkoutConfig.payment.splitit_payment.minTotal;
        let maxAmount = window.checkoutConfig.payment.splitit_payment.maxTotal;
        let cartAmount = totals.getGrandTotal();
        if ((cartAmount < minAmount) || (maxAmount && cartAmount > maxAmount)) {
          return false;
        }
      } catch (e) {
        return false;
      }
      return true;
    },
    isActive: function () {
      return this.isChecked() === this.getCode();
    },
    placeOrderClick: function () {
      this.placeOrder('parent');
    },
    validateCheckout : function () {
      return this.validate() &&
          additionalValidators.validate() &&
          this.isPlaceOrderActionAllowed() === true;
    },
    splititflexfieldsAfterRender: function () {
      var thisObj = this;

      if (quote.billingAddress() === null) {
          window.installmentsPlanNumber = null;
          return;
      }

      var flexFieldsInstance = Splitit.FlexFields.setup({
        culture: window.checkoutConfig.payment.splitit_payment.culture,
        container: '#splitit-card-data',
        fields: {
          cardholderName: {
            selector: '#splitit-card-holder-full-name'
          },
          number: {
            selector: '#splitit-card-number'
          },
          cvv: {
            selector: '#splitit-cvv'
          },
          expirationDate: {
            selector: '#splitit-expiration-date'
          }
        },
        installmentPicker: {
          selector: '#installment-picker'
        },
        termsConditions: {
          selector: '#splitit-terms-conditions'
        },
        errorBox: {
          selector: '#splitit-error-box'
        }
      }).ready(function () {
        if (checkoutData.getSelectedPaymentMethod() === thisObj.getCode()) {
          this.show();
        }
        var billingAddress = quote.billingAddress();
        thisObj.prepareCustomerAddress(billingAddress);
        thisObj.prepareConsumerData(billingAddress);

        var splititFlexFields = this;
        if (typeof window.installmentsPlanNumber == 'undefined') {
            window.installmentsPlanNumber = null;
        }
        $.ajax({
          url: '/splititpaymentgateway/flexfields/index',
          method: 'post',
          data: {
            amount: totals.getGrandTotal(),
            numInstallments: '', //passing numInstallments blank as Splitit will process this.
            billingAddress: {
              AddressLine: thisObj.billingAddress.addressLine,
              AddressLine2: thisObj.billingAddress.addressLine2,
              City: thisObj.billingAddress.city,
              State: thisObj.billingAddress.state,
              Country: thisObj.billingAddress.country,
              Zip: thisObj.billingAddress.zip
            },
            consumerModel: {
              FullName: thisObj.consumerData.fullName,
              Email: thisObj.consumerData.email,
              PhoneNumber: thisObj.consumerData.phoneNumber
            },
            installments_plan_number: window.installmentsPlanNumber
          },
          success: function (data) {
            if (typeof data == 'undefined' || typeof data.publicToken == 'undefined') {
              // this error alert can be replaced to reportExternalError when this function will be released
              if (typeof reportExternalError != 'undefined') {
                reportExternalError('Public Token is not defined', data);
              } else {
                console.error('Public Token is not defined');
                console.error(data);
              }
            } else {
              splititFlexFields.setPublicToken(data.publicToken);
              window.installmentsPlanNumber = data.installmentPlan.InstallmentPlanNumber;
            }
          }
        });
      }).onSuccess(function (result) {
        var instNum = flexFieldsInstance.getState().planNumber;

        //simulate error process for debug async flow
        if (window.splititAsyncDebug === 'simulateError') {
          console.log("Simulate Error. PlanNumber: " + instNum);
          return;
        }

        thisObj.additional_data["installmentPlanNum"] = instNum;
        thisObj.additional_data["succeeded"] = "";
        if(result.installmentPlan.installmentPlanNumber == instNum) {
          thisObj.placeOrderClick();
        } else {
          thisObj.additional_data["succeeded"] = "IPN error";
        }
      }).onError(function (err) {
        if (err !== "undefined" && err.length > 0 && err.showError) {
          var errMsg = err[0]['error'];
          thisObj.showError($t(errMsg + " Please try again!"));
        }
      }).on3dComplete(function (data) {
        /* This method is only triggered when 3ds is enabled.
         * On success it goes to onSucess and on Error goes to onError
         * Displaying error message/going for successful order are being handled in relevant methods.
         */
        if (data.isSuccess) {
          thisObj.additional_data["succeeded"] = true; //set succeeded true
        }
      });

      $(document).off('click', '#splitit-btn-pay');
      $(document).on('click', '#splitit-btn-pay', function () {
          if (!thisObj.validateCheckout()) {
              return false;
          }

          if (thisObj.isOneStepCheckout()) {
              SplititFF.updateDetails(
                  {consumerData: thisObj.consumerData, billingAddress: thisObj.billingAddress},
                  function () {
                      SplititFF.checkout();
                  }
              );
          } else {
              SplititFF.checkout();
          }
      });

      window.SplititFF = flexFieldsInstance;
    },

    selectPaymentMethodSplitit: function () {
      if (checkoutData.getSelectedPaymentMethod() !== this.getCode()) {
        this.updateCalculations(true);
        if (window.SplititFF && !window.SplititFF._isFormVisible) {
          window.SplititFF.toggle();
        }
      }

      return this.selectPaymentMethod();
    },

    showError: function (errorMessage) {
      messageList.addErrorMessage({
        message: errorMessage,
      });
    },

    isOneStepCheckout: function () {
      return checkoutConfig.payment.splitit_payment.osc
        || $('#iosc-summary').length != 0 //Onestepcheckout_Iosc extension
        || $('#checkout.am-checkout').length != 0 // Amasty Checkout
        || $('.onestepcheckout-index-index').length != 0 // Mageplaza Checkout
        || quote.isVirtual() // virtual checkout has only one billing step
    }
  });
});
