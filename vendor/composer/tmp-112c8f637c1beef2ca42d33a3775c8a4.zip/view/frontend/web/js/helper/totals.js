define([
    'jquery',
    'Splitit_PaymentGateway/js/helper/general',
    'Magento_Checkout/js/model/quote'
], function ($, splititHelper, quote) {
    'use strict';

    return {
        getGrandTotal: function () {
            /* Magneto issue - https://github.com/magento/magento2/issues/34649. Let's try to read final price from summary */
            var grandTotalcontainer = $('.grand .price');
            if (grandTotalcontainer.length && typeof grandTotalcontainer[0].firstChild !== undefined && grandTotalcontainer[0].firstChild !== null) {
                var priceHtml = grandTotalcontainer[0]['firstChild']['data'];
                return splititHelper.parsePriceHtmlToFloat(priceHtml);
            }

            return quote.getTotals()().grand_total;
        }
    };
});
