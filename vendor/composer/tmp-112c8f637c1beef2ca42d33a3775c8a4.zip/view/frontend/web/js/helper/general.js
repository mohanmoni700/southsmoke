define([
    'jquery',
    'underscore',
    'Magento_Catalog/js/price-utils'
], function ($, _, priceUtils) {
    'use strict';

    function parsePriceHtmlToFloat(priceHtml) {
        let floatPrice = null;

        if (priceHtml) {
            priceHtml = priceHtml.replace(/[^0-9\.,]/g, "");

            let isThousandInTheEnd = !!priceHtml.match(/[\.,]\d\d\d$/g);
            if (isThousandInTheEnd) {
                floatPrice = priceHtml.replace(/[\.,]/g, "");
            } else {
                let regex = /([+-]?[0-9|^.|^,]+)[\.|,]([0-9]+)$/igm
                let result = regex.exec(priceHtml);
                floatPrice = result ? result[1].replace(/[\.,]/g, "") + "." + result[2] : priceHtml.replace(/[^0-9-+]/g, "");
            }
        }

        return parseFloat(floatPrice);
    }

    function updatePriceFormatForUpstreamMessage(block) {
        if ($(block + ' .-splitit--text-price').length) {
            let priceHtml = $(block + ' .-splitit--text-price').html();
            let upstreamMessagePrice = parsePriceHtmlToFloat(priceHtml);

            priceHtml = priceUtils.formatPrice(upstreamMessagePrice);
            $(block + ' .-splitit--text-price').html(priceHtml);
        }
    }

    function getSplititNumInstallments(total, installments_range, default_installment) {
        let installmentNum = default_installment;
        if (!installmentNum) {
            _.each(installments_range, function(range){
                if (total >= range[0] && total <= range[1]) {
                    installmentNum = _.last(range[2]);
                    return;
                }
            });
        }

        return installmentNum ? installmentNum : 3;
    }

    function updateUpstreamMessage(blockSelector, amount, minAmount, maxAmount, installments) {
        $(blockSelector)
            .attr('data-splitit-amount', amount)
            .attr('data-splitit-num-installments', installments);

        if ((amount >= minAmount) && (maxAmount == null || amount <= maxAmount)) {
            $(blockSelector).show();
        } else {
            $(blockSelector).hide();
        }

        if (typeof splitit != "undefined") {
            setTimeout(splitit.ui.refresh, 10);
        }
    }

    return {
        parsePriceHtmlToFloat: parsePriceHtmlToFloat,
        updatePriceFormatForUpstreamMessage: updatePriceFormatForUpstreamMessage,
        getSplititNumInstallments: getSplititNumInstallments,
        updateUpstreamMessage: updateUpstreamMessage
    };
});
