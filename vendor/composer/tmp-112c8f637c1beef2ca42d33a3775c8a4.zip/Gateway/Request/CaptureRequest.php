<?php

namespace Splitit\PaymentGateway\Gateway\Request;

class CaptureRequest extends AbstractRequest
{
    /**
     * @inheritDoc
     */
    public function buildRequest()
    {
        return [
            'TXN_TYPE' => 'S',
            'TXN_ID' => $this->getTransactionId(),
            'ApiKey' => $this->getMerchantGatewayKey(),
            'OrderRefNumber' =>  $this->getOrder()->getOrderIncrementId()
        ];
    }

    /**
     * Get transaction id
     *
     * @param $payment
     * @return mixed
     */
    private function getTransactionId()
    {
        $payment = $this->getPayment();

        $txnid = $payment->getLastTransId();
        if (empty($txnid)) {
            $txnid = $payment->getAdditionalInformation('installmentPlanNum');
        }

        return $txnid;
    }
}
