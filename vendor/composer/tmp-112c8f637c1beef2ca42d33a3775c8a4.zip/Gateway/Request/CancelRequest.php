<?php

namespace Splitit\PaymentGateway\Gateway\Request;

class CancelRequest extends AbstractRequest
{
    /**
     * @inheritDoc
     */
    public function buildRequest()
    {
        return [
            'TXN_TYPE' => 'C',
            'TXN_ID' => $this->getPayment()->getLastTransId(),
            'ApiKey' => $this->getMerchantGatewayKey(),
            'RefundUnderCancelation' => 'OnlyIfAFullRefundIsPossible'
        ];
    }
}
