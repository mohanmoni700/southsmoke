<?php

namespace Splitit\PaymentGateway\Gateway\Request;

class AuthorizationRequest extends AbstractRequest
{
    /**
     * @inheritDoc
     */
    public function buildRequest()
    {
        $payment = $this->getPayment();
        $order = $this->getOrder();

        return [
            'TXN_TYPE' => 'A',
            'INVOICE' => $order->getOrderIncrementId(),
            'CURRENCY' => $order->getCurrencyCode(),
            'Email' => $order->getBillingAddress()->getEmail(),
            'ApiKey' => $this->getMerchantGatewayKey(),
            'Amount' => $order->getGrandTotalAmount(),
            'InstallmentPlanNumber' => $payment->getAdditionalInformation('installmentPlanNum'),
            'OrderRefNumber' => $order->getOrderIncrementId(),
            'Succeeded' => $payment->getAdditionalInformation('succeeded')
        ];
    }
}
