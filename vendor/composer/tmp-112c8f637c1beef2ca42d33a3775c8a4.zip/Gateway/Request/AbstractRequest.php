<?php

namespace Splitit\PaymentGateway\Gateway\Request;

use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;

abstract class AbstractRequest implements BuilderInterface
{
    /**
     * @var ConfigInterface
     */
    protected $config;

    /**
     * @var PaymentDataObjectInterface
     */
    protected $paymentDataObject;

    /**
     * @var array
     */
    protected $buildSubject;

    /**
     * @param ConfigInterface $config
     */
    public function __construct(
        ConfigInterface $config
    ) {
        $this->config = $config;
    }

    /**
     * @inheritDoc
     */
    public function build(array $buildSubject)
    {
        $this->buildSubject = $buildSubject;
        $this->preparePaymentDataObject($buildSubject);

        return $this->buildRequest();
    }

    /**
     * Build request
     *
     * @return array
     */
    abstract protected function buildRequest();

    /**
     * Prepare payment data object
     *
     * @param array $buildSubject
     */
    protected function preparePaymentDataObject($buildSubject)
    {
        if (!isset($buildSubject['payment']) || !$buildSubject['payment'] instanceof PaymentDataObjectInterface) {
            throw new \InvalidArgumentException(__('Payment data object should be provided'));
        }

        $this->paymentDataObject = $buildSubject['payment'];
    }

    /**
     * Get order payment
     *
     * @return OrderPaymentInterface
     */
    protected function getPayment()
    {
        $payment = $this->paymentDataObject->getPayment();
        if (!$payment instanceof OrderPaymentInterface) {
            throw new \LogicException(__('Order payment should be provided.'));
        }
        return $payment;
    }

    /**
     * Get order
     *
     * @return \Magento\Payment\Gateway\Data\OrderAdapterInterface
     */
    protected function getOrder()
    {
        return $this->paymentDataObject->getOrder();
    }

    /**
     * Get merchant gateway key
     *
     * @return mixed
     */
    protected function getMerchantGatewayKey()
    {
        return $this->config->getValue('merchant_gateway_key', $this->getOrder()->getStoreId());
    }
}
