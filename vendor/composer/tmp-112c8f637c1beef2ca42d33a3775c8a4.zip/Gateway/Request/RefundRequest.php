<?php

namespace Splitit\PaymentGateway\Gateway\Request;

class RefundRequest extends AbstractRequest
{
    /**
     * @inheritDoc
     */
    public function buildRequest()
    {
        return [
            'TXN_TYPE' => 'R',
            'TXN_ID' => $this->getPayment()->getLastTransId(),
            'ApiKey' => $this->getMerchantGatewayKey(),
            'Amount' => $this->buildSubject['amount']
        ];
    }
}
