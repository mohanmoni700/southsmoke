<?php

namespace Splitit\PaymentGateway\Gateway\Request;

class VoidRequest extends AbstractRequest
{
    /**
     * @inheritDoc
     */
    public function buildRequest()
    {
        return [
            'TXN_TYPE' => 'V',
            'TXN_ID' => $this->getPayment()->getLastTransId(),
            'MERCHANT_KEY' => $this->getMerchantGatewayKey(),
            'RefundUnderCancelation' => 'OnlyIfAFullRefundIsPossible'
        ];
    }
}
