<?php

namespace Splitit\PaymentGateway\Gateway\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Checkout\Model\Cart;
use Magento\Payment\Gateway\Validator\ResultInterfaceFactory;
use Splitit\PaymentGateway\Gateway\Config\Config;

class AvailabilityHandler extends AbstractValidator
{
    /**
     * @var ResultInterface
     */
    protected $resultFactory;

    /**
     * @var Config
     */
    protected $splititConfig;

    /**
     * @var Cart
     */
    protected $cart;

    /**
     * @param ResultInterfaceFactory $resultFactory
     * @param Config $splititConfig
     * @param Cart $cart
     */
    public function __construct(
        ResultInterfaceFactory $resultFactory,
        Config $splititConfig,
        Cart $cart
    ) {
        $this->splititConfig = $splititConfig;
        $this->cart = $cart;
        parent::__construct($resultFactory);
    }

    /**
     * @inheritDoc
     */
    public function validate(array $validationSubject)
    {
        $isValid = true;

        $thresholdAmount = $this->splititConfig->getSplititMinOrderAmount();
        $cartTotal = $this->cart->getQuote()->getGrandTotal();

        if ($cartTotal < $thresholdAmount) {
            $isValid = false;
        }

        return $this->createResult($isValid);
    }
}
