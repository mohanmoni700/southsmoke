<?php

namespace Splitit\PaymentGateway\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Locale\Resolver;
use Psr\Log\LoggerInterface;

/**
 * TODO: REFACTOR - Create an interface definition for this class
 */
class Config
{
    public const CONFIG_ENVIRONMENT = 'payment/splitit_payment/environment';
    public const CONFIG_ACTIVE = 'payment/splitit_payment/active';
    public const CONFIG_MERCHANT_ID = 'payment/splitit_payment/merchant_gateway_key';
    public const CONFIG_MERCHANT_USERNAME = 'payment/splitit_payment/splitit_username';
    public const CONFIG_MERCHANT_PASSWORD = 'payment/splitit_payment/splitit_password';
    public const CONFIG_OSC = 'payment/splitit_payment/osc';
    public const CONFIG_INSTALLMENT_RANGE = 'payment/splitit_payment/ranges';
    public const CONFIG_DEFAULT_INSTALLMENTS_NUMBER = 'payment/splitit_payment/upstream_default_installments';
    public const CONFIG_PAYMENT_ACTION = 'payment/splitit_payment/payment_action';
    public const CONFIG_3D_SECURE = 'payment/splitit_payment/splitit_3dsecure';

    public const ALLOWED_UM_LANGUAGES = ['da-DK', 'de-DE', 'en-GB', 'en-US', 'es-ES', 'fr-FR', 'it-IT', 'nl-NL', 'pt-PT'];
    public const ALLOWED_FF_LANGUAGES = ['da-DK', 'de-DE', 'en-AU', 'en-GB', 'en-IE', 'en-US', 'es-ES', 'fr-FR', 'it-IT', 'ja-JP', 'nl-NL', 'pt-PT', 'ru-RU', 'sv-SE', 'tr-TR', 'zh-CN', 'zh-HK'];

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * @var ProductMetadataInterface
     */
    private $productMetadata;

    /**
     * @var Resolver
     */
    private $locale;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param LoggerInterface $logger
     * @param ProductMetadataInterface $productMetadata
     * @param Resolver $locale
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger,
        ProductMetadataInterface $productMetadata,
        Resolver $locale
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
        $this->productMetadata = $productMetadata;
        $this->locale = $locale;
    }

    /**
     * Get config
     *
     * @param string $configPath
     * @return mixed
     */
    public function getConfig($configPath)
    {
        return $this->scopeConfig->getValue($configPath, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Get is one page checkout
     *
     * @return bool
     */
    public function getOsc()
    {
        return (bool) $this->getConfig(self::CONFIG_OSC);
    }

    /**
     * Gets threshold amount for Splitit Payment Option.
     *
     * @return float
     */
    public function getSplititMinOrderAmount()
    {
        $installmentRange = $this->getUnserializedInstallmentRange();

        $fromRange = array_map(function ($v) {
            return (double)$v['priceFrom'] ?? null;
        }, array_values($installmentRange));

        return empty($fromRange) ? 0.0 : (float)min($fromRange);
    }

    /**
     * Get Splitit max order amount
     *
     * @return float|null
     */
    public function getSplititMaxOrderAmount()
    {
        $installmentRange = $this->getUnserializedInstallmentRange();

        $toRange = array_map(function ($v) {
            return (double)$v['priceTo'] ?? null;
        }, array_values($installmentRange));

        return empty($toRange) ? null : (float)max($toRange);
    }

    /**
     * Gets value of configured environment.
     *
     * Possible values: production or sandbox.
     * @return string
     */
    public function getEnvironment()
    {
        return $this->getConfig(self::CONFIG_ENVIRONMENT);
    }

    /**
     * Gets API merchant ID.
     *
     * @return string
     */
    public function getApiMerchantId()
    {
        return $this->getConfig(self::CONFIG_MERCHANT_ID);
    }

    /**
     * Gets Splitit Username.
     *
     * @return string
     */
    public function getApiUsername()
    {
        return $this->getConfig(self::CONFIG_MERCHANT_USERNAME);
    }

    /**
     * Gets Splitit Password.
     *
     * @return string
     */
    public function getApiPassword()
    {
        return $this->getConfig(self::CONFIG_MERCHANT_PASSWORD);
    }

    /**
     * Gets Payment configuration status.
     *
     * @return bool
     */
    public function isActive()
    {
        return $this->getConfig(self::CONFIG_ACTIVE);
    }

    /**
     * Get installments array
     *
     * @param $line
     * @return false|string[]
     */
    protected function getInstallmentsArray($line)
    {
        $installments = array_filter(explode(',', $line), 'trim');
        sort($installments, SORT_ASC);
        return $installments;
    }

    /**
     * Get installment range from admin config.
     *
     * @return array
     */
    public function getInstallmentRange()
    {
        try {
            $instRangeArray = [];

            $installmentRange = $this->getUnserializedInstallmentRange();
            foreach ($installmentRange as $key => $row) {
                $instRangeArray[] = [
                    $row['priceFrom'],
                    $row['priceTo'],
                    $this->getInstallmentsArray($row['installment'])
                ];
            }

            return $instRangeArray;
        } catch (\Exception $e) {
            $this->logger->debug($e);
        }

        return [];
    }

    /**
     * Get upstream default installments number
     *
     * @return mixed|null
     */
    public function getUpstreamDefaultInstallmentsNumber()
    {
        $val = $this->getConfig(self::CONFIG_DEFAULT_INSTALLMENTS_NUMBER);
        return $val ? $val : null;
    }

    /**
     * Gets value of payment action.
     *
     * Possible values: authorize or authorize_capture.
     * @return string
     */
    public function getPaymentAction()
    {
        return $this->getConfig(self::CONFIG_PAYMENT_ACTION);
    }

    /**
     * Gets value of 3D secure setting.
     *
     * @return bool
     */
    public function get3DSecure()
    {
        return (boolean)$this->getConfig(self::CONFIG_3D_SECURE);
    }

    /**
     * Get unserialized installment range
     *
     * @return array
     */
    private function getUnserializedInstallmentRange()
    {
        $installmentRangeValue = $this->getConfig(self::CONFIG_INSTALLMENT_RANGE);
        if (empty($installmentRangeValue)) {
            return [];
        }

        // Fix for 2.0.0-2.2.0
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        if (version_compare($this->productMetadata->getVersion(), '2.2.0', '<')) {
            $serializer = $objectManager->get(\Magento\Framework\Json\Helper\Data::class);
            $range = $serializer->jsonDecode($installmentRangeValue);
        } else {
            $serializer = $objectManager->get(\Magento\Framework\Serialize\Serializer\Json::class);
            $range = $serializer->unserialize($installmentRangeValue);
        }

        return $range ?? [];
    }

    /**
     * Get language for upstream message
     *
     * @return string
     */
    public function getLanguageForUpstreamMessage()
    {
        return $this->getCurrentStoreLanguage(self::ALLOWED_UM_LANGUAGES);
    }

    /**
     * Get language for flex fields
     *
     * @return string
     */
    public function getLanguageForFlexFields()
    {
        return $this->getCurrentStoreLanguage(self::ALLOWED_FF_LANGUAGES);
    }

    /**
     * Get current store language
     *
     * @param string $allowedLanguages
     * @return string
     */
    private function getCurrentStoreLanguage($allowedLanguages)
    {
        $currentLocaleCode = $this->locale->getLocale();
        $currentLanguage = str_replace('_', '-', $currentLocaleCode);
        return in_array($currentLanguage, $allowedLanguages) ? $currentLanguage : 'en-US';
    }

    /**
     * Is Upstream Message enabled on page
     *
     * @param string $page
     * @return bool
     */
    public function isUpstreamMessageEnabledOn($page)
    {
        return $this->isActive() && (bool)$this->getConfig('payment/splitit_payment/upstream_messages_' . $page);
    }
}
