<?php

namespace Splitit\PaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\TransferInterface;
use SplititSdkClient\Model\CancelInstallmentPlanRequest;

class SplititCancelApiImplementation extends SplititAbstractHttpClient
{
    /**
     * @inheritDoc
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $data = $transferObject->getBody();
        $cancelRequest = new CancelInstallmentPlanRequest();
        $cancelRequest->setInstallmentPlanNumber($data['TXN_ID']);
        $cancelRequest->setRefundUnderCancelation($data['RefundUnderCancelation']);

        try {
            $apiInstance = $this->installmentPlanApiObject->create();
            $cancelResponse = $apiInstance->installmentPlanCancel($cancelRequest);
        } catch (\Exception $e) {
            $this->logger->debug($e->getTrace());
            throw new \Exception(__('Error in cancelling the installment plan.'));
        }

        $isSuccess = $cancelResponse->getResponseHeader()->getSucceeded();
        $txnId = $data['TXN_ID'] ?? '';

        return $this->prepareResponce($isSuccess, $txnId, $data);
    }
}
