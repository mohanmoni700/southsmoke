<?php

namespace Splitit\PaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use SplititSdkClient\Model\StartInstallmentsRequest;
use SplititSdkClient\Model\PlanData;
use SplititSdkClient\Model\UpdateInstallmentPlanRequest;

class SplititStartInstallmentImplementation extends SplititAbstractHttpClient
{
    /**
     * Places request to gateway. Returns result as ENV array
     * TODO: Inject InstallmentPlanApi, StartInstallmentsRequest
     *
     * @inheritDoc
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $data = $transferObject->getBody();

        if ((!isset($data['TXN_ID']) || ! $data['TXN_ID']) && $this->isAsyncFlow()) {
            //no need to make extra API calls here if is async flow
            return [
                'RESULT_CODE' => self::SUCCESS,
                'TXN_ID' => $this->request->getParam('InstallmentPlanNumber')
            ];
        }

        $apiInstance = $this->installmentPlanApiObject->create();

        $paymentAction = $this->splititConfig->getPaymentAction();
        if ($paymentAction == AbstractMethod::ACTION_AUTHORIZE_CAPTURE) {
            $orderRefNumber = $data['OrderRefNumber'];

            $planData = new PlanData();
            $planData->setRefOrderNumber($orderRefNumber);
            $updateRequest = new UpdateInstallmentPlanRequest();
            $updateRequest->setInstallmentPlanNumber($data['TXN_ID']);
            $updateRequest->setPlanData($planData);

            try {
                $result = $apiInstance->installmentPlanUpdate($updateRequest);
                if (isset($data['TXN_ID']) && $data['TXN_ID']) {
                    $this->updateLog($orderRefNumber, $data['TXN_ID']);
                }
            } catch (\Exception $e) {
                throw new \Exception(__('Error in adding order reference number to the installment plan. Please try again.'));
            }
        }

        $startInstallmentsRequest = new StartInstallmentsRequest();
        if (isset($data['TXN_ID']) && $data['TXN_ID']) {
            $startInstallmentsRequest->setInstallmentPlanNumber($data['TXN_ID']);
        }

        try {
            $startInstallmentsResponse = $apiInstance->installmentPlanStartInstallments($startInstallmentsRequest);
        } catch (\Exception $e) {
            throw new \Exception(__('Unable to process payment. Please try again later.'));
        }

        $isSuccess = $startInstallmentsResponse->getResponseHeader()->getSucceeded();
        $txnId = $data['TXN_ID'] ?? '';

        return $this->prepareResponce($isSuccess, $txnId, $data);
    }
}
