<?php

namespace Splitit\PaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\TransferInterface;
use SplititSdkClient\Model\PlanData;
use SplititSdkClient\Model\UpdateInstallmentPlanRequest;

class SplititCreateApiImplementation extends SplititAbstractHttpClient
{
    /**
     * @inheritDoc
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $data = $transferObject->getBody();
        if ((!isset($data['InstallmentPlanNumber']) || !$data['InstallmentPlanNumber']) && $this->isAsyncFlow()) {
            //no need to make extra API calls here if is async flow
            return [
                'RESULT_CODE' => self::SUCCESS,
                'TXN_ID' => $this->request->getParam('InstallmentPlanNumber')
            ];
        }
        $isSuccess = $data['Succeeded'];

        $orderRefNumber = $data['OrderRefNumber'];

        $planData = new PlanData();
        $planData->setRefOrderNumber($orderRefNumber);

        $updateRequest = new UpdateInstallmentPlanRequest();
        $updateRequest->setInstallmentPlanNumber($data['InstallmentPlanNumber']);
        $updateRequest->setPlanData($planData);

        try {
            $apiInstance = $this->installmentPlanApiObject->create();
            $result = $apiInstance->installmentPlanUpdate($updateRequest);
            $this->updateLog($orderRefNumber, $data['InstallmentPlanNumber']);
        } catch (\Exception $e) {
            throw new \Exception(__('Error in adding order reference number to the installment plan. Please try again.'));
        }

        $txnId = $data['InstallmentPlanNumber'] ?? '';

        return $this->prepareResponce($isSuccess, $txnId, $data);
    }
}
