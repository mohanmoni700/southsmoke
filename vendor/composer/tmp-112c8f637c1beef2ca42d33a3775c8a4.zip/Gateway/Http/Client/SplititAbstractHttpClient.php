<?php

namespace Splitit\PaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Splitit\PaymentGateway\Model\InstallmentPlanApiObject;
use Splitit\PaymentGateway\Gateway\Config\Config;
use Psr\Log\LoggerInterface;
use Splitit\PaymentGateway\Model\ResourceModel\Log as LogResource;
use Magento\Framework\App\RequestInterface;

abstract class SplititAbstractHttpClient implements ClientInterface
{
    public const SUCCESS = 1;
    public const FAILURE = 0;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var RequestInterface
     */
    public $request;

    /**
     * @var Config
     */
    protected $splititConfig;

    /**
     * @var LoggerInterface
     */
    protected $psrLogger;

    /**
     * @var LogResource
     */
    protected $logResource;

    /**
     * @var InstallmentPlanApiObject
     */
    protected $installmentPlanApiObject;

    /**
     * @param Logger $logger
     * @param Config $splititConfig
     * @param LoggerInterface $psrLogger
     * @param LogResource $logResource
     * @param RequestInterface $request
     * @param InstallmentPlanApiObject $installmentPlanApiObject
     */
    public function __construct(
        Logger $logger,
        Config $splititConfig,
        LoggerInterface $psrLogger,
        LogResource $logResource,
        RequestInterface $request,
        InstallmentPlanApiObject $installmentPlanApiObject
    ) {
        $this->logger = $logger;
        $this->splititConfig = $splititConfig;
        $this->psrLogger = $psrLogger;
        $this->logResource = $logResource;
        $this->request = $request;
        $this->installmentPlanApiObject = $installmentPlanApiObject;
    }

    /**
     * @inheritDoc
     */
    abstract public function placeRequest(TransferInterface $transferObject);

    /**
     * Prepare response
     *
     * @param int $isSuccess
     * @param string $transactionId
     * @param array $requestData
     * @return array
     */
    protected function prepareResponce($isSuccess, $transactionId, $requestData)
    {
        $response = [
            'RESULT_CODE' => (!empty($isSuccess)) ? self::SUCCESS : self::FAILURE,
            'TXN_ID' => $transactionId
        ];

        $this->logger->debug(
            [
                'request' => $requestData,
                'response' => $response
            ]
        );

        return $response;
    }

    /**
     * Is async flow
     *
     * @return bool
     */
    protected function isAsyncFlow()
    {
        return $this->request->getParam('InstallmentPlanNumber') && $this->request->getActionName('syccessasync');
    }

    /**
     * Update log
     *
     * @param int $incrementId
     * @param string $ipn
     */
    public function updateLog($incrementId, $ipn)
    {
        $log = $this->logResource->getByIPN($ipn);
        if ($log && $log->getId()) {
            $log->setIncrementId($incrementId);
            $log->setIsSuccess(true);
            try {
                $this->logResource->save($log);
            } catch (\Exception $e) {
                $this->logger->debug($e->getTrace());
            }
        } else {
            $this->logger->debug(['There is no log record for IPN ' . $ipn]);
        }
    }
}
