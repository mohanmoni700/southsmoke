<?php

namespace Splitit\PaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\TransferInterface;
use SplititSdkClient\Model\RefundPlanRequest;
use SplititSdkClient\Model\MoneyWithCurrencyCode;

class SplititRefundApiImplementation extends SplititAbstractHttpClient
{
    /**
     * Places request to gateway. Returns result as ENV array
     * TODO: Inject InstallmentPlanApi, RefundPlanRequest
     *
     * @inheritDoc
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $data = $transferObject->getBody();
        if (isset($data['TXN_ID']) && strpos($data['TXN_ID'], '-refund') !== false) {
            $data['TXN_ID'] = str_replace('-refund', '', $data['TXN_ID']);
        }

        $refundRequest = new RefundPlanRequest();
        $refundRequest->setInstallmentPlanNumber($data['TXN_ID']);
        $refundRequest->setAmount(new MoneyWithCurrencyCode(["value" => $data['Amount'], "currency_code" => "USD"]));
        $refundRequest->setRefundStrategy("FutureInstallmentsFirst");

        try {
            $apiInstance = $this->installmentPlanApiObject->create();
            $refundResponse = $apiInstance->installmentPlanRefund($refundRequest);
        } catch (\Exception $e) {
            throw new \Exception(__('Error in creating refund for installment plan.'));
        }

        $isSuccess = $refundResponse->getResponseHeader()->getSucceeded();
        $txnId = $data['TXN_ID'] ?? '';

        return $this->prepareResponce($isSuccess, $txnId, $data);
    }
}
