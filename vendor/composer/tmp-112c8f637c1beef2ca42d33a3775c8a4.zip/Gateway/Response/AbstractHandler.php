<?php

namespace Splitit\PaymentGateway\Gateway\Response;

use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Model\Order\Payment;

abstract class AbstractHandler implements HandlerInterface
{
    public const TXN_ID = 'TXN_ID';

    /**
     * @var InfoInterface|Payment
     */
    protected $payment;

    /**
     * @var array
     */
    protected $handlingSubject;

    /**
     * @var array
     */
    protected $response;

    /**
     * @inheritDoc
     */
    public function handle(array $handlingSubject, array $response)
    {
        $this->handlingSubject = $handlingSubject;
        $this->response = $response;
        $this->preparePayment($handlingSubject);
        $this->handleResponse();
    }

    /**
     * Handle response
     *
     * @return mixed
     */
    abstract protected function handleResponse();

    /**
     * Prepare payment
     *
     * @param array $handlingSubject
     */
    protected function preparePayment($handlingSubject)
    {
        if (!isset($handlingSubject['payment'])
            || !$handlingSubject['payment'] instanceof PaymentDataObjectInterface
        ) {
            throw new \InvalidArgumentException(__('Payment data object should be provided'));
        }

        /** @var PaymentDataObjectInterface $paymentDO */
        $paymentDO = $handlingSubject['payment'];

        $this->payment = $paymentDO->getPayment();
    }
}
