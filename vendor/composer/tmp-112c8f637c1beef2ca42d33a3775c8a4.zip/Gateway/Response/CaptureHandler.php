<?php

namespace Splitit\PaymentGateway\Gateway\Response;

class CaptureHandler extends AbstractHandler
{
    /**
     * @inheritDoc
     */
    public function handleResponse()
    {
        /** @var $payment \Magento\Sales\Model\Order\Payment */
        $this->payment->setTransactionId($this->response[self::TXN_ID]);
        $this->payment->setIsTransactionClosed(false);
    }
}
