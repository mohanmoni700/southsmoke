<?php

namespace Splitit\PaymentGateway\Gateway\Response;

class CancelHandler extends AbstractHandler
{
    /**
     * @inheritDoc
     */
    public function handleResponse()
    {
        /** @var $payment \Magento\Sales\Model\Order\Payment */
        $this->payment->setIsTransactionClosed(true);
        $this->payment->setShouldCloseParentTransaction(true);
    }
}
