<?php

namespace Splitit\PaymentGateway\Gateway\Response;

class FraudHandler extends AbstractHandler
{
    public const FRAUD_MSG_LIST = 'FRAUD_MSG_LIST';

    /**
     * @inheritDoc
     */
    public function handleResponse()
    {
        if (!isset($this->response[self::FRAUD_MSG_LIST]) || !is_array($this->response[self::FRAUD_MSG_LIST])) {
            return;
        }

        $this->payment->setAdditionalInformation(self::FRAUD_MSG_LIST, (array)$this->response[self::FRAUD_MSG_LIST]);
        $this->payment->setIsTransactionPending(true);
        $this->payment->setIsFraudDetected(true);
    }
}
