<?php

namespace Splitit\PaymentGateway\Gateway\Response;

class TxnIdHandler extends AbstractHandler
{
    public const PAYMENT_METHOD = 'splitit_payment';

    /**
     * @inheritDoc
     */
    public function handleResponse()
    {
        $this->payment->setTransactionId($this->response[self::TXN_ID]);
        $this->payment->setIsTransactionClosed(false);
    }
}
