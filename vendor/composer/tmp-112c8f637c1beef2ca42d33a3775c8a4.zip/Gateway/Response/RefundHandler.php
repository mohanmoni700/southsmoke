<?php

namespace Splitit\PaymentGateway\Gateway\Response;

class RefundHandler extends AbstractHandler
{
    /**
     * @inheritDoc
     */
    public function handleResponse()
    {
        $shouldCloseParentTransaction = $this->shouldCloseParentTransaction();

        $this->payment->setIsTransactionClosed(true);
        $this->payment->setShouldCloseParentTransaction($shouldCloseParentTransaction);
    }

    /**
     * Check should close parent transaction
     *
     * @return bool
     */
    public function shouldCloseParentTransaction()
    {
        return !(bool)$this->payment->getCreditmemo()->getInvoice()->canRefund();
    }
}
