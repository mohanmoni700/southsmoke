<?php

namespace Splitit\PaymentGateway\Block;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Splitit\PaymentGateway\Block\AdminPaymentForm\FlexFieldsBlock;

class Payment extends Template
{
    /**
     * @var ConfigProviderInterface
     */
    protected $config;

    /**
     * @var FlexFieldsBlock
     */
    protected $flexfield;

    /**
     * Constructor
     *
     * @param Context $context
     * @param ConfigProviderInterface $config
     * @param FlexFieldsBlock $flexfield
     * @param array $data
     */
    public function __construct(
        Context $context,
        ConfigProviderInterface $config,
        FlexFieldsBlock $flexfield,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->config = $config;
        $this->flexfield = $flexfield;
    }

    /**
     * Get payment config
     *
     * @return false|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getPaymentConfig()
    {
        $payment = $this->config->getConfig()['payment'];
        $config = $payment[$this->getCode()];
        $config['code'] = $this->getCode();
        $config += [
            'ajaxUrl' => $this->flexfield->getAjaxUrl(),
            'totalsAjaxUrl' => $this->flexfield->getTotalsUpdateAjaxUrl(),
            'getQuoteIdAjaxUrl' => $this->flexfield->getCurrentQuoteIdUrl()
        ];
        return json_encode($config, JSON_UNESCAPED_SLASHES);
    }

    /**
     * Get payment code
     *
     * @return string
     */
    public function getCode()
    {
        return "splitit_payment";
    }

    /**
     * Get quote id
     *
     * @return int
     */
    public function getQuoteId()
    {
        return (int)$this->flexfield->getQuoteId();
    }
}
