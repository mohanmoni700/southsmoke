<?php

namespace Splitit\PaymentGateway\Block\UpstreamMessaging;

use Splitit\PaymentGateway\Block\UpstreamMessaging;

class UpstreamContentProduct extends UpstreamMessaging
{
    /**
     * Returns true/false based on admin configuration
     *
     * @return boolean
     */
    public function canDisplay()
    {
        return $this->splititConfig->isActive() && $this->splititConfig->isUpstreamMessageEnabledOn('product');
    }

    /**
     * Gets Current Product Price
     *
     * @return string|null
     */
    public function getCurrentProductPrice()
    {
        $currentProduct = $this->registry->registry('current_product');
        if (isset($currentProduct)) {
            if ($currentProduct->getTypeId() == 'bundle') {
                $productPrice = $currentProduct->getPriceInfo()->getPrice('final_price')->getMinimalPrice()->getValue();
            } elseif ($currentProduct->getTypeId() == 'grouped') {
                $associatedProducts = $currentProduct->getTypeInstance(true)->getAssociatedProducts($currentProduct);
                foreach ($associatedProducts as $childProduct) {
                    $prices[] = $childProduct->getPrice();
                }
                sort($prices);
                $productPrice = $prices[0];
            } else {
                $productPrice = $currentProduct->getFinalPrice();
            }
            return bcdiv($productPrice, 1, 2);
        }
        return null;
    }

    /**
     * Gets installment number per admin config
     *
     * @return string
     */
    public function getInstallmentNumber()
    {
        $productTotal = $this->getCurrentProductPrice();
        $installmentNum = $this->splititConfig->getUpstreamDefaultInstallmentsNumber();
        if (!$installmentNum) {
            $installmentArray = $this->getInstallmentRangeValues();
            foreach ($installmentArray as $installmentArrayItem) {
                if ($productTotal >= $installmentArrayItem[0] && $productTotal <= $installmentArrayItem[1]) {
                    $installmentNum = end($installmentArrayItem[2]);
                    break;
                }
            }
        }

        return !empty($installmentNum) ? $installmentNum : 3; //use 3 as default installment number if not configured
    }
}
