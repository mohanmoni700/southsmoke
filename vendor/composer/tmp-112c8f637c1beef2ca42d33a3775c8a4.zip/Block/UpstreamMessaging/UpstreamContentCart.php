<?php

namespace Splitit\PaymentGateway\Block\UpstreamMessaging;

use Splitit\PaymentGateway\Block\UpstreamMessaging;

class UpstreamContentCart extends UpstreamMessaging
{
    /**
     * Returns true/false based on admin configuration
     *
     * @return boolean
     */
    public function canDisplay()
    {
        return $this->splititConfig->isActive() && $this->splititConfig->isUpstreamMessageEnabledOn('cart');
    }

    /**
     * Gets current cart subtotal amount
     *
     * @return int|null
     */
    public function getCurrentCartTotal()
    {
        $subtotal = $this->cart->getQuote()->getSubtotal();
        if (!empty($subtotal)) {
            return $subtotal;
        }

        return null;
    }

    /**
     * Gets current order grand total
     *
     * @return int
     */
    public function getOrderTotalPrice()
    {
        return $this->cart->getQuote()->getGrandTotal();
    }

    /**
     * Gets installment number per admin config
     *
     * @return string
     */
    public function getInstallmentNumber()
    {
        $cartTotal =  $this->getCurrentCartTotal();
        $installmentNum = $this->splititConfig->getUpstreamDefaultInstallmentsNumber();
        if (!$installmentNum) {
            $installmentArray = $this->getInstallmentRangeValues();
            foreach ($installmentArray as $installmentArrayItem) {
                if ($cartTotal >= $installmentArrayItem[0] && $cartTotal <= $installmentArrayItem[1]) {
                    $installmentNum = end($installmentArrayItem[2]);
                    break;
                }
            }
        }

        return $installmentNum;
    }

    /**
     * Gets threshold amount from config
     *
     * @return float
     */
    public function getMinTotal()
    {
        return $this->splititConfig->getSplititMinOrderAmount();
    }
}
