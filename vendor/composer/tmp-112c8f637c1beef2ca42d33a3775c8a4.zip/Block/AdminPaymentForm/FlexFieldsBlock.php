<?php

namespace Splitit\PaymentGateway\Block\AdminPaymentForm;

use Magento\Backend\Model\Session\Quote;
use Magento\Framework\View\Element\Template;
use Magento\Backend\Model\UrlInterface;

class FlexFieldsBlock extends Template
{
    public const FLEXFIELDS_CONTROLLER_ROUTE = 'splititpaymentgateway/flexfields/index';
    public const TOTALS_CONTROLLER_ROUTE = 'splititpaymentgateway/flexfields/totals';
    public const GET_QUOTE_ID_ROUTE = 'splititpaymentgateway/index/quoteid';

    /**
     * @var UrlInterface
     */
    private $backendUrl;

    /**
     * @var Quote
     */
    private $quote;

    /**
     * FlexFieldsBlock constructor.
     *
     * @param Template\Context $context
     * @param Quote $quote
     * @param UrlInterface $backendUrl
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Quote $quote,
        UrlInterface $backendUrl,
        array $data = []
    ) {
        $this->quote = $quote;
        $this->backendUrl = $backendUrl;
        parent::__construct($context, $data);
    }

    /**
     * Return ajax url for flexfields render
     *
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getAjaxUrl()
    {
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        return $baseUrl . self::FLEXFIELDS_CONTROLLER_ROUTE;
    }

    /**
     * Return ajax url for totals update
     *
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getTotalsUpdateAjaxUrl()
    {
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        return $baseUrl . self::TOTALS_CONTROLLER_ROUTE;
    }

    /**
     * Get current quote id URL
     *
     * @return string
     */
    public function getCurrentQuoteIdUrl()
    {
        return $this->backendUrl->getUrl(self::GET_QUOTE_ID_ROUTE);
    }

    /**
     * Get quote id
     *
     * @return int
     */
    public function getQuoteId()
    {
        return $this->quote->getQuoteId();
    }
}
