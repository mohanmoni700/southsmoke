<?php

namespace Splitit\PaymentGateway\Block;

use Magento\Framework\View\Element\Template;
use Splitit\PaymentGateway\Gateway\Config\Config;

class AddJsHeader extends Template
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @param Config $config
     * @param Template\Context $context
     * @param array $data
     */
    public function __construct(
        Config $config,
        Template\Context $context,
        array $data = []
    ) {
        $this->config = $config;
        parent::__construct($context, $data);
    }

    /**
     * @inheritDoc
     */
    public function toHtml()
    {
        $src = 'https://flexfields.' . $this->config->getEnvironment() . '.splitit.com/v2.0/splitit.flex-fields.sdk.js';
        return '<script type="text/javascript" src="' . $src . '"></script>'
            . $this->addUpstreamMessageHtml();
    }

    /**
     * Add upstream message html
     *
     * @return string
     */
    private function addUpstreamMessageHtml()
    {
        try {
            return $this->config->isUpstreamMessageEnabledOn('checkout')
                ? $this->getLayout()
                    ->createBlock(\Splitit\PaymentGateway\Block\UpstreamMessaging::class)
                    ->setTemplate("Splitit_PaymentGateway::upstream-messaging.phtml")
                    ->toHtml()
                : '';
        } catch (\Exception $e) {
            return '';
        }
    }
}
