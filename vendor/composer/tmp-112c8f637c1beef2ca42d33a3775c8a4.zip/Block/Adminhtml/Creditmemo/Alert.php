<?php

namespace Splitit\PaymentGateway\Block\Adminhtml\Creditmemo;

use Magento\Backend\Block\Template;
use Splitit\PaymentGateway\Model\Ui\ConfigProvider;

class Alert extends Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @param Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->coreRegistry = $registry;
    }

    /**
     * Retrieve creditmemo model instance
     *
     * @return \Magento\Sales\Model\Order\Creditmemo
     */
    public function getCreditmemo()
    {
        return $this->coreRegistry->registry('current_creditmemo');
    }

    /**
     * Check is Splitit payment method
     *
     * @return bool
     */
    public function isSplititMethod()
    {
        if ($this->getCreditmemo()
            && $this->getCreditmemo()->getOrder()
            && $this->getCreditmemo()->getOrder()->getPayment()
        ) {
            return $this->getCreditmemo()->getOrder()->getPayment()->getMethod() == ConfigProvider::CODE;
        }
        return false;
    }
}
