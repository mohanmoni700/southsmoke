<?php

namespace Splitit\PaymentGateway\Block;

use Magento\Framework\Phrase;
use Magento\Payment\Block\ConfigurableInfo;
use Splitit\PaymentGateway\Gateway\Response\FraudHandler;

class Info extends ConfigurableInfo
{
    /**
     * @inheritDoc
     */
    protected function getLabel($field)
    {
        return __($field);
    }

    /**
     * @inheritDoc
     */
    protected function getValueView($field, $value)
    {
        switch ($field) {
            case FraudHandler::FRAUD_MSG_LIST:
                return implode('; ', $value);
        }
        return parent::getValueView($field, $value);
    }
}
