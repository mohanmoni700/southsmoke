<?php

namespace Splitit\PaymentGateway\Block\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Documentation extends Field
{
    /**
     * @var string
     */
    private $userGuide = "https://developers.splitit.com/documentation/platform-plugins/magento";

    /**
     * @inheritDoc
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        return sprintf(
            "<span style='margin-bottom:-8px; display:block;'><a href='%s' target='_blank'>%s</a></span>",
            $this->userGuide,
            __("Support Articles")
        ) . $element->getValue();
    }
}
