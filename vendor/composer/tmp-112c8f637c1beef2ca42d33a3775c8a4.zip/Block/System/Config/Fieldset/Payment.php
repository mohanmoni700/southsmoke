<?php

namespace Splitit\PaymentGateway\Block\System\Config\Fieldset;

use Magento\Backend\Block\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Config\Block\System\Config\Form\Fieldset;
use Magento\Config\Model\Config;
use Magento\Framework\View\Helper\Js;

class Payment extends Fieldset
{
    /**
     * @inheritDoc
     */
    protected function _getFrontendClass($element)
    {
        return parent::_getFrontendClass($element) . ' with-button';
    }

    /**
     * @inheritDoc
     */
    protected function _getHeaderTitleHtml($element)
    {
        $htmlId = $element->getHtmlId();
        $script = $this->renderEventListenerAsTag($htmlId);
        $configureText = __('Configure');
        $closeText = __('Close');

        $html = <<<HTML
        <div class="config-heading" >
            <div class="button-container">
                <button type="button" class="button action-configure" id="{$htmlId}-head" >
                    <span class="state-closed">{$configureText}</span>
                    <span class="state-opened">{$closeText}</span>
                </button>
                {$script}
            </div>
            <div class="heading">
                <strong>{$element->getLegend()}</strong>
                <span class="heading-intro">{$element->getComment()}</span>
                <div class="config-alt"></div>
            </div>
        </div>
HTML;

        return $html;
    }

    /**
     * Render event listener as tag
     *
     * @param string $htmlId
     * @return string
     */
    private function renderEventListenerAsTag($htmlId)
    {
        $random = uniqid();
        $listenerFunction = 'eventListener' . $random;
        $elementName = 'listenedElement' . $random;
        $url = $this->getUrl('adminhtml/*/state');

        $script = <<<JS_SCRIPT
            <script type="text/javascript">
                function {$listenerFunction} () {
                    splititToggleSolution.call(this,'{$htmlId}','{$url}');event.preventDefault();
                }
                var {$elementName}Array = document.querySelectorAll("button#{$htmlId}-head");
                if({$elementName}Array.length !== 'undefined'){
                    {$elementName}Array.forEach(function(element) {
                        if (element) {
                            element.onclick = function (event) {
                                var targetElement = element;
                                if (event && event.target) {
                                    targetElement = event.target;
                                }
                                {$listenerFunction}.apply(targetElement);
                            };
                        }
                    });
                }
            </script>
JS_SCRIPT;

        return $script;
    }

    /**
     * @inheritDoc
     */
    protected function _getHeaderCommentHtml($element)
    {
        return '';
    }

    /**
     * @inheritDoc
     */
    protected function _isCollapseState($element)
    {
        return false;
    }

    /**
     * @inheritDoc
     */
    protected function _getExtraJs($element)
    {
        $script = "require(['jquery', 'prototype'], function(jQuery){
            window.splititToggleSolution = function (id, url) {
                var doScroll = false;
                Fieldset.toggleCollapse(id, url);
                if ($(this).hasClassName(\"open\")) {
                    \$$(\".with-button button.button\").each(function(anotherButton) {
                        if (anotherButton != this && $(anotherButton).hasClassName(\"open\")) {
                            $(anotherButton).click();
                            doScroll = true;
                        }
                    }.bind(this));
                }
                if (doScroll) {
                    var pos = Element.cumulativeOffset($(this));
                    window.scrollTo(pos[0], pos[1] - 45);
                }
            }
        });";

        return $this->_jsHelper->getScript($script);
    }
}
