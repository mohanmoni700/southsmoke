<?php

namespace Splitit\PaymentGateway\Block\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Component\ComponentRegistrar;
use Magento\Backend\Block\Template\Context;

class Version extends Field
{
    /**
     * @var ComponentRegistrar
     */
    private $componentRegistrar;

    /**
     * @param Context $context
     * @param ComponentRegistrar $componentRegistrar
     * @param array $data
     */
    public function __construct(
        Context $context,
        ComponentRegistrar $componentRegistrar,
        array $data = []
    ) {
        $this->componentRegistrar = $componentRegistrar;
        parent::__construct($context, $data);
    }

    /**
     * @inheritDoc
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        $nameSpace = explode("\\", __NAMESPACE__);
        $moduleName = $nameSpace[0] . '_' . $nameSpace[1];
        $configFile = $this->componentRegistrar->getPath(ComponentRegistrar::MODULE, $moduleName)
            . DIRECTORY_SEPARATOR . 'etc' . DIRECTORY_SEPARATOR . 'module.xml';
        $xml = new \SimpleXMLElement(file_get_contents($configFile));

        return "<span style='margin-bottom:-8px; display:block;'>"
            . $xml->module[0]->attributes()->setup_version
            . "</span>"
            . $this->getErrorMessage()
            . $element->getValue();
    }

    /**
     * Check compatibility and get error message
     *
     * @return string
     */
    private function getErrorMessage()
    {
        $message = '';

        if (!$this->isSdkInstalled()) {
            $message = 'Splitit SDK is not installed.
                        <div>Use command to install: 
                            <span class="composer-command">composer require splitit/sdk</span>
                        </div>';
        }

        return $message ? "<div class='splitit-error'>" . $message . "</div>" : '';
    }

    /**
     * Check is SDK installed
     *
     * @return bool
     */
    private function isSdkInstalled()
    {
        return class_exists(\SplititSdkClient\HeaderSelector::class);
    }
}
