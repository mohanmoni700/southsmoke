<?php

namespace Splitit\PaymentGateway\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Splitit\PaymentGateway\Model\Statistic\Notification;

class FirstInstall implements DataPatchInterface
{
    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * @var Notification
     */
    private $notification;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param Notification $notification
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        Notification $notification
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->notification = $notification;
    }

    /**
     * @inheritdoc
     */
    public function apply()
    {
        $this->moduleDataSetup->startSetup();
        $this->notification->moduleEnabled();
        $this->moduleDataSetup->endSetup();
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }
}
