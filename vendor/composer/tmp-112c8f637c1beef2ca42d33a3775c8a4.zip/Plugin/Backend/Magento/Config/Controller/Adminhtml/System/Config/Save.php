<?php

namespace Splitit\PaymentGateway\Plugin\Backend\Magento\Config\Controller\Adminhtml\System\Config;

use Magento\Config\Controller\Adminhtml\System\Config\Save as SaveConfig;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Splitit\PaymentGateway\Model\ValidateApiCredentials;

class Save extends SaveConfig
{
    /**
     * @var SaveConfig
     */
    private $saveConfig;

    /**
     * @var ValidateApiCredentials
     */
    private $validateApiCredentials;

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Config\Model\Config\Structure $configStructure
     * @param \Magento\Config\Controller\Adminhtml\System\ConfigSectionChecker $sectionChecker
     * @param \Magento\Config\Model\Config\Factory $configFactory
     * @param \Magento\Framework\Cache\FrontendInterface $cache
     * @param \Magento\Framework\Stdlib\StringUtils $string
     * @param ValidateApiCredentials $validateApiCredentials
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Config\Model\Config\Structure $configStructure,
        \Magento\Config\Controller\Adminhtml\System\ConfigSectionChecker $sectionChecker,
        \Magento\Config\Model\Config\Factory $configFactory,
        \Magento\Framework\Cache\FrontendInterface $cache,
        \Magento\Framework\Stdlib\StringUtils $string,
        ValidateApiCredentials $validateApiCredentials,
        ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context, $configStructure, $sectionChecker, $configFactory, $cache, $string);

        $this->validateApiCredentials = $validateApiCredentials;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Around plugin for save configuration
     *
     * @param SaveConfig $subject
     * @param \Closure $proceed
     * @return $result
     */
    public function aroundExecute(
        SaveConfig $subject,
        \Closure $proceed
    ) {
        $this->saveConfig = $subject;

        $this->updateOscCheckboxValue();

        if ($this->isSplititPaymentEnabled()) {
            if (!$this->isValideInstallmentRange()) {
                $errorMessage = 'Please add a valid, non overlapping range values for splitit installment range.';
                return $this->handleError($errorMessage);
            }

            if (!$this->isApiCredentialsValid()) {
                $errorMessage = 'Please check API credentials for Splitit payment.';
                return $this->handleError($errorMessage);
            }
        }

        return $proceed();
    }

    /**
     * Is Splitit payment enabled
     *
     * @return false
     */
    private function isSplititPaymentEnabled()
    {
        $section = $this->saveConfig->getRequest()->getParam('section');

        if ($section == 'payment') {
            $params = $this->saveConfig->getRequest()->getParams();

            return (isset($params['groups']['splitit_payment']['groups']['general']['fields']['active']['value'])
                && $params['groups']['splitit_payment']['groups']['general']['fields']['active']['value'] == 1)
                || (isset($params['groups']['splitit_payment']['groups']['general']['fields']['active']['inherit'])
                && $params['groups']['splitit_payment']['groups']['general']['fields']['active']['inherit'] == 1);
        }

        return false;
    }

    /**
     * Update osc checkbox value
     */
    private function updateOscCheckboxValue()
    {
        $params = $this->saveConfig->getRequest()->getParams();

        $oscValue = isset($params['groups']['splitit_payment']['groups']['payment']['fields']['osc']['value']) ? 1 : 0;
        $params['groups']['splitit_payment']['groups']['payment']['fields']['osc']['value'] = $oscValue;

        unset($params['key']);
        unset($params['section']);

        $this->getRequest()->setPostValue($params);
    }

    /**
     * Validate is installment range configured correct
     *
     * @return bool
     */
    private function isValideInstallmentRange()
    {
        $groups = $this->saveConfig->_getGroupsForSave();
        if (isset($groups['splitit_payment']['groups']['payment']['fields']['ranges']['value'])) {
            $ranges = $groups['splitit_payment']['groups']['payment']['fields']['ranges']['value'];
            $arr = [];
            foreach ($ranges as $range) {
                if (empty($range)) {
                    break;
                }
                $to = $range['priceTo'];
                $from = $range['priceFrom'];
                if ($to < $from) {
                    return false;
                }
                $arr[] = $from;
                $arr[] = $to;
            }

            if (!empty($arr)) {
                $originalArr = $arr;
                sort($arr);

                if (count(array_unique($arr)) < count($arr)) {
                    return false;
                }

                if ($arr != $originalArr) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Validate is API credentials are correct
     *
     * @return bool
     */
    private function isApiCredentialsValid()
    {
        $username = $this->getCredentialsValue('splitit_username');
        $password = $this->getCredentialsValue('splitit_password');
        $apiKey = $this->getCredentialsValue('merchant_gateway_key');
        $environment = $this->getCredentialsValue('environment');

        $this->validateApiCredentials->validate($username, $password, $apiKey, $environment);

        return $this->validateApiCredentials->isValid();
    }

    /**
     * Get credentials value by key
     *
     * @param string $key
     * @return mixed|string|null
     */
    private function getCredentialsValue($key)
    {
        $params = $this->saveConfig->getRequest()->getParams();

        $value = isset($params['groups']['splitit_payment']['groups']['api_credentials']['fields'][$key]['value'])
            ? $params['groups']['splitit_payment']['groups']['api_credentials']['fields'][$key]['value']
            : null;

        if ($value === null) {
            $value = isset($params['groups']['splitit_payment']['groups']['api_credentials']['fields'][$key]['inherit'])
                ? $params['groups']['splitit_payment']['groups']['api_credentials']['fields'][$key]['inherit']
                : null;
        }

        if ($value == '******') {
            $website = $this->saveConfig->getRequest()->getParam('website');
            $scopeType = $website ? ScopeInterface::SCOPE_WEBSITE : ScopeConfigInterface::SCOPE_TYPE_DEFAULT;
            $scopeCode = $website ? $website : null;

            $value = $this->scopeConfig->getValue('payment/splitit_payment/' . $key, $scopeType, $scopeCode);
        }

        return $value;
    }

    /**
     * Handle error
     *
     * @param string $errorMessage
     * @return mixed
     */
    private function handleError($errorMessage)
    {
        $this->saveConfig->messageManager->addErrorMessage(__($errorMessage));
        $this->saveConfig->_saveState($this->saveConfig->getRequest()->getPost('config_state'));

        $resultRedirect = $this->saveConfig->resultRedirectFactory->create();

        return $resultRedirect->setPath(
            'adminhtml/system_config/edit',
            [
                '_current' => ['section', 'website', 'store'],
                '_nosid' => true
            ]
        );
    }
}
