<?php

namespace Splitit\PaymentGateway\Plugin\Magento\Framework\Module;

use Splitit\PaymentGateway\Model\Statistic\Notification;
use Magento\Framework\Setup\Patch\PatchHistory;

class Status
{
    /**
     * @var Notification
     */
    private $notification;

    /**
     * @var PatchHistory
     */
    private $patchHistory;

    /**
     * @param Notification $notification
     * @param PatchHistory $patchHistory
     */
    public function __construct(
        Notification $notification,
        PatchHistory $patchHistory
    ) {
        $this->notification = $notification;
        $this->patchHistory = $patchHistory;
    }

    /**
     * @param $subject
     * @param bool $isEnabled
     * @param array $modules
     * @return array
     */
    public function beforeSetIsEnabled($subject, $isEnabled, $modules)
    {
        if ($isEnabled == false && in_array('Splitit_PaymentGateway', $modules)) {
            $this->notification->moduleDisabled();
            if ($this->patchHistory->isApplied(\Splitit\PaymentGateway\Setup\Patch\Data\FirstInstall::class)) {
                $this->patchHistory->revertPatchFromHistory(\Splitit\PaymentGateway\Setup\Patch\Data\FirstInstall::class);
            }
        }

        return [$isEnabled, $modules];
    }
}
