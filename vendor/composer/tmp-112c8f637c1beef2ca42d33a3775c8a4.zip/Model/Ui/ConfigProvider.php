<?php

namespace Splitit\PaymentGateway\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Splitit\PaymentGateway\Gateway\Config\Config;

class ConfigProvider implements ConfigProviderInterface
{
    public const CODE = 'splitit_payment';

    /**
     * @var Config
     */
    private $config;

    /**
     * @param Config $config
     */
    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    /**
     * @inheritDoc
     */
    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'minTotal' => $this->config->getSplititMinOrderAmount(),
                    'osc' => $this->config->getOsc(),
                    'maxTotal' => $this->config->getSplititMaxOrderAmount(),
                    'culture' => $this->config->getLanguageForFlexFields(),
                    'isUpstreamMessageEnabled' => $this->config->isUpstreamMessageEnabledOn('checkout'),
                    'defaultInstallments' => $this->config->getUpstreamDefaultInstallmentsNumber(),
                    'installmentsRange' => $this->config->getInstallmentRange()
                ]
            ]
        ];
    }
}
