<?php

namespace Splitit\PaymentGateway\Model;

use Splitit\PaymentGateway\Gateway\Config\Config;
use Splitit\PaymentGateway\Gateway\Login\LoginAuthentication;
use Splitit\PaymentGateway\Helper\TouchpointHelper;
use SplititSdkClient\Configuration;
use SplititSdkClient\Api\InstallmentPlanApi;

class InstallmentPlanApiObject
{
    /**
     * @var TouchpointHelper
     */
    private $touchPointHelper;

    /**
     * @var LoginAuthentication
     */
    private $loginAuth;

    /**
     * @var Config
     */
    private $splititConfig;

    /**
     * InstallmentPlanApiObject constructor.
     *
     * @param TouchpointHelper $touchPointHelper
     * @param LoginAuthentication $loginAuth
     * @param Config $splititConfig
     */
    public function __construct(
        TouchpointHelper $touchPointHelper,
        LoginAuthentication $loginAuth,
        Config $splititConfig
    ) {
        $this->touchPointHelper = $touchPointHelper;
        $this->loginAuth = $loginAuth;
        $this->splititConfig = $splititConfig;
    }

    /**
     * Create installment plan
     *
     * @return \SplititSdkClient\Api\InstallmentPlanApi
     */
    public function create()
    {
        $touchPointData = $this->touchPointHelper->getTouchPointData();
        $sessionId = $this->loginAuth->getLoginSession();
        $envSelected = $this->splititConfig->getEnvironment();
        //TODO: Inject InstallmentPlanApi.

        if ($envSelected == "sandbox") {
            Configuration::sandbox()->setTouchPoint($touchPointData);
            $installmentPlanApi = new InstallmentPlanApi(
                Configuration::sandbox(),
                $sessionId
            );
        } else {
            Configuration::production()->setTouchPoint($touchPointData);
            $installmentPlanApi = new InstallmentPlanApi(
                Configuration::production(),
                $sessionId
            );
        }

        return $installmentPlanApi;
    }
}
