<?php

namespace Splitit\PaymentGateway\Model\Statistic;

use Magento\Framework\HTTP\Client\Curl;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Send notification to Splitit Slack channel and Splitit API when plugin has been activated or deactivated
 * We use this information only for internal Splitit statistic and do not transfer data to any third-party systems
 * Format: Domain, Platform, Status
 */
class Notification
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var Curl
     */
    private $curl;

    /**
     * @param Curl $curl
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Curl $curl,
        StoreManagerInterface $storeManager
    ) {
        $this->storeManager = $storeManager;
        $this->curl = $curl;
    }

    /**
     * Send notification when module was disabled
     *
     * @return bool
     */
    public function moduleDisabled()
    {
        try {
            $this->sendInfoToSlack('deactivate');
            $this->sendInfoToApi('deactivate');
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * Send notification when module was enabled
     *
     * @return bool
     */
    public function moduleEnabled()
    {
        try {
            $this->sendInfoToSlack('activate');
            $this->sendInfoToApi('activate');
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * Send message to internal Splitit Slack channel
     *
     * @param string $status
     */
    private function sendInfoToSlack($status)
    {
        $slackKey1 = 'TGYNZCYCC';
        $slackKey2 = 'B03BBNA77DZ';
        $slackKey3 = 'Xw97npf5R1hHI8OLl615Tgwy';

        $message = 'Splitit app has been ' . $status . ' \n Domain: <' .  $this->getStoreUrl()  . '|'
            . $this->getDomain() . '> \n Platform: Magento';

        $this->sendPostRequest(
            'https://hooks.slack.com/services/' . $slackKey1 . '/' . $slackKey2 . '/' . $slackKey3,
            [
                'payload' => '{"blocks": [{"type":"section", "text": {"type": "mrkdwn", "text": "' . $message . '"}}]}'
            ]
        );
    }

    /**
     * Send message to internal Splitit API
     *
     * @param string $actionType
     */
    private function sendInfoToApi($actionType)
    {
        $this->sendPostRequest(
            'https://internalapi.production.splitit.com/api/plugins-action-logs/save',
            [
                'platform' => 'Magento',
                'actionType' => $actionType,
                'domain' => $this->getDomain()
            ]
        );
    }

    /**
     * Get site domain
     *
     * @return array|false|int|string|null
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getDomain()
    {
        return parse_url($this->getStoreUrl(), PHP_URL_HOST);
    }

    /**
     * Get site base URL
     *
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getStoreUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl();
    }

    /**
     * Send post request
     *
     * @param string $url
     * @param array $postData
     */
    private function sendPostRequest($url, $postData)
    {
        $this->curl->setOption(CURLOPT_CUSTOMREQUEST, "POST");
        $this->curl->setOption(CURLOPT_POST, true);
        $this->curl->setOption(CURLOPT_RETURNTRANSFER, true);
        $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);
        $this->curl->post($url, $postData);
    }
}
