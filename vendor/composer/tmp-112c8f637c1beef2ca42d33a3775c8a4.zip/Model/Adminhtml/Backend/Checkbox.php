<?php

namespace Splitit\PaymentGateway\Model\Adminhtml\Backend;

class Checkbox extends \Magento\Framework\App\Config\Value
{
    /**
     * @inheritDoc
     */
    public function beforeSave()
    {
        $value = $this->getValue();
        if ($value === '') {
            $this->setValue('1');
        }
        parent::beforeSave();
    }
}
