<?php

namespace Splitit\PaymentGateway\Model\Adminhtml\Form\Field;

class Checkbox extends \Magento\Framework\Data\Form\Element\Checkbox
{
    /**
     * @inheritDoc
     */
    public function getElementHtml()
    {
        if ($checked = $this->getIsChecked()) {
            $this->setData('checked', true);
        } else {
            $this->unsetData('checked');
        }
        return parent::getElementHtml();
    }

    /**
     * @inheritDoc
     */
    public function setIsChecked($value = false)
    {
        $this->setData('checked', $value == '1');
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getIsChecked()
    {
        $this->setChecked($this->getValue() == '1');
        return $this->getChecked();
    }
}
