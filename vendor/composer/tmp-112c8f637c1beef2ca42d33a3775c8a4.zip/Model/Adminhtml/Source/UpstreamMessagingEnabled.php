<?php

namespace Splitit\PaymentGateway\Model\Adminhtml\Source;

class UpstreamMessagingEnabled implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @inheritDoc
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'home page', 'label' => __('home page')],
            ['value' => 'product page', 'label' => __('product page')],
            ['value' => 'cart', 'label' => __('cart')],
            ['value' => 'footer', 'label' => __('footer')]
        ];
    }

    /**
     * Return array of options as key:label
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'home page' => __('home page'),
            'product page' => __('product page'),
            'cart' => __('cart'),
            'footer' => __('footer')
        ];
    }
}
