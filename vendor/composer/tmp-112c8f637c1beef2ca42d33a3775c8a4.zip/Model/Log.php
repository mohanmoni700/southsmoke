<?php

namespace Splitit\PaymentGateway\Model;

use Magento\Framework\Model\AbstractModel;
use Splitit\PaymentGateway\Model\ResourceModel\Log as LogResource;

/**
 * Log Splitit transactions
 */
class Log extends AbstractModel
{
    public const ENTITY_ID = 'entity_id';
    public const QUOTE_ID = 'quote_id';
    public const INCREMENT_ID = 'increment_id';
    public const SUCCESS = 'success';
    public const ASYNC = 'async';
    public const INSTALLMENT_PLAN_NUMBER = 'installment_plan_number';

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(LogResource::class);
    }

    /**
     * Get quote id
     *
     * @return int
     */
    public function getQuoteId()
    {
        return (int) $this->_getData(self::QUOTE_ID);
    }

    /**
     * Get increment id
     *
     * @return int|null
     */
    public function getIncrementId()
    {
        return $this->_getData(self::INCREMENT_ID);
    }

    /**
     * Is success
     *
     * @return bool|null
     */
    public function isSuccess()
    {
        return $this->_getData(self::SUCCESS);
    }

    /**
     * Is async
     *
     * @return bool|null
     */
    public function isAsync()
    {
        return $this->_getData(self::ASYNC);
    }

    /**
     * Get installment plan number
     *
     * @return string
     */
    public function getInstallmentPlanNumber()
    {
        return (string) $this->_getData(self::INSTALLMENT_PLAN_NUMBER);
    }

    /**
     * Set quote id
     *
     * @param int $quoteId
     * @return $this
     */
    public function setQuoteId($quoteId)
    {
        $this->setData(self::QUOTE_ID, $quoteId);

        return $this;
    }

    /**
     * Set increment id
     *
     * @param int|null $incrementId
     * @return $this
     */
    public function setIncrementId($incrementId = null)
    {
        $this->setData(self::INCREMENT_ID, $incrementId);

        return $this;
    }

    /**
     * Set is success flag
     *
     * @param bool|null $isSuccess
     * @return $this
     */
    public function setIsSuccess($isSuccess = null)
    {
        $this->setData(self::SUCCESS, $isSuccess);

        return $this;
    }

    /**
     * Set is async flag
     *
     * @param bool|null $isAsync
     * @return $this
     */
    public function setIsAsync($isAsync = null)
    {
        $this->setData(self::ASYNC, $isAsync);

        return $this;
    }

    /**
     * Set installment plan number
     *
     * @param string $installmentPlanNumber
     * @return $this
     */
    public function setInstallmentPlanNumber($installmentPlanNumber)
    {
        $this->setData(self::INSTALLMENT_PLAN_NUMBER, $installmentPlanNumber);

        return $this;
    }
}
