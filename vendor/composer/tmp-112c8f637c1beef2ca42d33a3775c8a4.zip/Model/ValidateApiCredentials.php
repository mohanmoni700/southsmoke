<?php

namespace Splitit\PaymentGateway\Model;

use Splitit\PaymentGateway\Gateway\Login\LoginAuthentication;

class ValidateApiCredentials
{
    /**
     * @var LoginAuthentication
     */
    private $loginAuth;

    /**
     * @var bool
     */
    private $status;

    /**
     * @var string
     */
    private $errorMessage;

    /**
     * @var string
     */
    private $successMessage;

    /**
     * @param LoginAuthentication $loginAuth
     */
    public function __construct(
        LoginAuthentication $loginAuth
    ) {
        $this->loginAuth = $loginAuth;
    }

    /**
     * Validate API credentials
     *
     * @param string $username
     * @param string $password
     * @param string $apiKey
     * @param string $envSelected
     */
    public function validate($username, $password, $apiKey, $envSelected)
    {
        $this->status = false;
        $this->errorMessage = "";
        $this->successMessage = "";

        if (!empty($username) && !empty($password) && !empty($apiKey) && !empty($envSelected)) {
            $sessionId = $this->loginAuth->verifyCredentials($username, $password, $apiKey, $envSelected);
            if (!empty($sessionId)) {
                $this->successMessage = "Credentials are valid!";
                $this->status = true;
            } else {
                $this->errorMessage = "Invalid Credentials. Please enter valid credentials and try again!";
            }
        } else {
            $this->errorMessage = "Please enter the credentials (api key, username, password).";
        }
    }

    /**
     * Get validation status
     *
     * @return bool
     */
    public function isValid()
    {
        return $this->status;
    }

    /**
     * Get error message
     *
     * @return string
     */
    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    /**
     * Get success message
     *
     * @return string
     */
    public function getSuccessMessage()
    {
        return $this->successMessage;
    }
}
