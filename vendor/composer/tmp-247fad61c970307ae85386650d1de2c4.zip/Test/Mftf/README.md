# Gift Wrapping Staging Functional Tests

The Functional Test Module for **Magento Gift Wrapping Staging** module.
