<?php
/**
 * Paradox Labs, Inc.
 * http://www.paradoxlabs.com
 * 717-431-3330
 *
 * Need help? Open a ticket in our support system:
 *  http://support.paradoxlabs.com
 *
 * @author      Chad Bender <support@paradoxlabs.com>
 * @license     http://store.paradoxlabs.com/license.html
 */

namespace ParadoxLabs\FirstData\Model;

use Magento\Payment\Gateway\Command\CommandException;

/**
 * First Data card model
 */
class Card extends \ParadoxLabs\TokenBase\Model\Card
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $config;

    /**
     * Card constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \ParadoxLabs\TokenBase\Model\Card\Context $cardContext
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $config
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \ParadoxLabs\TokenBase\Model\Card\Context $cardContext,
        \Magento\Framework\App\Config\ScopeConfigInterface $config,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $extensionFactory, $customAttributeFactory, $cardContext, $resource,
            $resourceCollection, $data);
        $this->config = $config;
    }

    /**
     * Finalize before saving.
     *
     * return $this
     */
    public function beforeSave()
    {
        // Send only if we have an info instance for payment data
        if ($this->hasData('info_instance') && $this->getData('no_sync') !== true) {
            if ($this->getInfoInstance() !== null && $this->getInfoInstance()->getData('cc_number') != '') {
                $this->sendDataForTokenization();
            }
        }

        // If we're using 'Save only' transactions, attempt to perform a $0 auth to validate the data.
        if ($this->config->getValue('payment/paradoxlabs_firstdata/payment_action') === 'order'
            && $this->getInfoInstance() !== null
            && $this->getInfoInstance()->getAdditionalInformation('is_valid') !== true){
            /** @var \ParadoxLabs\FirstData\Model\Gateway $gateway */
            $gateway = $this->getMethodInstance()->gateway();
            $gateway->setCard($this);
            $payment = $this->getInfoInstance();
            $gateway->authorize($payment, "0.00");
            // Limit the auth to ONCE per order payment.
            $payment->setAdditionalInformation('is_valid', true);
        }

        parent::beforeSave();

        return $this;
    }

    /**
     * Attempt to create token data.
     *
     * @return $this
     * @throws CommandException
     */
    protected function sendDataForTokenization()
    {
        $this->helper->log(
            $this->getMethod(),
            sprintf(
                'sendDataForTokenization() (payment_id %s)',
                var_export($this->getPaymentId(), 1)
            )
        );

        $this->getMethodInstance()->setCard($this);

        /** @var \ParadoxLabs\FirstData\Model\Gateway $gateway */
        $gateway = $this->getMethodInstance()->gateway();

        $gateway->setCardBillingInfo($this);

        $this->setPaymentInfoOnCreate($gateway);

        $paymentId = $gateway->tokenizeCreditCard();

        $response = $gateway->getLastResponse();

        if ($response['status'] == 'failed' || empty($paymentId)) {
            //Handles if multiple errors are thrown
            $errors = $this->helper->getArrayValue($response, 'Error/messages');
            $errorTextArray = [];
            $errorMsgArray = [];

            foreach ($errors as $error) {
                $errorCode = $error['code'];
                $errorText = $error['description'];

                //Pushes error text to array to be used to display error(s) on frontend
                $errorTextArray[] = $errorText;

                /*
                 * Creates string to be used in log
                 * This allows all the errors to be logged in one line instead of one line per error
                 */
                $errorMsg = sprintf('%s (%s)', $errorText, $errorCode);
                $errorMsgArray[] = $errorMsg;
            }

            $this->helper->log($this->getMethod(), sprintf('API error: %s', implode(',', $errorMsgArray)));
            $gateway->logLogs();

            //Returns a comma-delimited string of all the errors
            throw new CommandException(__('First Data Gateway: %1', implode(',', $errorTextArray)));
        }

        if (!empty($paymentId)) {
            /**
             * Prevent data from being updated multiple times in one request.
             */
            $this->setPaymentId($paymentId);
            $this->setData('no_sync', true);
        } else {
            $gateway->logLogs();

            throw new CommandException(__('First Data Gateway: Unable to create payment record.'));
        }

        return $this;
    }

    /**
     * On card save, set payment data to the gateway. (Broken out for extensibility)
     *
     * @param \ParadoxLabs\TokenBase\Api\GatewayInterface $gateway
     * @return $this
     */
    protected function setPaymentInfoOnCreate(\ParadoxLabs\TokenBase\Api\GatewayInterface $gateway)
    {
        /** @var \Magento\Sales\Model\Order\Payment $info */
        $info = $this->getInfoInstance();
        $cardType = $this->helper->mapCcTypeToFirstData($info->getData('cc_type'));
        $gateway->setParameter('credit_card_type', $cardType);
        $gateway->setParameter('card_number', $info->getData('cc_number'));
        $gateway->setParameter('cvv', $info->getData('cc_cid'));
        $gateway->setParameter(
            'exp_date',
            sprintf('%02d-%02d', $info->getData('cc_exp_month'), substr($info->getData('cc_exp_year'), -2))
        );

        return $this;
    }
}
