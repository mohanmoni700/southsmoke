# Catalog Import Export Functional Tests

The Functional Test Module for **Magento Catalog Import Export** module.
