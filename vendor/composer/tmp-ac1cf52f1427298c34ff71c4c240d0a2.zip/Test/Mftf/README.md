# Catalog Staging Functional Tests

The Functional Test Module for **Magento Catalog Staging** module.
