# Gift Card Negotiable Quote Functional Tests

The Functional Test Module for **Magento Gift Card Negotiable Quote** module.
