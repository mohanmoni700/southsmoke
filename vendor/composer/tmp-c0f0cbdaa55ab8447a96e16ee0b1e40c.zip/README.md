# ConfigurableRequisitionListGraphQl

**ConfigurableRequisitionListGraphQl** provides GraphQL schema and resolvers for the requisition list module to extend and implement configurable products in requisition list
