<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Helper;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\ObjectManagerInterface;
use Magento\SalesRule\Model\Coupon;
use Magento\Store\Model\StoreManagerInterface;
use Mageplaza\Core\Helper\AbstractData;
use Mageplaza\MultipleCoupons\Model\Config\Source\ApplyPage;

/**
 * Class Data
 * @package Mageplaza\MultipleCoupons\Helper
 */
class Data extends AbstractData
{
    const CONFIG_MODULE_PATH = 'mpmultiplecoupons';
    const COUPON_DELIMITER   = ';';

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Coupon
     */
    protected $coupon;

    /**
     * Data constructor.
     *
     * @param Context $context
     * @param ObjectManagerInterface $objectManager
     * @param StoreManagerInterface $storeManager
     * @param Coupon $coupon
     * @param Session $session
     */
    public function __construct(
        Context $context,
        ObjectManagerInterface $objectManager,
        StoreManagerInterface $storeManager,
        Coupon $coupon,
        Session $session
    ) {
        $this->coupon  = $coupon;
        $this->session = $session;

        parent::__construct($context, $objectManager, $storeManager);
    }

    /**
     * @param null $storeId
     *
     * @return array
     */
    public function getApplyPage($storeId = null)
    {
        return explode(',', $this->getConfigGeneral('apply_page', $storeId));
    }

    /**
     * @param null $storeId
     *
     * @return float
     */
    public function getLimitQty($storeId = null)
    {
        return floatval($this->getConfigGeneral('limit_qty', $storeId));
    }

    /**
     * @param null $storeId
     *
     * @return array
     */
    public function getUniqueCodes($storeId = null)
    {
        return array_map('trim', preg_split('/\r\n|\r|\n/', $this->getConfigGeneral('unique_codes', $storeId)));
    }

    /**
     * @param null $storeId
     *
     * @return bool
     */
    public function isApplyFor($storeId = null)
    {
        $page = $this->isAdmin() ? ApplyPage::ADMIN_CHECKOUT : ApplyPage::FRONT_CHECKOUT;

        return $this->isEnabled($storeId) && in_array($page, $this->getApplyPage($storeId));
    }

    /**
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getAppliedCodes()
    {
        $quote = $this->session->getQuote();

        if (!$couponCodes = $quote->getCouponCode()) {
            return [];
        }

        $coupons = $this->formatCodeArray($couponCodes);
        $rules   = $this->formatCodeArray($quote->getAppliedRuleIds(), ',');

        if (!$rules) {
            return [];
        }

        foreach ($coupons as $key => $code) {
            $coupon = $this->coupon->loadByCode($code);
            if (!$this->coupon->getResource()->exists($code) || !in_array($coupon->getRuleId(), $rules)) {
                unset($coupons[$key]);
            }
        }

        $coupons = array_unique($coupons);
        return $coupons;
    }

    /**
     * @param string $data
     * @param string $delimiter
     *
     * @return array
     */
    public function formatCodeArray($data, $delimiter = self::COUPON_DELIMITER)
    {
        return array_unique(array_filter(explode($delimiter, $data), 'strlen'));
    }

    /**
     * @param null $storeId
     *
     * @return bool
     */
    public function isOscPage($storeId = null)
    {
        return $this->isEnabled($storeId) && $this->_request->getRouteName() == 'onestepcheckout';
    }

    /**
     * @param $couponCode
     *
     * @return array|null
     */
    public function getCouponsCodes($couponCode)
    {
        return $couponCode ? $this->formatCodeArray($couponCode) : [];
    }

    /**
     * @return boolean
     */

    public function checkVersion()
    {
        $productMetadata = $this->objectManager->get(ProductMetadataInterface::class);
        $version         = $productMetadata->getVersion(); //will return the magento version

        return version_compare($version, "2.2.8", ">=") && version_compare($version, "2.3.0", "!=");
    }
}
