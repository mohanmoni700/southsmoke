<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Block\Cart;

use Magento\Checkout\Block\Checkout\LayoutProcessorInterface;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class LayoutProcessor
 * @package Mageplaza\MultipleCoupons\Block\Cart
 */
class LayoutProcessor implements LayoutProcessorInterface
{
    /**
     * @var Data
     */
    protected $data;

    /**
     * LayoutProcessor constructor.
     *
     * @param Data $data
     */
    public function __construct(Data $data)
    {
        $this->data = $data;
    }

    /**
     * @param array $jsLayout
     *
     * @return array
     */
    public function process($jsLayout)
    {
        if (!$this->data->isApplyFor()) {
            return $jsLayout;
        }

        if ($this->data->checkVersion()) {
            $discount = &$jsLayout['components']['block-totals']['children']['discount'];
        } else {
            $discount = &$jsLayout['components']['block-totals']['children']['before_grandtotal']['children']['discount'];
        }

        $discount['component'] = 'Mageplaza_MultipleCoupons/js/view/totals/discount';
        $discount['sortOrder'] = 30;

        return $jsLayout;
    }
}
