<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Block\Sales\Order;

use Magento\Framework\DataObject;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Creditmemo;
use Magento\Sales\Model\Order\Invoice;
use Magento\SalesRule\Model\CouponFactory;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\RuleFactory;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class Discount
 *
 * @package Mageplaza\MultipleCoupons\Block\Sales\Order
 */
class Discount extends Template
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * @var Rule
     */
    private $rule;

    /**
     * @var CouponFactory
     */
    private $coupon;

    /**
     * Discount constructor.
     *
     * @param Template\Context $context
     * @param Data $helper
     * @param CouponFactory $coupon
     * @param RuleFactory $rule
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        CouponFactory $coupon,
        RuleFactory $rule,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->coupon = $coupon;
        $this->rule   = $rule;
        parent::__construct($context, $data);
    }

    /**
     * @return $this
     */
    public function initTotals()
    {
        $parent = $this->getParentBlock();
        /** @var Order|Invoice|Creditmemo $source */
        $source = $parent->getSource();

        $couponCode = $source->getCouponCode();
        if ($source->getOrder()) {
            $couponCode = $source->getOrder()->getCouponCode();
        }

        if (strlen($couponCode) && abs($source->getDiscountAmount()) > 0) {
            $coupons = preg_split("/[;,]/", $couponCode);

            $label = '';
            foreach ($coupons as $code) {
                $coupon = $this->coupon->create()->loadByCode($code);
                if ($coupon->getRuleId()) {
                    $rule      = $this->rule->create()->load($coupon->getRuleId());
                    $ruleLabel = $rule->getStoreLabel($source->getStoreId()) ?: $code;
                    if (strlen($label)) {
                        $label .= ', ';
                    }
                    $label .= $ruleLabel;
                }
            }

            $parent->addTotal(new DataObject([
                'code'       => 'discount',
                'value'      => $source->getDiscountAmount(),
                'base_value' => $source->getBaseDiscountAmount(),
                'label'      => __('Discount (%1)', $label)
            ]), 'tax');
        }

        return $this;
    }
}
