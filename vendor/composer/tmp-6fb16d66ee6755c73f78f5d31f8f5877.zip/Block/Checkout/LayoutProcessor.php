<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Block\Checkout;

use Magento\Checkout\Block\Checkout\LayoutProcessorInterface;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class LayoutProcessor
 * @package Mageplaza\MultipleCoupons\Block\Checkout
 */
class LayoutProcessor implements LayoutProcessorInterface
{
    /**
     * @var Data
     */
    protected $data;

    /**
     * LayoutProcessor constructor.
     *
     * @param Data $data
     */
    public function __construct(Data $data)
    {
        $this->data = $data;
    }

    /**
     * Process js Layout of block
     *
     * @param array $jsLayout
     *
     * @return array
     */
    public function process($jsLayout)
    {
        if (!$this->data->isApplyFor()) {
            return $jsLayout;
        }

        $discount = [
            'component' => 'Mageplaza_MultipleCoupons/js/view/checkout',
            'config'    => [
                'template' => 'Mageplaza_MultipleCoupons/checkout/payment'
            ],
            'children'  => [
                'messages' => [
                    'component'   => 'Mageplaza_MultipleCoupons/js/view/messages',
                    'displayArea' => 'messages'
                ]
            ]
        ];

        $discountAmount = &$jsLayout['components']['checkout']['children']['sidebar']['children']['summary']['children']['totals']['children']['discount'];

        $discountAmount['component'] = 'Mageplaza_MultipleCoupons/js/view/totals/discount';
        $discountAmount['sortOrder'] = 30;

        if (!$this->data->isOscPage()) {
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
            ['children']['payment']['children']['afterMethods']['children']['discount'] = $discount;

            return $jsLayout;
        }

        /** @var \Mageplaza\Osc\Helper\Data $oscHelper */
        $oscHelper = $this->data->getObject(\Mageplaza\Osc\Helper\Data::class);

        if (!$oscHelper->disabledPaymentCoupon()) {
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
            ['children']['payment']['children']['afterMethods']['children']['discount'] = $discount;
        }

        if (!$oscHelper->disabledReviewCoupon()) {
            $jsLayout['components']['checkout']['children']['sidebar']['children']['place-order-information-left']['children']['discount'] = $discount;
        }

        return $jsLayout;
    }
}
