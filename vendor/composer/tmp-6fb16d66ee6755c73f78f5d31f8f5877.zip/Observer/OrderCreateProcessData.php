<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Sales\Model\AdminOrder\Create;
use Magento\SalesRule\Model\Coupon;
use Magento\SalesRule\Model\Rule;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class OrderCreateProcessData
 * @package Mageplaza\MultipleCoupons\Observer
 */
class OrderCreateProcessData implements ObserverInterface
{
    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var Coupon
     */
    protected $coupon;

    /**
     * @var Data
     */
    protected $data;

    /**
     * @var Rule
     */
    protected $rule;

    /**
     * OrderCreateProcessData constructor.
     *
     * @param ManagerInterface $messageManager
     * @param RequestInterface $request
     * @param Coupon $coupon
     * @param Data $data
     * @param Rule $rule
     */
    public function __construct(
        ManagerInterface $messageManager,
        RequestInterface $request,
        Coupon $coupon,
        Data $data,
        Rule $rule
    ) {
        $this->messageManager = $messageManager;
        $this->request        = $request;
        $this->coupon         = $coupon;
        $this->data           = $data;
        $this->rule           = $rule;
    }

    /**
     * @param Observer $observer
     *
     * @return $this
     */
    public function execute(Observer $observer)
    {
        /** @var Create $model */
        $model = $observer->getEvent()->getOrderCreateModel();
        $data  = $observer->getEvent()->getRequest();
        $quote = $model->getQuote();

        $storeId = $quote->getStoreId();

        $couponCode = $quote->getCouponCode();
        $isApplyFor = $this->data->isApplyFor($storeId) && isset($data['order']['coupon']['code']);

        if (!$isApplyFor) {
            return $this;
        }

        $isRemove    = $data['order']['coupon']['remove'];
        $originCodes = $this->data->formatCodeArray($couponCode);

        unset($data['order']['coupon']);
        $this->request->setPostValue('order', $data['order']);

        if (!$isRemove && $quote->getBaseSubtotalWithDiscount() <= 0) {
            $quote->setCouponCode(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [end($originCodes)])));

            $this->messageManager->addErrorMessage(__('Could not apply more coupon codes on this cart.'));

            return $this;
        }

        foreach (array_count_values(array_filter(
            explode(Data::COUPON_DELIMITER, $couponCode),
            'strlen'
        )) as $code => $item) {
            if ($item > 1) {
                $quote->setCouponCode(implode(Data::COUPON_DELIMITER, $originCodes));

                $this->messageManager->addErrorMessage(__('Could not apply coupon code "%1".', $code));

                return $this;
            }
        }

        $intersectCodes = array_intersect($originCodes, $this->data->getUniqueCodes($storeId));

        if (!empty($intersectCodes)) {
            $quote->setCouponCode(end($intersectCodes));

            end($intersectCodes) != end($originCodes)
                ? $this->messageManager->addErrorMessage(__('You are using an unique coupon. To add other coupons, please remove this unique one.'))
                : $this->messageManager->addSuccessMessage(__('The coupon code has been accepted.'));

            return $this;
        }

        if (empty($intersectCodes) && $this->data->getLimitQty($storeId) && count($originCodes) > $this->data->getLimitQty($storeId)) {
            $quote->setCouponCode(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [end($originCodes)])));

            $this->messageManager->addErrorMessage(__('Coupon quantity limit has been reached.'));

            return $this;
        }

        $model->saveQuote();

        $rules = array_unique(array_filter(explode(',', $quote->getAppliedRuleIds()), 'strlen'));

        foreach ($originCodes as $key => $code) {
            $coupon = $this->coupon->loadByCode($code);
            if (!$this->coupon->getResource()->exists($code) || !in_array($coupon->getRuleId(), $rules)) {
                $quote->setCouponCode(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [$code])));

                $this->messageManager->addErrorMessage(__('Could not apply coupon code "%1".', $code));

                return $this;
            }
        }

        $quote->setCouponCode(implode(Data::COUPON_DELIMITER, $originCodes));

        $message = $isRemove ? __('The coupon code has been removed.') : __('The coupon code has been accepted.');

        $this->messageManager->addSuccessMessage($message);

        return $this;
    }
}
