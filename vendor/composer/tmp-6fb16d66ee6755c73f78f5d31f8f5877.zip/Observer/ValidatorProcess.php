<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\Rule\Action\Discount\Data;
use Mageplaza\MultipleCoupons\Model\RuleManagement;

/**
 * Class ValidatorProcess
 * @package Mageplaza\MultipleCoupons\Observer
 */
class ValidatorProcess implements ObserverInterface
{
    /**
     * @var string
     */
    protected $simpleAction;

    /**
     * @var RuleManagement
     */
    protected $ruleManagement;

    /**
     * CouponObserver constructor.
     *
     * @param RuleManagement $ruleManagement
     */
    public function __construct(RuleManagement $ruleManagement)
    {
        $this->ruleManagement = $ruleManagement;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        /** @var Rule $rule */
        $rule = $observer->getData('rule');
        //get Action by rule
        $this->simpleAction = $rule->getSimpleAction();
        /** @var Data $result */
        $result = $observer->getData('result');
        /** @var Quote $quote */
        $quote = $observer->getData('quote');

        if ($code = $rule->getCode()) {
            $this->ruleManagement->setRule($code, $result->getBaseAmount(), $rule->getStoreLabel($quote->getStoreId()));
        }
    }
}
