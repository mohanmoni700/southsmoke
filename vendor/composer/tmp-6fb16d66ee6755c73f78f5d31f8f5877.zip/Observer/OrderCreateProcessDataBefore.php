<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\AdminOrder\Create;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class OrderCreateProcessDataBefore
 * @package Mageplaza\MultipleCoupons\Observer
 */
class OrderCreateProcessDataBefore implements ObserverInterface
{
    /**
     * @var Data
     */
    protected $data;

    /**
     * OrderCreateProcessDataBefore constructor.
     *
     * @param Data $data
     */
    public function __construct(Data $data)
    {
        $this->data = $data;
    }

    /**
     * @param Observer $observer
     *
     * @return $this
     */
    public function execute(Observer $observer)
    {
        /** @var Create $model */
        $model = $observer->getEvent()->getOrderCreateModel();
        /** @var RequestInterface $request */
        $request = $observer->getEvent()->getRequestModel();
        $quote   = $model->getQuote();
        $data    = $request->getPostValue();

        $isApplyFor = $this->data->isApplyFor($quote->getStoreId()) && isset($data['order']['coupon']['code']);

        if (!$isApplyFor) {
            return $this;
        }

        $originCodes  = $this->data->formatCodeArray($data['order']['coupon']['code']);
        $appliedCodes = $this->data->formatCodeArray($quote->getCouponCode());

        $data['order']['coupon']['remove'] = (count($originCodes) < count($appliedCodes));
        $request->setPostValue('order', $data['order']);

        return $this;
    }
}
