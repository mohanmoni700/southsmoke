<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Observer;

use Exception;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use Magento\SalesRule\Model\Coupon;
use Magento\SalesRule\Model\ResourceModel\Coupon\Usage;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class SalesOrderPlaceAfter
 * @package Mageplaza\MultipleCoupons\Observer
 */
class SalesOrderPlaceAfter implements ObserverInterface
{
    /**
     * @var Data
     */
    protected $data;

    /**
     * @var Coupon
     */
    protected $_coupon;

    /**
     * @var Usage
     */
    protected $_couponUsage;

    /**
     * @var array
     */
    protected $checkedCodes = [];

    /**
     * SalesOrderPlaceAfter constructor.
     *
     * @param Data $data
     * @param Coupon $coupon
     * @param Usage $couponUsage
     */
    public function __construct(
        Data $data,
        Coupon $coupon,
        Usage $couponUsage
    ) {
        $this->data         = $data;
        $this->_coupon      = $coupon;
        $this->_couponUsage = $couponUsage;
    }

    /**
     * @param Observer $observer
     *
     * @return $this
     * @throws Exception
     */
    public function execute(Observer $observer)
    {
        /** @var Order $order */
        $order = $observer->getEvent()->getOrder();

        if (!$order) {
            return $this;
        }

        $customerId = $order->getCustomerId();
        $coupons    = $this->data->formatCodeArray($order->getCouponCode());

        if (!$customerId || !count($coupons)) {
            return $this;
        }

        foreach ($coupons as $code) {
            if ($this->_coupon->getResource()->exists($code)) {
                $this->_coupon->loadByCode($code);
                $this->_coupon->setTimesUsed($this->_coupon->getTimesUsed() + 1);
                $this->_coupon->save();
                $this->_couponUsage->updateCustomerCouponTimesUsed($customerId, $this->_coupon->getId());
            }
        }

        return $this;
    }
}
