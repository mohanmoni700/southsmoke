/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'ko',
        'Magento_Checkout/js/model/quote'
    ],
    function(ko, quote) {
        "use strict";

        var couponDelimiter = window.checkoutConfig.mpMultipleCoupons.couponDelimiter;

        var couponCode = ko.computed(function() {
            if (quote.getTotals()()['coupon_code']){
                return quote.getTotals()()['coupon_code'];
            }

            return '';
        });

        var checkoutModel = {
            couponDelimiter: couponDelimiter,
            couponCode: couponCode,
            inputCode: ko.observable(''),
            isLoading: ko.observable(false),
            arrayCode: ko.computed(function() {
                return couponCode() ? couponCode().split(couponDelimiter) : [];
            }),

            initialize: function() {
                var self = this;

                this.isApplied = ko.computed(function() {
                    return self.arrayCode().length > 0;
                });

                this.checkAndDisplayCodeInput();

                return this;
            },

            checkAndDisplayCodeInput: function() {
                this.inputCode('');
            }
        };

        return checkoutModel.initialize();
    }
);

