/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery',
        'ko',
        'underscore',
        'uiComponent',
        'Mageplaza_MultipleCoupons/js/model/checkout',
        'Mageplaza_MultipleCoupons/js/action/apply-coupon',
        'Mageplaza_MultipleCoupons/js/action/cancel-coupon',
        'mage/translate'
    ],
    function($, ko, _, Component, checkout, applyAction, cancelAction, $t) {
        'use strict';

        var couponDelimiter = checkout.couponDelimiter;

        return Component.extend({
            defaults: {
                template: 'Mageplaza_MultipleCoupons/checkout/cart'
            },

            blockTitle: $t('Apply Discount Code'),
            couponCode: checkout.couponCode,
            inputCode: checkout.inputCode,
            arrayCode: checkout.arrayCode,
            isLoading: checkout.isLoading,
            isApplied: checkout.isApplied,

            apply: function() {
                var form = $('#discount-mpmultiplecoupons-form');

                form.validation();

                if (form.valid() && this.inputCode()){
                    var arrayCode = this.couponCode() ? this.couponCode().split(couponDelimiter) : [];

                    arrayCode.push(this.inputCode());

                    applyAction(arrayCode.join(couponDelimiter), false);
                }
            },

            cancel: function(code) {
                var arrayCode = this.couponCode() ? this.couponCode().split(couponDelimiter) : [];

                arrayCode = _.without(arrayCode, code);

                if (arrayCode.length){
                    applyAction(arrayCode.join(couponDelimiter), true);
                } else {
                    cancelAction();
                }
            }
        });
    }
);

