/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'ko',
        'jquery',
        'mage/storage',
        'Magento_Checkout/js/model/quote',
        'Mageplaza_MultipleCoupons/js/model/checkout',
        'Magento_Checkout/js/model/resource-url-manager',
        'Mageplaza_MultipleCoupons/js/model/messageList',
        'Magento_Checkout/js/model/totals',
        'Magento_Checkout/js/action/get-totals',
        'Magento_Checkout/js/action/get-payment-information',
        'mage/translate'
    ],
    function(ko, $, storage, quote, checkout, urlManager, messageContainer, totals, getTotalsAction, getPaymentInformationAction, $t) {
        'use strict';

        return function() {
            var url     = urlManager.getCancelCouponUrl(quote.getQuoteId()),
                message = $t('Remove discount code successfully.');

            checkout.isLoading(true);

            return storage.delete(
                url, false
            ).done(function(response) {
                if (!response){
                    return;
                }

                var deferred = $.Deferred();

                totals.isLoading(true);

                if ($('body').hasClass('checkout-cart-index')){
                    getTotalsAction([], deferred);
                } else {
                    getPaymentInformationAction(deferred);
                }

                $.when(deferred).done(function() {
                    checkout.isLoading(false);
                    totals.isLoading(false);
                });

                checkout.checkAndDisplayCodeInput();
                messageContainer.addSuccessMessage({'message': message});
            }).fail(function(response) {
                checkout.isLoading(false);
                totals.isLoading(false);
                messageContainer.addErrorMessage(JSON.parse(response.responseText));
            });
        };
    }
);

