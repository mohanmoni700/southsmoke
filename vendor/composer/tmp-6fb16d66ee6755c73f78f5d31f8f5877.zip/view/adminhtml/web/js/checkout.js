/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(['jquery', 'underscore'], function($, _) {
    'use strict';

    $('#order-items').on('click', '.action-remove', function() {
        var code  = $(this).next().filter('.mpmultiplecoupons').val(),
            codes = [];

        _.each($('.mpmultiplecoupons'), function(elem) {
            codes.push(elem.value);
        });

        codes = _.without(codes, code);

        window.order.applyCoupon(codes.join(window.mpMultipleCouponsDelimiter));
    });

    $('body').on('click', '.discount.row-totals', function() {
        var max  = $('body .row-totals').length,
            show = $(this).hasClass('hide-details');

        for (var i = 0; i <= max; i++){
            var child = $('.mpmultiplecoupons' + i);
            if (child.length){
                if (show){
                    child.show();
                } else {
                    child.hide();
                }
            }
        }

        if (show){
            $(this).removeClass('hide-details');
        } else {
            $(this).addClass('hide-details');
        }
    });
});
