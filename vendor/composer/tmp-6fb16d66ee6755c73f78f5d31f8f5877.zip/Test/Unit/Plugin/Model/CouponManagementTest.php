<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Test\Unit\Plugin\Model;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\QuoteRepository;
use Mageplaza\MultipleCoupons\Helper\Data;
use Mageplaza\MultipleCoupons\Plugin\Model\CouponManagement;
use PHPUnit_Framework_MockObject_MockObject;
use PHPUnit_Framework_TestCase;

/**
 * Class CouponManagementTest
 * @package Mageplaza\MultipleCoupons\Test\Unit\Plugin\Model
 */
class CouponManagementTest extends PHPUnit_Framework_TestCase
{
    /**
     * @var QuoteRepository|PHPUnit_Framework_MockObject_MockObject
     */
    private $quoteRepository;

    /**
     * @var Data|PHPUnit_Framework_MockObject_MockObject
     */
    private $data;

    /**
     * @var CouponManagement
     */
    private $object;

    protected function setUp(): void
    {
        $this->quoteRepository = $this->getMockBuilder(QuoteRepository::class)->disableOriginalConstructor()->getMock();
        $this->data            = $this->getMockBuilder(Data::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'isEnabled',
                'getAppliedCodes',
                'formatCodeArray',
                'getUniqueCodes',
                'getLimitQty',
                'isApplyFor'
            ])
            ->getMock();

        $this->object = new CouponManagement($this->quoteRepository, $this->data);
    }

    public function testAroundSetZeroSubtotal()
    {
        /** @var \Magento\Quote\Model\CouponManagement|PHPUnit_Framework_MockObject_MockObject $subject */
        $subject = $this->getMockBuilder(\Magento\Quote\Model\CouponManagement::class)->disableOriginalConstructor()->getMock();
        $cartId  = 3;
        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB' . Data::COUPON_DELIMITER . 'codeC';
        $oldCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $oldCode, $unqCode);

        try {
            $this->object->aroundSet($subject, $this->mockPluginProceed([$cartId, $newCode]), $cartId, $newCode);
        } catch (CouldNotSaveException $exception) {
            $this->assertEquals(
                new CouldNotSaveException(new Phrase('Could not apply more coupon codes on this cart.')),
                $exception
            );
        } catch (NoSuchEntityException $exception) {
        }
    }

    public function testAroundSetUniqueCoupon()
    {
        /** @var \Magento\Quote\Model\CouponManagement|PHPUnit_Framework_MockObject_MockObject $subject */
        $subject = $this->getMockBuilder(\Magento\Quote\Model\CouponManagement::class)->disableOriginalConstructor()->getMock();
        $cartId  = 3;
        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeC';
        $oldCode = 'codeA';
        $unqCode = 'codeC';

        $this->prepareCodeData($newCode, $oldCode, $unqCode, 2, 10);

        try {
            $this->object->aroundSet($subject, $this->mockPluginProceed([$cartId, $newCode]), $cartId, $newCode);
        } catch (CouldNotSaveException $exception) {
            $this->assertEquals(
                new CouldNotSaveException(new Phrase('You are using an unique coupon. To add other coupons, please remove this unique one.')),
                $exception
            );
        } catch (NoSuchEntityException $exception) {
        }
    }

    public function testAroundSetLimitQty()
    {
        /** @var \Magento\Quote\Model\CouponManagement|PHPUnit_Framework_MockObject_MockObject $subject */
        $subject = $this->getMockBuilder(\Magento\Quote\Model\CouponManagement::class)->disableOriginalConstructor()->getMock();
        $cartId  = 3;
        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB' . Data::COUPON_DELIMITER . 'codeC';
        $oldCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $oldCode, $unqCode, 2, 10);

        try {
            $this->object->aroundSet($subject, $this->mockPluginProceed([$cartId, $newCode]), $cartId, $newCode);
        } catch (CouldNotSaveException $exception) {
            $this->assertEquals(
                new CouldNotSaveException(new Phrase('Coupon quantity limit has been reached.')),
                $exception
            );
        } catch (NoSuchEntityException $exception) {
        }
    }

    public function testAroundSetInvalidCode()
    {
        /** @var \Magento\Quote\Model\CouponManagement|PHPUnit_Framework_MockObject_MockObject $subject */
        $subject = $this->getMockBuilder(\Magento\Quote\Model\CouponManagement::class)->disableOriginalConstructor()->getMock();
        $cartId  = 3;
        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB' . Data::COUPON_DELIMITER . 'codeC';
        $oldCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $count = $this->prepareCodeData($newCode, $oldCode, $unqCode, 3, 10) + 4;

        $afterSavedCodes = $this->formatCodeArray($oldCode);
        $this->data->expects($this->at($count))->method('getAppliedCodes')->willReturn($afterSavedCodes);

        try {
            $this->object->aroundSet($subject, $this->mockPluginProceed([$cartId, $newCode]), $cartId, $newCode);
        } catch (CouldNotSaveException $exception) {
        } catch (NoSuchEntityException $exception) {
            $this->assertEquals(
                new NoSuchEntityException(new Phrase('Coupon code is not valid.')),
                $exception
            );
        }
    }

    /**
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     */
    public function testAroundSetValidCode()
    {
        /** @var \Magento\Quote\Model\CouponManagement|PHPUnit_Framework_MockObject_MockObject $subject */
        $subject = $this->getMockBuilder(\Magento\Quote\Model\CouponManagement::class)->disableOriginalConstructor()->getMock();
        $cartId  = 3;
        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB' . Data::COUPON_DELIMITER . 'codeC';
        $oldCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $count = $this->prepareCodeData($newCode, $oldCode, $unqCode, 3, 10) + 4;

        $afterSavedCodes = $this->formatCodeArray($newCode);
        $this->data->expects($this->at($count))->method('getAppliedCodes')->willReturn($afterSavedCodes);

        $this->object->aroundSet($subject, $this->mockPluginProceed([$cartId, $newCode]), $cartId, $newCode);
    }

    /**
     * @param $newCode
     * @param $oldCode
     * @param $unqCode
     * @param int $limit
     * @param int $subtotal
     *
     * @return int
     */
    protected function prepareCodeData($newCode, $oldCode, $unqCode, $limit = 3, $subtotal = 0)
    {
        $cartId  = 3;
        $enabled = true;
        $storeId = 1;

        $this->data->method('isApplyFor')->willReturn($enabled);

        $quote = $this->getMockBuilder(CartInterface::class)->setMethods([
            'getStoreId',
            'getBaseSubtotalWithDiscount'
        ])->getMockForAbstractClass();
        $this->quoteRepository->expects($this->once())->method('get')->with($cartId)->willReturn($quote);
        $quote->method('getStoreId')->willReturn($storeId);
        $quote->method('getBaseSubtotalWithDiscount')->willReturn($subtotal);

        $originCodes = $this->formatCodeArray($newCode);
        $this->data->method('formatCodeArray')->with($newCode)->willReturn($originCodes);

        $count        = 0;
        $appliedCodes = $this->formatCodeArray($oldCode);
        $this->data->expects($this->at($count++))->method('getAppliedCodes')->withAnyParameters()->willReturn($appliedCodes);
        $this->data->expects($this->at($count++))->method('getAppliedCodes')->withAnyParameters()->willReturn($appliedCodes);
        $this->data->expects($this->at($count++))->method('getAppliedCodes')->withAnyParameters()->willReturn($appliedCodes);

        $uniqueCodes = $this->formatCodeArray($unqCode);
        $this->data->method('getUniqueCodes')->with($storeId)->willReturn($uniqueCodes);

        $this->data->method('getLimitQty')->with($storeId)->willReturn($limit);

        return $count;
    }

    /**
     * @param string $data
     * @param string $delimiter
     *
     * @return array
     */
    protected function formatCodeArray($data, $delimiter = Data::COUPON_DELIMITER)
    {
        return array_unique(array_filter(explode($delimiter, $data), 'strlen'));
    }

    /**
     * @param mixed $returnValue
     *
     * @return callable
     */
    protected function mockPluginProceed($returnValue = null)
    {
        return function () use ($returnValue) {
            return $returnValue;
        };
    }
}
