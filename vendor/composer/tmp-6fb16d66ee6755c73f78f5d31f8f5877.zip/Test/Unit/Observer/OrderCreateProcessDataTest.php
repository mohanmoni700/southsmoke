<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Test\Unit\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Phrase;
use Magento\Quote\Model\Quote;
use Magento\Sales\Model\AdminOrder\Create;
use Magento\SalesRule\Model\Coupon;
use Magento\SalesRule\Model\ResourceModel\Coupon as CouponResource;
use Magento\SalesRule\Model\Rule;
use Mageplaza\MultipleCoupons\Helper\Data;
use Mageplaza\MultipleCoupons\Observer\OrderCreateProcessData;
use PHPUnit_Framework_MockObject_MockObject;
use PHPUnit_Framework_TestCase;

/**
 * Class OrderCreateProcessDataTest
 * @package Mageplaza\MultipleCoupons\Test\Unit\Observer
 */
class OrderCreateProcessDataTest extends PHPUnit_Framework_TestCase
{
    /**
     * @var ManagerInterface|PHPUnit_Framework_MockObject_MockObject
     */
    private $messageManager;

    /**
     * @var RequestInterface|PHPUnit_Framework_MockObject_MockObject
     */
    private $request;

    /**
     * @var Coupon|PHPUnit_Framework_MockObject_MockObject
     */
    private $coupon;

    /**
     * @var Data|PHPUnit_Framework_MockObject_MockObject
     */
    private $data;

    /**
     * @var Rule|PHPUnit_Framework_MockObject_MockObject
     */
    private $rule;

    /**
     * @var Observer|PHPUnit_Framework_MockObject_MockObject
     */
    private $observer;

    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $quote;

    /**
     * @var OrderCreateProcessData
     */
    private $object;

    protected function setUp(): void
    {
        $this->messageManager = $this->getMockBuilder(ManagerInterface::class)->getMock();
        $this->request        = $this->getMockBuilder(RequestInterface::class)->setMethods(['setPostValue'])->getMockForAbstractClass();
        $this->coupon         = $this->getMockBuilder(Coupon::class)->setMethods([
            'loadByCode',
            'getResource'
        ])->disableOriginalConstructor()->getMock();
        $this->data           = $this->getMockBuilder(Data::class)->disableOriginalConstructor()->getMock();
        $this->rule           = $this->getMockBuilder(Rule::class)->disableOriginalConstructor()->getMock();

        $this->object = new OrderCreateProcessData(
            $this->messageManager,
            $this->request,
            $this->coupon,
            $this->data,
            $this->rule
        );
    }

    public function testExecuteZeroSubtotal()
    {
        $this->observer = $this->getMockBuilder(Observer::class)->getMock();

        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $unqCode);

        $originCodes = $this->formatCodeArray($newCode);
        $this->quote->method('setCouponCode')
            ->with(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [end($originCodes)])))
            ->willReturnSelf();

        $this->messageManager->expects($this->atLeastOnce())->method('addErrorMessage')
            ->with(new Phrase('Could not apply more coupon codes on this cart.'))
            ->willReturnSelf();

        $this->assertEquals($this->object, $this->object->execute($this->observer));
    }

    public function testExecuteUniqueCode()
    {
        $this->observer = $this->getMockBuilder(Observer::class)->getMock();

        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = 'codeA';

        $this->prepareCodeData($newCode, $unqCode, 3, 10);

        $originCodes = $this->formatCodeArray($newCode);

        $intersectCodes = array_intersect($originCodes, $this->formatCodeArray($unqCode));

        $this->quote->method('setCouponCode')->with(end($intersectCodes))->willReturnSelf();

        $this->messageManager->expects($this->atLeastOnce())->method('addErrorMessage')
            ->with(new Phrase('You are using an unique coupon. To add other coupons, please remove this unique one.'));

        $this->assertEquals($this->object, $this->object->execute($this->observer));
    }

    public function testExecuteLimitQtyReached()
    {
        $this->observer = $this->getMockBuilder(Observer::class)->getMock();

        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $unqCode, 1, 10);

        $originCodes = $this->formatCodeArray($newCode);

        $this->quote->method('setCouponCode')
            ->with(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [end($originCodes)])))
            ->willReturnSelf();

        $this->messageManager->expects($this->atLeastOnce())->method('addErrorMessage')
            ->with(new Phrase('Coupon quantity limit has been reached.'));

        $this->assertEquals($this->object, $this->object->execute($this->observer));
    }

    public function testExecuteInvalidCode()
    {
        $this->observer = $this->getMockBuilder(Observer::class)->getMock();

        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $unqCode, 3, 10);

        $originCodes = $this->formatCodeArray($newCode);
        $invalidCode = end($originCodes);

        $coupon = $this->getMockBuilder(Coupon::class)->setMethods(['getRuleId'])->disableOriginalConstructor()->getMock();
        $this->coupon->method('loadByCode')->willReturn($coupon);

        $couponResource = $this->getMockBuilder(CouponResource::class)->setMethods(['exists'])->disableOriginalConstructor()->getMock();
        $this->coupon->method('getResource')->willReturn($couponResource);

        $rule      = 1;
        $ruleArray = $this->formatCodeArray($rule, ',');
        $this->quote->method('getAppliedRuleIds')->willReturn($rule);

        $count = 0;
        foreach ($originCodes as $code) {
            $isRuleValid = $code != $invalidCode ? $ruleArray[0] : 99;
            $couponResource->expects($this->at($count))->method('exists')->with($code)->willReturn(true);
            $coupon->expects($this->at($count++))->method('getRuleId')->willReturn($isRuleValid);
        }

        $this->quote->method('setCouponCode')
            ->with(implode(Data::COUPON_DELIMITER, array_diff($originCodes, [$invalidCode])))
            ->willReturnSelf();

        $this->messageManager->expects($this->atLeastOnce())->method('addErrorMessage')
            ->with(new Phrase('Could not apply coupon code "%1".', [$invalidCode]));

        $this->assertEquals($this->object, $this->object->execute($this->observer));
    }

    public function testExecuteValidCode()
    {
        $this->observer = $this->getMockBuilder(Observer::class)->getMock();

        $newCode = 'codeA' . Data::COUPON_DELIMITER . 'codeB';
        $unqCode = '';

        $this->prepareCodeData($newCode, $unqCode, 3, 10);

        $originCodes = $this->formatCodeArray($newCode);

        $coupon = $this->getMockBuilder(Coupon::class)->setMethods(['getRuleId'])->disableOriginalConstructor()->getMock();
        $this->coupon->method('loadByCode')->willReturn($coupon);

        $couponResource = $this->getMockBuilder(CouponResource::class)->setMethods(['exists'])->disableOriginalConstructor()->getMock();
        $this->coupon->method('getResource')->willReturn($couponResource);

        $rule      = 1;
        $ruleArray = $this->formatCodeArray($rule, ',');
        $this->quote->method('getAppliedRuleIds')->willReturn($rule);

        $count = 0;
        foreach ($originCodes as $code) {
            $couponResource->expects($this->at($count))->method('exists')->with($code)->willReturn(true);
            $coupon->expects($this->at($count++))->method('getRuleId')->willReturn($ruleArray[0]);
        }

        $this->quote->method('setCouponCode')
            ->with(implode(Data::COUPON_DELIMITER, $originCodes))
            ->willReturnSelf();

        $this->messageManager->expects($this->once())->method('addSuccessMessage')
            ->with(new Phrase('The coupon code has been accepted.'));

        $this->assertEquals($this->object, $this->object->execute($this->observer));
    }

    /**
     * @param $newCode
     * @param $unqCode
     * @param int $limit
     * @param int $subtotal
     */
    protected function prepareCodeData($newCode, $unqCode, $limit = 3, $subtotal = 0)
    {
        $event = $this->getMockBuilder(Event::class)
            ->setMethods(['getOrderCreateModel', 'getRequest'])->disableOriginalConstructor()->getMock();
        $this->observer->method('getEvent')->willReturn($event);

        $model = $this->getMockBuilder(Create::class)->disableOriginalConstructor()->getMock();
        $event->method('getOrderCreateModel')->willReturn($model);

        $data = [
            'order' => [
                'coupon' => [
                    'code'   => $newCode,
                    'remove' => false
                ]
            ]
        ];
        $event->method('getRequest')->willReturn($data);

        $this->quote = $this->getMockBuilder(Quote::class)
            ->setMethods([
                'getStoreId',
                'getCouponCode',
                'getBaseSubtotalWithDiscount',
                'setCouponCode',
                'getAppliedRuleIds'
            ])
            ->disableOriginalConstructor()->getMock();
        $model->method('getQuote')->willReturn($this->quote);

        $storeId = 1;
        $this->quote->method('getStoreId')->willReturn($storeId);

        $groupId = 2;
        $this->quote->method('getCustomerGroupId')->willReturn($groupId);

        $isApplyFor = true;
        $this->data->method('isApplyFor')->with($storeId)->willReturn($isApplyFor);

        $this->quote->method('getCouponCode')->willReturn($newCode);
        $originCodes = $this->formatCodeArray($newCode);
        $this->data->method('formatCodeArray')->with($newCode)->willReturn($originCodes);

        $this->quote->method('getBaseSubtotalWithDiscount')->willReturn($subtotal);

        $uniqueCodes = $this->formatCodeArray($unqCode);
        $this->data->method('getUniqueCodes')->with($storeId)->willReturn($uniqueCodes);

        $this->data->method('getLimitQty')->with($storeId)->willReturn($limit);
    }

    /**
     * @param string $data
     * @param string $delimiter
     *
     * @return array
     */
    protected function formatCodeArray($data, $delimiter = Data::COUPON_DELIMITER)
    {
        return array_unique(array_filter(explode($delimiter, $data), 'strlen'));
    }
}
