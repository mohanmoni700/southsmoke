<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
declare(strict_types=1);

namespace Mageplaza\MultipleCoupons\Model\Resolver;

use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Quote\Model\Quote;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class Cart
 * @package Mageplaza\MultipleCoupons\Model\Resolver
 */
class Cart implements ResolverInterface
{
    /**
     * @var Data
     */
    private $data;

    /**
     * @var Quote
     */
    private $quote;

    /**
     * @param Data $data
     * @param Quote $quote
     */
    public function __construct(
        Data $data,
        Quote $quote
    ) {
        $this->data  = $data;
        $this->quote = $quote;
    }

    /**
     * @inheritdoc
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        if (!$this->data->isEnabled()) {
            return [];
        }

        $quote = $this->quote->load($value['model']->getId());

        /** @var \Magento\Quote\Model\Quote\Address\Total $multipleCouponsData */
        $multipleCouponsData = $quote->getTotals()['mpmultiplecoupons'];

        return [
            'mpmultiplecoupons' => $this->getData($multipleCouponsData)
        ];
    }

    /**
     * @param $data
     *
     * @return array
     */
    public function getData($data)
    {
        return [
            'code'  => $data->getCode(),
            'title' => $data->getTitle(),
            'value' => $this->getValue($data)
        ];
    }

    /**
     * @param $data
     *
     * @return array
     */
    public function getValue($data)
    {
        $result = [];
        foreach ($data->getValue() as $dt) {
            $result[] = $dt;
        }

        return $result;
    }
}
