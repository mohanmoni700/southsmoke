<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Model\ResourceModel\Report;

use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class Collection
 * @package Mageplaza\MultipleCoupons\Plugin\Model\ResourceModel\Report
 */
class Collection extends \Magento\SalesRule\Model\ResourceModel\Report\Collection
{
    /**
     * Redeclare after load method for specifying collection items original data
     *
     * @return \Magento\SalesRule\Model\ResourceModel\Report\Collection|Collection
     */
    protected function _afterLoad()
    {
        $result = parent::_afterLoad();

        foreach ($result->getItems() as &$item) {
            if ($item->getData('coupon_code')) {
                $item->setData('coupon_code', str_replace(Data::COUPON_DELIMITER, ',', $item->getData('coupon_code')));
            }
        }

        return $result;
    }
}
