<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Model\Sales\Pdf;

use Magento\Sales\Model\Order\Pdf\Total\DefaultTotal;
use Magento\SalesRule\Model\CouponFactory;
use Magento\SalesRule\Model\RuleFactory;
use Magento\Tax\Model\Calculation;
use Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class MultipleCoupons
 * @package Mageplaza\MultipleCoupons\Model\Sales\Pdf
 */
class MultipleCoupons extends DefaultTotal
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * @var CouponFactory
     */
    private $coupon;

    /**
     * @var RuleFactory
     */
    private $rule;

    /**
     * MultipleCoupons constructor.
     *
     * @param \Magento\Tax\Helper\Data $taxHelper
     * @param Calculation $taxCalculation
     * @param CollectionFactory $ordersFactory
     * @param Data $helper
     * @param CouponFactory $coupon
     * @param RuleFactory $rule
     * @param array $data
     */
    public function __construct(
        \Magento\Tax\Helper\Data $taxHelper,
        Calculation $taxCalculation,
        CollectionFactory $ordersFactory,
        Data $helper,
        CouponFactory $coupon,
        RuleFactory $rule,
        array $data = []
    ) {
        parent::__construct($taxHelper, $taxCalculation, $ordersFactory, $data);

        $this->helper = $helper;
        $this->coupon = $coupon;
        $this->rule   = $rule;
    }

    /**
     * Get array of arrays with totals information for display in PDF
     * array(
     *  $index => array(
     *      'amount'   => $amount,
     *      'label'    => $label,
     *      'font_size'=> $font_size
     *  )
     * )
     * @return array
     */
    public function getTotalsForDisplay()
    {
        $coupons = $this->helper->formatCodeArray($this->getOrder()->getCouponCode(), Data::COUPON_DELIMITER);

        $label = '';
        foreach ($coupons as $code) {
            $coupon = $this->coupon->create()->loadByCode($code);
            $rule   = $this->rule->create()->load($coupon->getRuleId());
            if ($rule->getId()) {
                $ruleLabel = $rule->getStoreLabel($this->getOrder()->getStoreId()) ?: $code;
                if (strlen($label)) {
                    $label .= ', ';
                }

                $label .= $ruleLabel;
            }
        }

        $total = [
            'label'     => __('Discount') . ' (' . $label . ')',
            'amount'    => $this->getOrder()->formatPriceTxt($this->getAmount()),
            'font_size' => $this->getFontSize() ?: 7
        ];

        return [$total];
    }
}
