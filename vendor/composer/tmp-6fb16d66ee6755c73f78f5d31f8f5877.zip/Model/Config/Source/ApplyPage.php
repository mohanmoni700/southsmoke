<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class ApplyPage
 * @package Mageplaza\MultipleCoupons\Model\Config\Source
 */
class ApplyPage implements OptionSourceInterface
{
    const FRONT_CHECKOUT = 'frontend';
    const ADMIN_CHECKOUT = 'adminhtml';

    /**
     * Retrieve option array
     *
     * @return string[]
     */
    public function getOptionArray()
    {
        return [
            self::FRONT_CHECKOUT => __('Shopping Cart & Checkout Page (included Mageplaza OSC)'),
            self::ADMIN_CHECKOUT => __('Admin Order Page'),
        ];
    }

    /**
     * Retrieve option array with empty value
     *
     * @return string[]
     */
    public function toOptionArray()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }
}
