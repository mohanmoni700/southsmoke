<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Model;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Pricing\Helper\Data;

/**
 * Class RuleManagement
 * @package Mageplaza\MultipleCoupons\Model
 */
class RuleManagement
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var array
     */
    protected $rule = [];


    /**
     * @var Data
     */
    protected $priceHelper;


    /**
     * DiscountCollector constructor.
     *
     * @param StoreManagerInterface $storeManager
     * @param Data $priceHelper
     */
    public function __construct(StoreManagerInterface $storeManager, Data $priceHelper)
    {
        $this->storeManager = $storeManager;
        $this->priceHelper = $priceHelper;
    }

    /**
     * @param $code
     * @param $amount
     * @param $label
     */
    public function setRule($code, $amount, $label)
    {
        if (!isset($this->rule[$code])) {
            $this->rule[$code] = [
                'amount' => 0,
                'label'  => $label ?: $code
            ];
        }

        $this->rule[$code]['amount'] += $amount;
    }

    /**
     * @return array
     */
    public function getRule()
    {
        $rules = [];

        foreach ($this->rule as $code => $value) {
            $rules[] = [
                'code'   => $code,
                'amount' => $value['amount'],
                'label'  => $value['label']
            ];
        }

        return $rules;
    }

    /**
     * @return array
     * @throws NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getFormattedRule()
    {
        /** @var Store $store */
        $store = $this->storeManager->getStore();
        $rules = [];

        foreach ($this->getRule() as $rule) {
            $rule['amount'] = $this->priceHelper->currency($rule['amount'], false, false);
            $amount  = '-' . $store->getCurrentCurrency()->format($rule['amount'], [], false);
            $rules[] = [
                'code'   => $rule['code'],
                'amount' => $amount,
                'label'  => $rule['label'],
            ];
        }

        return $rules;
    }

    /**
     * Flush rule
     */
    public function flushRule()
    {
        $this->rule = [];
    }
}
