<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Model\Quote\Total;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;
use Mageplaza\MultipleCoupons\Helper\Data;
use Mageplaza\MultipleCoupons\Model\RuleManagement;
use Magento\Directory\Model\PriceCurrency;

/**
 * Class Coupon
 *
 * @package Mageplaza\MultipleCoupons\Model\Quote\Total
 */
class Coupon extends AbstractTotal
{
    const DISCOUNT_CODE = 'mpmultiplecoupons';

    /**
     * @var PriceCurrency
     */
    protected $priceCurrency;

    /**
     * @var RuleManagement
     */
    protected $ruleManagement;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Data
     */
    protected $data;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * Coupon constructor.
     *
     * @param RuleManagement   $ruleManagement
     * @param Session          $session
     * @param Data             $data
     * @param RequestInterface $request
     * @param PriceCurrency    $priceCurrency
     */
    public function __construct(
        RuleManagement $ruleManagement,
        Session $session,
        Data $data,
        RequestInterface $request,
        PriceCurrency $priceCurrency
    ) {
        $this->ruleManagement = $ruleManagement;
        $this->session        = $session;
        $this->data           = $data;
        $this->request        = $request;
        $this->priceCurrency  = $priceCurrency;
    }

    /**
     * @param Quote                       $quote
     * @param ShippingAssignmentInterface $shippingAssignment
     * @param Total                       $total
     *
     * @return $this|AbstractTotal
     * @throws NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function collect(Quote $quote, ShippingAssignmentInterface $shippingAssignment, Total $total)
    {
        parent::collect($quote, $shippingAssignment, $total);
        $address = $shippingAssignment->getShipping()->getAddress();
        $total->setDiscountDescription($address->getDiscountDescription());
        if ($this->data->isApplyFor($quote->getStoreId())) {
            $this->session->setMpMultipleCoupons($this->ruleManagement->getRule());
            $this->session->setMpMultipleCouponsFormatted($this->ruleManagement->getFormattedRule());
        }

        return $this;
    }

    /**
     * @param Quote $quote
     * @param Total $total
     *
     * @return array
     * @SuppressWarnings(Unused)
     */
    public function fetch(Quote $quote, Total $total): array
    {
        if ($this->request->getFullActionName() === 'multishipping_checkout_overview') {
            return [];
        }

        if (!$this->data->isApplyFor($quote->getStoreId())) {
            return [];
        }

        if ($this->data->isAdmin()) {
            $count  = 0;
            $result = [];
            foreach ($this->session->getMpMultipleCoupons() as $item) {
                $result[] = [
                    'code'  => self::DISCOUNT_CODE . ($count++),
                    'title' => $item['label'],
                    'value' => $this->priceCurrency->convert(-$item['amount'], $quote->getStoreId(), $quote->getCurrency())
                ];
            }

            if ($count) {
                array_unshift($result, [
                    'code'  => 'discount',
                    'title' => __('Discount'),
                ]);
            }

            return $result;
        }

        $description = (string)$total->getDiscountDescription() ?: '';

        return [
            'code'  => self::DISCOUNT_CODE,
            'title' => strlen($description) ? __('Discount (%1)', $description) : __('Discount'),
            'value' => $this->session->getMpMultipleCouponsFormatted()
        ];
    }
}
