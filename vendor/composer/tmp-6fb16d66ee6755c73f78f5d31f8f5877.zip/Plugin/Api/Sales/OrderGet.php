<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Plugin\Api\Sales;

use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderSearchResultInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class OrderGet
 * @package Mageplaza\MultipleCoupons\Plugin\Api\Sales
 */
class OrderGet
{
    /**
     * @param OrderRepositoryInterface $subject
     * @param OrderInterface $result
     *
     * @return OrderInterface
     * @SuppressWarnings(Unused)
     */
    public function afterGet(OrderRepositoryInterface $subject, $result)
    {
        $result->setCouponCode($this->formatCoupon($result->getCouponCode()));
        $result->setDiscountDescription($this->formatCoupon($result->getDiscountDescription()));

        return $result;
    }

    /**
     * @param OrderRepositoryInterface $subject
     * @param OrderSearchResultInterface $result
     *
     * @return mixed
     * @SuppressWarnings(Unused)
     */
    public function afterGetList(OrderRepositoryInterface $subject, $result)
    {
        foreach ($result->getItems() as $item) {
            $item->setCouponCode($this->formatCoupon($item->getCouponCode()));
            $item->setDiscountDescription($this->formatCoupon($item->getDiscountDescription()));
        }

        return $result;
    }

    /**
     * @param $code
     *
     * @return mixed
     */
    private function formatCoupon($code)
    {
        return str_replace(Data::COUPON_DELIMITER, ',', $code);
    }
}
