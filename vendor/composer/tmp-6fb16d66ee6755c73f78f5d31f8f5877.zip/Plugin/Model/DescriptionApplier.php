<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
namespace Mageplaza\MultipleCoupons\Plugin\Model;

use Magento\Quote\Model\Quote\Address;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\RulesApplier;

/**
 * Class DescriptionApplier
 * Mageplaza\MultipleCoupons\Plugin\Model
 */
class DescriptionApplier
{
    /**
     * @param RulesApplier $subject
     * @param callable $proceed
     * @param Address $address
     * @param Rule $rule
     *
     * @return mixed
     */
    public function aroundAddDiscountDescription(
        RulesApplier $subject,
        callable $proceed,
        Address $address,
        Rule $rule
    ) {
        $description = $address->getDiscountDescriptionArray();
        $ruleLabel = $rule->getStoreLabel($address->getQuote()->getStore());
        $label = '';
        if ($ruleLabel) {
            $label = $ruleLabel;
        } elseif ($address->getCouponCode() !== '') {
            $label = $rule->getCouponCode();

            if ($rule->getDescription()) {
                $label = $rule->getDescription();
            }
        }

        if (strlen($label)) {
            $description[$rule->getId()] = $label;
        }

        $address->setDiscountDescriptionArray($description);

        return $this;
    }
}
