<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */
declare(strict_types=1);

namespace Mageplaza\MultipleCoupons\Plugin\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Quote\Api\CouponManagementInterface;
use Magento\QuoteGraphQl\Model\Cart\GetCartForUser;
use Magento\QuoteGraphQl\Model\Resolver\ApplyCouponToCart as GraphQlApplyCouponToCart;
use Magento\Framework\Registry;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * @inheritdoc
 */
class ApplyCouponToCart
{
    /**
     * @var GetCartForUser
     */
    private $getCartForUser;

    /**
     * @var CouponManagementInterface
     */
    private $couponManagement;

    /**
     * @var Data
     */
    private $data;

    /**
     * @var Registry
     */
    private $registry;

    /**
     * @param GetCartForUser $getCartForUser
     * @param CouponManagementInterface $couponManagement
     * @param Data $data
     * @param Registry $registry
     */
    public function __construct(
        GetCartForUser $getCartForUser,
        CouponManagementInterface $couponManagement,
        Data $data,
        Registry $registry
    ) {
        $this->getCartForUser   = $getCartForUser;
        $this->couponManagement = $couponManagement;
        $this->data             = $data;
        $this->registry         = $registry;
    }

    /**
     * @inheritdoc
     */
    public function beforeResolve(
        GraphQlApplyCouponToCart $subject,
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        // compatible with GraphQl
        if ($this->data->isEnabled()) {
            $this->registry->register('is_multiple_coupon', true);
        }

        return [$field, $context, $info, $value, $args];
    }
}
