<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Plugin\Model;

use Closure;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\QuoteRepository;
use Magento\Framework\Registry;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class CouponManagement
 * @package Mageplaza\MultipleCoupons\Plugin\Model
 */
class CouponManagement
{
    /**
     * @var QuoteRepository
     */
    protected $quoteRepository;

    /**
     * @var Data
     */
    protected $data;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * CouponManagement constructor.
     *
     * @param QuoteRepository $quoteRepository
     * @param Data $data
     * @param Registry $registry
     */
    public function __construct(
        QuoteRepository $quoteRepository,
        Data $data,
        Registry $registry
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->data            = $data;
        $this->registry        = $registry;
    }

    /**
     * @param \Magento\Quote\Model\CouponManagement $subject
     * @param string $result
     *
     * @return string
     * @throws NoSuchEntityException
     * @throws LocalizedException
     * @SuppressWarnings(Unused)
     */
    public function afterGet(\Magento\Quote\Model\CouponManagement $subject, $result)
    {
        // compatible with GraphQl
        if ($this->registry->registry('is_multiple_coupon')) {
            $this->registry->unregister('is_multiple_coupon');
            return null;
        }

        if ($this->data->isApplyFor() && count($appliedCoupons = $this->data->getAppliedCodes())) {
            return implode(Data::COUPON_DELIMITER, $appliedCoupons);
        }

        return $result;
    }

    /**
     * @param \Magento\Quote\Model\CouponManagement $subject
     * @param Closure $proceed
     * @param $cartId
     * @param $couponCode
     *
     * @return bool
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     * @throws LocalizedException
     * @SuppressWarnings(Unused)
     */
    public function aroundSet(\Magento\Quote\Model\CouponManagement $subject, Closure $proceed, $cartId, $couponCode)
    {
        $quote   = $this->quoteRepository->get($cartId);
        $storeId = $quote->getStoreId();

        if (!$this->data->isApplyFor($storeId)) {
            return $proceed($cartId, $couponCode);
        }

        $originCodes = $this->data->formatCodeArray($couponCode);

        if (count($originCodes) > count($this->data->getAppliedCodes()) && $quote->getBaseSubtotalWithDiscount() <= 0) {
            throw new CouldNotSaveException(__('Could not apply more coupon codes on this cart.'));
        }

        if (!empty($intersectCodes = array_intersect($originCodes, $this->data->getUniqueCodes($storeId)))) {
            $couponCode = end($intersectCodes);
        }

        if (!empty($intersectCodes) && end($intersectCodes) != end($originCodes)) {
            throw new CouldNotSaveException(__('You are using an unique coupon. To add other coupons, please remove this unique one.'));
        }

        if (empty($intersectCodes) && $this->data->getLimitQty($storeId) && count($originCodes) > $this->data->getLimitQty($storeId)) {
            throw new CouldNotSaveException(__('Coupon quantity limit has been reached.'));
        }

        $result = $proceed($cartId, $couponCode);

        if ($couponCode != $this->afterGet($subject, $couponCode)) {
            throw new NoSuchEntityException(__('Coupon code is not valid.'));
        }

        return $result;
    }
}
