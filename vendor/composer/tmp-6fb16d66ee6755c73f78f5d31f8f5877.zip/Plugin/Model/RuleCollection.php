<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_MultipleCoupons
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\MultipleCoupons\Plugin\Model;

use Closure;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Quote\Model\Quote\Address;
use Magento\SalesRule\Model\ResourceModel\Rule\Collection;
use Magento\SalesRule\Model\Rule;
use Mageplaza\MultipleCoupons\Helper\Data;

/**
 * Class RuleCollection
 * @package Mageplaza\MultipleCoupons\Plugin\Model
 */
class RuleCollection
{
    /**
     * @var Data
     */
    protected $data;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * RuleCollection constructor.
     *
     * @param Data $data
     * @param TimezoneInterface $timezone
     */
    public function __construct(
        Data $data,
        TimezoneInterface $timezone
    ) {
        $this->data     = $data;
        $this->timezone = $timezone;
    }

    /**
     * @param Collection $subject
     * @param Closure $proceed
     * @param int $websiteId
     * @param int $customerGroupId
     * @param string $couponCode
     * @param string|null $now
     * @param Address $address
     *
     * @return mixed
     */
    public function aroundSetValidationFilter(
        Collection $subject,
        Closure $proceed,
        $websiteId,
        $customerGroupId,
        $couponCode = '',
        $now = null,
        Address $address = null
    ) {
        if (!$this->data->isApplyFor($websiteId) || !strlen($couponCode)) {
            return $proceed($websiteId, $customerGroupId, $couponCode, $now, $address);
        }

        $coupons = $this->data->formatCodeArray($couponCode);

        if (!empty($intersectCodes = array_intersect($coupons, $this->data->getUniqueCodes($websiteId)))) {
            $coupons = [end($intersectCodes)];
        }

        /** @var Collection $result */
        $result = $proceed($websiteId, $customerGroupId, $couponCode, $now, $address);
        $limit  = $this->data->getLimitQty($websiteId);
        if ($limit && count($coupons) > $limit) {
            return $result;
        }

        $select         = $result->getSelect();
        $connection     = $result->getConnection();
        $isValidVersion = $this->data->checkVersion();
        if ($isValidVersion) {
            $saleRuleCustomerGroupTable = $subject->getTable('salesrule_customer_group');
            $srcgColumnName             = $connection->tableColumnExists(
                $saleRuleCustomerGroupTable,
                'rule_id'
            ) ? 'rule_id' : 'row_id';

            $select->reset();
            $select->from(['main_table' => $result->getMainTable()]);
            if ($this->data->isModuleOutputEnabled('Mageplaza_SpecialPromotions')) {
                $specialPromotionsHelperData = $this->data->getObject(\Mageplaza\SpecialPromotions\Helper\Data::class);
                if ($address && $address->getQuote()
                    && $specialPromotionsHelperData->checkHasSpecialOrTierPrice($address->getQuote())) {
                    $select->where('mp_skip_special_tier_price = 0');
                }
            }
            $select->joinLeft(
                ['rule_coupons' => $subject->getTable('salesrule_coupon')],
                $connection->quoteInto(
                    'main_table.rule_id = rule_coupons.rule_id AND main_table.coupon_type != ?',
                    Rule::COUPON_TYPE_NO_COUPON
                )
            )->joinInner(
                ['customer_group_ids' => $saleRuleCustomerGroupTable],
                $connection->quoteInto(
                    'main_table.rule_id = customer_group_ids.'
                    . $srcgColumnName .
                    ' AND customer_group_ids.customer_group_id = ?',
                    $customerGroupId
                )
            );

            $selectCoupon = $connection->select()->from(['main_table' => $subject->getTable('salesrule')]);

            $selectCoupon->joinLeft(
                ['rule_coupons' => $subject->getTable('salesrule_coupon')],
                $connection->quoteInto(
                    'main_table.rule_id = rule_coupons.rule_id AND main_table.coupon_type != ?',
                    Rule::COUPON_TYPE_NO_COUPON
                )
            );
        }

        foreach ($coupons as $coupon) {
            $timeNow           = $this->timezone->date()->format('Y-m-d');
            $orWhereConditions = [
                $connection->quoteInto(
                    '(main_table.coupon_type = ? AND rule_coupons.type = 0)',
                    Rule::COUPON_TYPE_AUTO
                ),
                $connection->quoteInto(
                    '(main_table.coupon_type = ? AND main_table.use_auto_generation = 1 AND rule_coupons.type = 1)',
                    Rule::COUPON_TYPE_SPECIFIC
                ),
                $connection->quoteInto(
                    '(main_table.coupon_type = ? AND main_table.use_auto_generation = 0 AND rule_coupons.type = 0)',
                    Rule::COUPON_TYPE_SPECIFIC
                ),
            ];

            $andWhereConditions = [
                $connection->quoteInto(
                    'rule_coupons.code = ? AND main_table.is_active = 1',
                    $coupon
                ),
                $connection->quoteInto(
                    '(rule_coupons.expiration_date IS NULL OR rule_coupons.expiration_date >= ?)',
                    $timeNow
                ),
            ];

            if ($isValidVersion) {
                array_push(
                    $andWhereConditions,
                    $connection->quoteInto(
                        '(from_date IS NULL OR from_date <= ?)',
                        $timeNow
                    ),
                    $connection->quoteInto(
                        '(to_date IS NULL OR to_date >= ?)',
                        $timeNow
                    )
                );
            }

            $orWhereCondition  = implode(' OR ', $orWhereConditions);
            $andWhereCondition = implode(' AND ', $andWhereConditions);

            if ($isValidVersion) {
                $selectCoupon->orWhere(' ( ' . $orWhereCondition . ' ) AND ' . $andWhereCondition);
            } else {
                $select->orWhere(' ( ' . $orWhereCondition . ' ) AND ' . $andWhereCondition);
            }
        }

        if ($isValidVersion) {
            $select->where('rule_coupons.code IN (?)', $coupons)
                ->where('main_table.rule_id IN (?)', $connection->fetchCol($selectCoupon));
            $select->orWhere(
                'main_table.coupon_type = ?',
                Rule::COUPON_TYPE_NO_COUPON
            );
        }

        return $result;
    }
}
