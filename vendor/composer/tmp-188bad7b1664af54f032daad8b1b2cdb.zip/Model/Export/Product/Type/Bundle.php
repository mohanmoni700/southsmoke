<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\BundleImportExport\Model\Export\Product\Type;

/**
 * Class Bundle
 */
class Bundle extends \Magento\CatalogImportExport\Model\Export\Product\Type\AbstractType
{
}
