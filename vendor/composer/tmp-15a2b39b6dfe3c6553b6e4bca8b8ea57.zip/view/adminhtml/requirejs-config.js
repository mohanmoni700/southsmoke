
var config = {
    map: {
        '*': {
            tokenbaseForm:            'ParadoxLabs_TokenBase/js/form',
            tokenbasePaymentinfo:     'ParadoxLabs_TokenBase/js/paymentinfo',
            tokenbaseCardFormatter:   'ParadoxLabs_TokenBase/js/cardFormatter'
        }
    }
};
