<?php

/**
 * @see https://github.com/laminas/laminas-serializer for the canonical source repository
 */

declare(strict_types=1);

namespace Laminas\Serializer\Adapter;

use Laminas\Stdlib\AbstractOptions;

class AdapterOptions extends AbstractOptions
{
}
