# Grouped Requisition List Functional Tests

The Functional Test Module for **Magento Grouped Requisition List** module.
