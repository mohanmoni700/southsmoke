/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            requisition: 'Magento_RequisitionList/js/requisition',
            requisitionActions: 'Magento_RequisitionList/js/requisition-actions'
        }
    }
};
