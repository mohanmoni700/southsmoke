# Requisition List Functional Tests

The Functional Test Module for **Magento Requisition List** module.
