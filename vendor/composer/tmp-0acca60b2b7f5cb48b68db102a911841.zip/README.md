# CatalogStagingGraphQl

**CatalogStagingGraphQl** supports Staging functionality for Catalog in the scope of GraphQl.
This includes preview capabilities for catalog entities.
