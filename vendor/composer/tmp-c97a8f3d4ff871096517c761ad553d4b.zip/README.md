# WishlistGiftCardGraphQl

**WishlistGiftCardGraphQl** provides the needed provider for adding a gift card wishlist item to cart.
