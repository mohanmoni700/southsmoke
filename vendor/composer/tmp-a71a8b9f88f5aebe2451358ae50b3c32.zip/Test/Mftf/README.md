# Product Video Staging Functional Tests

The Functional Test Module for **Magento Product Video Staging** module.
