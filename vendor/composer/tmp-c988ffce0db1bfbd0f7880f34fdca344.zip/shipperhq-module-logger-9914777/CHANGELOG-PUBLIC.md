# Change Log
## 20.4.0 (2018-06-21)
SHQ18-331 remove module-common dependency


## 20.5.0 (2020-09-17)
MNB-657 Remove logging per extension switches


## 20.6.0 (2022-02-18)
MNB-5 Move to declarative schema


## 20.7.0 (2022-05-13)
MNB-2430 M2.4.4 compatibility


