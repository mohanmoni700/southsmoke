# Magento_BannerPageBuilderAnalytics module

The Magento_BannerPageBuilderAnalytics module configures data definitions for a data collection related to the PageBuilder module entities to be used in [Advanced Reporting](http://devdocs.magento.com/guides/v2.2/advanced-reporting/modules.html). 
