<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\Resolver;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\Resolver\ContextInterface;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\IdEncoder;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\SetNegotiableQuoteShippingAddressForUser;
use Magento\Quote\Api\CartRepositoryInterface;

/**
 * Resolver for setting the shipping address on a negotiable quote
 */
class SetNegotiableQuoteShippingAddress implements ResolverInterface
{
    /**
     * @var SetNegotiableQuoteShippingAddressForUser
     */
    private $setNegotiableQuoteShippingAddressForUser;

    /**
     * @var CartRepositoryInterface
     */
    private $quoteRepository;

    /**
     * @var IdEncoder
     */
    private $idEncoder;

    /**
     * @param CartRepositoryInterface $quoteRepository
     * @param SetNegotiableQuoteShippingAddressForUser $setNegotiableQuoteShippingAddressForUser
     * @param IdEncoder $idEncoder
     */
    public function __construct(
        CartRepositoryInterface $quoteRepository,
        SetNegotiableQuoteShippingAddressForUser $setNegotiableQuoteShippingAddressForUser,
        IdEncoder $idEncoder
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->setNegotiableQuoteShippingAddressForUser = $setNegotiableQuoteShippingAddressForUser;
        $this->idEncoder = $idEncoder;
    }

    /**
     * Set negotiable quote shipping address resolver
     *
     * @param Field $field
     * @param ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array
     * @throws GraphQlAuthorizationException
     * @throws GraphQlInputException
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ): array {
        if (empty($args['input']['quote_uid'])) {
            throw new GraphQlInputException(__('Required parameter "quote_uid" is missing.'));
        }
        if (empty($args['input']['customer_address_id'])) {
            throw new GraphQlInputException(__('Required parameter "customer_address_id" is missing.'));
        }

        $maskedId = $args['input']['quote_uid'];
        $customerAddressId = (int)$this->idEncoder->decode($args['input']['customer_address_id']);

        $negotiableQuote = $this->setNegotiableQuoteShippingAddressForUser->execute(
            $maskedId,
            $customerAddressId,
            (int)$context->getUserId(),
            $context->getExtensionAttributes()->getStore()->getWebsite()
        );
        $quote = $this->quoteRepository->get($negotiableQuote->getQuoteId());

        $data['quote'] = [
            'uid' => $maskedId,
            'name' => $negotiableQuote->getQuoteName(),
            'created_at' => $quote->getCreatedAt(),
            'updated_at' => $quote->getUpdatedAt(),
            'status' => $negotiableQuote->getStatus(),
            'model' => $quote,
        ];
        return $data;
    }
}
