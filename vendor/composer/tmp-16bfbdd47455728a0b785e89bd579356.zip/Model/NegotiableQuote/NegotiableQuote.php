<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\NegotiableQuote\Api\NegotiableQuoteRepositoryInterface;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\ResourceModel\QuoteIdMask;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Store\Api\Data\WebsiteInterface;

/**
 * Negotiable Quote model with related validation methods
 */
class NegotiableQuote
{
    /**
     * @var NegotiableQuoteRepositoryInterface
     */
    private $negotiableQuoteRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var QuoteIdMask
     */
    private $quoteIdMaskResource;

    /**
     * @param NegotiableQuoteRepositoryInterface $negotiableQuoteRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param QuoteIdMask $quoteIdMaskResource
     */
    public function __construct(
        NegotiableQuoteRepositoryInterface $negotiableQuoteRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        QuoteIdMask $quoteIdMaskResource
    ) {
        $this->negotiableQuoteRepository = $negotiableQuoteRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->quoteIdMaskResource = $quoteIdMaskResource;
    }

    /**
     * Retrieve negotiable quotes and validate quotes for all ids exist and belong to the current customer and website
     *
     * @param int[] $quoteIds
     * @param int $customerId
     * @param WebsiteInterface $website
     * @return CartInterface[]
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     */
    public function getOwnedNegotiableQuotes(array $quoteIds, int $customerId, WebsiteInterface $website): array
    {
        $validStoreIds = $website->getStoreIds();
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter('extension_attribute_negotiable_quote.quote_id', $quoteIds, 'in')
            ->addFilter('customer_id', $customerId)
            ->addFilter('store_id', $validStoreIds, 'in')
            ->create();

        /** @var CartInterface[] $quotes */
        $quotes = $this->negotiableQuoteRepository->getList($searchCriteria)->getItems();
        if (count($quotes) !== count($quoteIds)) {
            $foundQuoteIds = [];
            foreach ($quotes as $quote) {
                $foundQuoteIds[] = (int)$quote->getId();
            }

            $missingQuoteIds = array_diff($quoteIds, $foundQuoteIds);
            throw new GraphQlNoSuchEntityException(
                __(
                    "Could not find negotiable quotes with the following UIDs: "
                    . implode(", ", array_values($this->quoteIdMaskResource->getMaskedQuoteIds($missingQuoteIds)))
                )
            );
        }

        return $quotes;
    }
}
