<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote;

use Exception;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\NegotiableQuote\Api\Data\NegotiableQuoteInterface;
use Magento\NegotiableQuote\Model\Quote\Address;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\ResourceModel\QuoteIdMask;
use Magento\Store\Api\Data\WebsiteInterface;

/**
 * Model for setting a shipping address on a negotiable quote
 */
class SetNegotiableQuoteShippingAddressForUser
{
    /**
     * @var Address
     */
    private $negotiableQuoteAddress;

    /**
     * @var CustomerAddress
     */
    private $shippingAddress;

    /**
     * @var Customer
     */
    private $customer;

    /**
     * @var Quote
     */
    private $quote;

    /**
     * @var QuoteIdMask
     */
    private $quoteIdMaskResource;

    /**
     * @param Address $negotiableQuoteAddress
     * @param CustomerAddress $shippingAddress
     * @param Customer $customer
     * @param Quote $quote
     * @param QuoteIdMask $quoteIdMaskResource
     */
    public function __construct(
        Address $negotiableQuoteAddress,
        CustomerAddress $shippingAddress,
        Customer $customer,
        Quote $quote,
        QuoteIdMask $quoteIdMaskResource
    ) {
        $this->negotiableQuoteAddress = $negotiableQuoteAddress;
        $this->shippingAddress = $shippingAddress;
        $this->customer = $customer;
        $this->quote = $quote;
        $this->quoteIdMaskResource = $quoteIdMaskResource;
    }

    /**
     * Set shipping address on a negotiable quote
     *
     * @param string $maskedId
     * @param int $customerAddressId
     * @param int $customerId
     * @param WebsiteInterface $website
     * @return NegotiableQuoteInterface
     * @throws GraphQlAuthorizationException
     * @throws GraphQlInputException
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     */
    public function execute(
        string $maskedId,
        int $customerAddressId,
        int $customerId,
        WebsiteInterface $website
    ): NegotiableQuoteInterface {
        $this->customer->validateCanManage($customerId);

        $quoteId = $this->quoteIdMaskResource->getUnmaskedQuoteId($maskedId);
        $quote = $this->quote->getOwnedQuote($quoteId, $website);
        $this->quote->validateNegotiable([$quote]);
        $this->quote->validateCanSubmit([$quote]);
        $this->shippingAddress->getOwnedAddress($customerId, $customerAddressId);

        try {
            $this->negotiableQuoteAddress->updateAddress($quoteId, $customerAddressId);
        } catch (Exception $exception) {
            throw new LocalizedException(__("Unable to set the shipping address on the specified negotiable quote."));
        }

        return $quote->getExtensionAttributes()->getNegotiableQuote();
    }
}
