<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote;

use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\Data\AddressInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;

/**
 * Customer Address model with associated validation methods
 */
class CustomerAddress
{
    /**
     * @var AddressRepositoryInterface
     */
    private $addressRepository;

    /**
     * @param AddressRepositoryInterface $addressRepository
     */
    public function __construct(AddressRepositoryInterface $addressRepository)
    {
        $this->addressRepository = $addressRepository;
    }

    /**
     * Get address from id and verify it belongs to the current customer
     *
     * @param int $customerId
     * @param int $addressId
     * @return AddressInterface
     *
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     */
    public function getOwnedAddress(int $customerId, int $addressId): AddressInterface
    {
        $errorMessage = "No address exists with the specified customer address ID.";
        try {
            $address = $this->addressRepository->getById($addressId);
        } catch (NoSuchEntityException $exception) {
            throw new GraphQlNoSuchEntityException(__($errorMessage));
        }
        if ($customerId != $address->getCustomerId()) {
            throw new GraphQlNoSuchEntityException(__($errorMessage));
        }

        return $address;
    }
}
