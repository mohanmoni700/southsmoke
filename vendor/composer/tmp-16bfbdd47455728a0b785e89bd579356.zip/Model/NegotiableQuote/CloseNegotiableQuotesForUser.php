<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\NegotiableQuote\Api\NegotiableQuoteManagementInterface;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\ResourceModel\QuoteIdMask;
use Magento\Store\Api\Data\WebsiteInterface;

/**
 * Model for closing negotiable quotes
 */
class CloseNegotiableQuotesForUser
{
    /**
     * @var NegotiableQuoteManagementInterface
     */
    private $negotiableQuoteManagement;

    /**
     * @var Customer
     */
    private $customer;

    /**
     * @var Quote
     */
    private $quote;

    /**
     * @var NegotiableQuote
     */
    private $negotiableQuote;

    /**
     * @var QuoteIdMask
     */
    private $quoteIdMaskResource;

    /**
     * @param NegotiableQuoteManagementInterface $negotiableQuoteManagement
     * @param Customer $customer
     * @param Quote $quote
     * @param NegotiableQuote $negotiableQuote
     * @param QuoteIdMask $quoteIdMaskResource
     */
    public function __construct(
        NegotiableQuoteManagementInterface $negotiableQuoteManagement,
        Customer $customer,
        Quote $quote,
        NegotiableQuote $negotiableQuote,
        QuoteIdMask $quoteIdMaskResource
    ) {
        $this->negotiableQuoteManagement = $negotiableQuoteManagement;
        $this->customer = $customer;
        $this->quote = $quote;
        $this->negotiableQuote = $negotiableQuote;
        $this->quoteIdMaskResource = $quoteIdMaskResource;
    }

    /**
     * Close negotiable quote
     *
     * @param string[] $maskedQuoteIds
     * @param int $customerId
     * @param WebsiteInterface $website
     * @return array
     * @throws GraphQlAuthorizationException
     * @throws GraphQlInputException
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     */
    public function execute(array $maskedQuoteIds, int $customerId, WebsiteInterface $website): array
    {
        $this->customer->validateCanManage($customerId);

        $quoteIds = $this->quoteIdMaskResource->getUnmaskedQuoteIds($maskedQuoteIds);
        $quotes = $this->negotiableQuote->getOwnedNegotiableQuotes($quoteIds, $customerId, $website);
        $maskedIds = array_flip($quoteIds);
        $this->quote->validateCanClose($quotes);

        $data = [];
        $failedIds = [];
        foreach ($quotes as $quote) {
            $quoteId = (int)$quote->getId();
            $maskedId = $maskedIds[$quoteId];
            try {
                if ($this->negotiableQuoteManagement->close($quoteId)) {
                    $negotiableQuote = $quote->getExtensionAttributes()->getNegotiableQuote();
                    $data['closed_quotes'][$maskedId] = [
                        "uid" => $maskedId,
                        'status' => $negotiableQuote->getStatus(),
                        'name' => $negotiableQuote->getQuoteName(),
                        'created_at' => $quote->getCreatedAt(),
                        'updated_at' => $quote->getUpdatedAt(),
                        'model' => $quote
                    ];
                } else {
                    $failedIds[] = $maskedId;
                }
            } catch (\Exception $e) {
                $failedIds[] = $maskedId;
            }
        }

        if ($failedIds) {
            throw new LocalizedException(
                __("Could not close the negotiable quotes with the following UIDs: " . implode(", ", $failedIds))
            );
        }

        return $data;
    }
}
