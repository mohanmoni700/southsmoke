<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\NegotiableQuote\Api\NegotiableQuoteRepositoryInterface;
use Magento\NegotiableQuote\Model\ResourceModel\QuoteGridInterface;
use Magento\NegotiableQuoteGraphQl\Model\NegotiableQuote\ResourceModel\QuoteIdMask;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Store\Api\Data\WebsiteInterface;

/**
 * Model for deleting negotiable quotes
 */
class DeleteNegotiableQuotesForUser
{
    /**
     * @var NegotiableQuoteRepositoryInterface
     */
    private $negotiableQuoteRepository;

    /**
     * @var QuoteGridInterface
     */
    private $quoteGrid;

    /**
     * @var Customer
     */
    private $customer;

    /**
     * @var Quote
     */
    private $quote;

    /**
     * @var NegotiableQuote
     */
    private $negotiableQuote;

    /**
     * @var QuoteIdMask
     */
    private $quoteIdMaskResource;

    /**
     * @param NegotiableQuoteRepositoryInterface $negotiableQuoteRepository
     * @param QuoteGridInterface $quoteGrid
     * @param Customer $customer
     * @param Quote $quote
     * @param NegotiableQuote $negotiableQuote
     * @param QuoteIdMask $quoteIdMaskResource
     */
    public function __construct(
        NegotiableQuoteRepositoryInterface $negotiableQuoteRepository,
        QuoteGridInterface $quoteGrid,
        Customer $customer,
        Quote $quote,
        NegotiableQuote $negotiableQuote,
        QuoteIdMask $quoteIdMaskResource
    ) {
        $this->negotiableQuoteRepository = $negotiableQuoteRepository;
        $this->quoteGrid = $quoteGrid;
        $this->customer = $customer;
        $this->quote = $quote;
        $this->negotiableQuote = $negotiableQuote;
        $this->quoteIdMaskResource = $quoteIdMaskResource;
    }

    /**
     * Deletes negotiable quote
     *
     * @param string[] $maskedQuoteIds
     * @param int $customerId
     * @param WebsiteInterface $website
     * @return CartInterface[]
     * @throws GraphQlAuthorizationException
     * @throws GraphQlInputException
     * @throws GraphQlNoSuchEntityException
     * @throws LocalizedException
     */
    public function execute(array $maskedQuoteIds, int $customerId, WebsiteInterface $website): array
    {
        $this->customer->validateCanManage($customerId);

        $quoteIds = $this->quoteIdMaskResource->getUnmaskedQuoteIds($maskedQuoteIds);
        $maskedIds = array_flip($quoteIds);
        $quotes = $this->negotiableQuote->getOwnedNegotiableQuotes($quoteIds, $customerId, $website);
        $this->quote->validateCanDelete($quotes);

        $failedIds = [];
        foreach ($quotes as $quote) {
            $negotiableQuote = $quote->getExtensionAttributes()->getNegotiableQuote();
            try {
                $this->negotiableQuoteRepository->delete($negotiableQuote);
                $this->quoteGrid->remove($quote);
            } catch (\Exception $e) {
                $failedIds[] = $maskedIds[(int)$quote->getId()];
            }
        }
        if ($failedIds) {
            throw new LocalizedException(
                __("Could not delete the negotiable quotes with the following UIDs: " . implode(", ", $failedIds))
            );
        }

        return $quotes;
    }
}
