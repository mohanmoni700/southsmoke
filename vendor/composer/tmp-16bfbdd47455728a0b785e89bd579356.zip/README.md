# Negotiable Quote GraphQL #
