# Gift Card Requisition List Functional Tests

The Functional Test Module for **Magento Gift Card Requisition List** module.
