# Quick Order Functional Tests

The Functional Test Module for **Magento Quick Order** module.
