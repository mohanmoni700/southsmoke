# Bundle Staging Functional Tests

The Functional Test Module for **Magento Bundle Staging** module.
