# Magento_CatalogStagingPageBuilder module

The Magento_CatalogStagingPageBuilder module sets up PageBuilder to be a part of the staging functionality in Magento EE.
