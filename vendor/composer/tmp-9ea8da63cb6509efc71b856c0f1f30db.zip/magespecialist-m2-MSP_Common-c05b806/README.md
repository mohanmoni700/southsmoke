# MSP_Common for M2
MageSpecialist Magento2 Common Library

This module is almost useless, it is just a requirement for other Magento 2 MageSpecialist modules.
