# Purchase Order Rule Functional Tests

The Functional Test Module for **Magento Purchase Order Rule** module.
